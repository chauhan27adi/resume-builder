# New Code Review Findings

This review examined the complete Normal Track pipeline, Track 1 (BinDiff), Track 2
(pseudo-C / Java decompilation), acquisition, triage, stage orchestration, result
reporting, and remaining utilities/workflow. Findings #1–17 from the earlier review are
archived in `old_bugs_fixed.md`.

## Medium severity

18. **Oracle Stage 1 silently skips corrupt or unreadable JARs**
    - **Status:** Fixed (2026-10-26). `_jar_has_classes()` no longer swallows errors; an unreadable or corrupt changed jar is recorded in Stage 1 `errors` (exit 3).
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 1 / Java decompilation.
    - **Location:** `oracle/stage1.py` — `_jar_has_classes()` and the changed-JAR loop.
    - **Trigger:** A changed `.jar`/`.zip` is corrupt, unreadable, or disappears after
      triage but before Stage 1 processes it.
    - **Failure scenario and observed behavior:** `_jar_has_classes()` catches every
      exception from opening and listing the archive and returns `False`. The caller
      treats that result as an ordinary archive with no Java classes and continues
      without adding an entry to `errors`. An end-to-end temporary reproduction used
      differing, invalid JAR files on both sides: Oracle triage reported one changed
      content file, while Stage 1 returned `available: true`, `errors: 0`, and no
      readable result.
    - **Impact:** Changed OJVM classes can be omitted from the analysis while the Stage 1
      result looks successful and the CLI has no recorded partial failure to report.
    - **Suggested fix:** Distinguish a valid archive with no `.class` entries from an
      archive that cannot be read or parsed. Record the latter in Stage 1 `errors` and
      add tests for a corrupt archive and a file that vanishes between triage and Stage 1.

19. **Unexpected `meta.json` shapes can crash CVE attribution**
    - **Status:** Fixed (2026-10-26). `load_attrib()` accepts only `{"tracked_cves": "id,id" | ["id", ...]}`. Any other shape, non-string items or unreadable JSON produce a warning and empty attribution instead of an exception.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — shared attribution used by Stage 1/Stage 2.
    - **Location:** `_attribution.py` — `load_attrib()`, metadata fallback.
    - **Trigger:** `meta.json` exists and contains valid JSON, but its top level is not an
      object, or `tracked_cves` has an unsupported value type.
    - **Failure scenario and observed behavior:** After JSON parsing, `load_attrib()`
      immediately calls `meta.get("tracked_cves")` without validating that `meta` is a
      dictionary. A JSON list raises `AttributeError`; an integer `tracked_cves` raises
      `TypeError` when iterated. Both shapes were reproduced directly.
    - **Impact:** Instead of warning and continuing without attribution, a malformed
      metadata file can abort a stage (and therefore the run) before it writes a complete
      result.
    - **Suggested fix:** Validate the `meta.json` top-level shape and `tracked_cves`
      type before using them. Emit a clear diagnostic and follow the documented
      no-attribution fallback rather than allowing a raw type exception to escape.

20. **Oracle Stage 1 drops Java classes removed from a still-valid JAR**
    - **Status:** Fixed (2026-10-26). Each present jar side is checked for classes independently; a valid class-free side is an empty class map, so the other side's classes report as removed.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 1 / Java decompilation.
    - **Location:** `oracle/stage1.py` — changed-JAR loop and `_jar_has_classes()`.
    - **Trigger:** A changed JAR is a valid ZIP on both sides, the prior JAR contains
      `.class` files, and the fixed JAR contains no `.class` files.
    - **Failure scenario and observed behavior:** For a modified JAR, Stage 1 tests only
      the fixed-side archive with `_jar_has_classes(fj)`. If it has no classes, Stage 1
      skips the JAR without checking whether the prior side has classes. A temporary
      reproduction used a prior ZIP containing `x/Foo.class` and a fixed ZIP containing
      only `README.txt`: Stage 1 returned `available: true`, `errors: 0`, and no readable
      results.
    - **Impact:** Java code removed by a patch is omitted from the report, even though
      Stage 1 reports no analysis error.
    - **Suggested fix:** Check both archives independently. If only one side contains
      Java classes, decompile and report those classes as removed or added; skip only
      when neither side contains classes. Add a regression test for a valid class-free
      archive on one side.

21. **DB2 registry layer bytes are accepted without checking their advertised digest**
    - **Status:** Fixed (2026-10-26). A layer is SHA-256 hashed while it streams (a resumed `.part`'s prefix first) and cached only on an exact digest match. A layer cached by an older version is verified once and stamped (`.verified`: digest + size + mtime). A non-sha256 digest is refused.
    - **Status:** Fixed (2026-10-26). Follow-up: the `.verified` stamp (digest + size + mtime) let a layer replaced by same-size bytes with its timestamp restored pass. `_layer_ok()` now hashes a cached layer against its digest every time it is used (only when a tree is being extracted, which reads every layer anyway). Stamps left by the earlier version are deleted.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — DB2 acquisition / OCI layer cache.
    - **Location:** `db2/acquire.py` — `_download_blob()` and `_acquire_container()`.
    - **Trigger:** A registry returns bytes that do not match a layer's manifest digest,
      or a cached layer file is corrupted or replaced.
    - **Failure scenario and observed behavior:** `_acquire_container()` names each
      cached blob using the manifest digest, but `_download_blob()` neither hashes a
      downloaded response nor validates an existing cache file before returning it. A
      focused reproduction supplied a valid gzipped tar layer whose bytes differed from
      the advertised SHA-256. The function saved it under the expected digest name, and
      `_extract_layers()` extracted its altered DB2 file content.
    - **Impact:** A truncated, corrupted, or otherwise mismatched registry layer can
      silently become part of the reconstructed DB2 tree, making the comparison analyze
      content different from the image identified by the manifest.
    - **Suggested fix:** Validate every downloaded and cached layer against its
      manifest digest using the digest algorithm declared by the digest. Reject and
      remove a mismatch rather than extracting it; add tests for mismatched downloads
      and corrupt cache entries.

## Additional findings from this review

### Medium severity

22. **Replacing a manual MSSQL installer without changing its file stats reuses the old engine**
    - **Status:** Fixed (2026-10-26). `file_fingerprint()` is now name, size and the SHA-256 of the file's content (mtime dropped: a touched but unchanged installer isn't re-extracted). It is not memoized by file stats, because a same-size, same-timestamp replacement leaves every stat unchanged. It covers manual MSSQL installers, DB2 manual fixpacks and the #31 carve sentinel.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — manual MSSQL acquisition / extraction cache.
    - **Location:** `_acquire_state.py` — `file_fingerprint()`; `mssql/acquire.py` —
      `extract_engine()`.
    - **Trigger:** A user replaces a manually supplied installer with different bytes
      but preserves its basename, size, and modification timestamp. DB2 manual fixpack
      acquisition uses the same fingerprint helper.
    - **Failure scenario and observed behavior:** `file_fingerprint()` identifies a
      source only by basename, size, and `mtime_ns`; `extract_engine()` reuses an
      extracted tree whenever that fingerprint matches. A focused reproduction replaced
      a temporary installer from `build-A` to different same-length `build-B` bytes and
      restored the original timestamp. The second extraction was skipped and the cached
      engine still contained `build-A`.
    - **Impact:** The CLI can compare an old extracted build while the user believes the
      newly supplied installer is being analyzed. This can produce stale or incorrect
      findings without a partial-failure warning.
    - **Suggested fix:** Bind manual-source cache identity to the file contents (ideally
      hashing while reading/extracting, so a multi-GB source is not needlessly read
      twice), or use a stronger validated identity that cannot match after content
      replacement. Add a regression test for same-size, same-timestamp replacement.

23. **Oracle Stage 1 silently omits changed readable files larger than 8 MiB**
    - **Status:** Fixed (2026-10-26). `_read_source()` raises `SourceTooLarge` over the limit and lets read errors propagate; Stage 1 records the file in `errors` instead of diffing it against empty text.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 1 / PL/SQL and SQL input.
    - **Location:** `oracle/stage1.py` — `_read_source()` and the readable-text loop.
    - **Trigger:** A changed `.sql`/PL/SQL file exceeds `_MAX_BYTES` (8 MiB) on both
      sides, or one side exceeds the limit and the other does not.
    - **Failure scenario and observed behavior:** `_read_source()` returns an empty
      string for an oversized file. Stage 1 treats this like a successful read rather
      than a skip or error. A temporary run with distinct 8 MiB + 1-byte SQL files on
      both sides reported `readable_changed: 0`, `errors: 0`, and no readable cards.
    - **Impact:** A real change in a large database package or script can disappear
      from the analysis while the stage result indicates no analysis problem. With
      only one side over the limit, the empty source can also make the diff resemble a
      one-sided addition or removal.
    - **Suggested fix:** Represent an over-limit read explicitly and add it to Stage 1
      errors/partial-result reporting, or produce a clearly marked bounded/truncated
      comparison rather than treating the file as empty.

24. **Oracle/DB2 triage silently treats unreadable subdirectories as absent**
    - **Status:** Fixed (2026-10-26). Both indexers pass an `onerror` callback to `os.walk()`. A directory that can't be listed is recorded in Stage 0 `errors` (exit 3), and files under it on the other side are no longer reported as added/removed. Excluded/noise folders are ignored, and a missing root is reported as `.`.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Stage 0 file indexing.
    - **Location:** `oracle/triage.py` — `_index()`; the same default `os.walk()` behavior
      is used by `db2/triage.py` — `_rel_files()`.
    - **Trigger:** A nested input directory cannot be enumerated, for example because
      of an access-denied error or because it disappears during the walk.
    - **Failure scenario and observed behavior:** Both indexers call `os.walk()` without
      an `onerror` callback, so Python suppresses directory-scanning `OSError`s. A
      focused reproduction injected a `PermissionError` for a subdirectory containing
      different prior/fixed SQL files: Oracle triage returned zero files and zero
      errors, as if the trees were empty.
    - **Impact:** Files beneath the inaccessible directory are excluded from all later
      stages, and the run can look like a valid no-change result.
    - **Suggested fix:** Supply an `onerror` callback and record the affected path in
      Stage 0 `errors`; ensure the CLI then returns its partial-result exit status.
      Add tests for a denied/disappearing subdirectory in each backend indexer.

25. **MSSQL Track 2 decompilation concatenates disjoint code fragments without fixing branches**
    - **Status:** Fixed (2026-10-26). `_extract_func_bytes()` places every chunk at its true offset from the primary (gaps filled with int3). Chunks below the primary, or spans over 16 MiB, are left out and the pseudo-C gets a `// NOTE` saying it is partial.
    - **Confidence:** Confirmed.
    - **Track:** Track 2 — MSSQL pseudo-C decompilation.
    - **Location:** `mssql/stage2.py` — `_extract_func_bytes()` and its `decompile_cached()`
      call.
    - **Trigger:** A function has separate hot/cold `.pdata` chunks with a relative
      branch or call from one chunk to another, and `--decompile` is enabled for that
      function.
    - **Failure scenario and observed behavior:** `_extract_func_bytes()` concatenates
      chunk bytes but retains the relative branch displacement calculated for the
      chunks' original addresses. A focused x86-64 calculation used a hot chunk at
      `0x1000` jumping to a cold chunk at `0x5000`: the original target was `0x5000`,
      while after concatenation and loading at `0x100000` the jump targeted `0x104000`
      instead of the cold chunk at `0x100005`.
    - **Impact:** Ghidra receives incorrect control-flow targets for such functions.
      The generated pseudo-C can omit or invent paths, undermining the intended
      before/after explanation. The assembly/function diff remains the separate
      canonical analysis.
    - **Suggested fix:** Preserve the fragments' relative virtual addresses during
      decompilation or relocate cross-fragment relative branches/calls when building
      the synthetic blob. If correct relocation is not supported, mark these pseudo-C
      results unavailable instead of presenting potentially misleading output.

26. **Track 1 reuses BinExport files after Ghidra or BinExport changes**
    - **Status:** Fixed (2026-10-26). The BinExport sidecar now records the binary's SHA-256 plus `tool_paths.binexport_identity()` (the content of Ghidra's application.properties, the JDK, and the BinExport extension's jars/script/properties) and an export-options tag. A tool update re-exports, and older binary-hash-only sidecars are not trusted.
    - **Confidence:** Confirmed.
    - **Track:** Track 1 — Ghidra/BinExport cache.
    - **Location:** `_bindiff.py` — `ghidra_binexport()` cache check and `.sha256` sidecar.
    - **Trigger:** The input binary remains unchanged but the installed Ghidra version,
      BinExport extension, or `BinExport.java` script is updated while the work directory
      containing the cached export is retained.
    - **Failure scenario and observed behavior:** Cache validity is determined only by
      whether the `.BinExport` and its sidecar exist and whether the sidecar equals the
      input binary's SHA-256. It does not include the Ghidra/BinExport/script identity.
      A focused mocked run called `ghidra_binexport()` twice for the same input and
      simulated an intervening tool update: the second call made no subprocess calls
      and returned the previous export.
    - **Impact:** Track 1 can continue matching functions using an export produced by an
      older analysis tool or export script, even though the user has updated the tools.
      The run gives no indication that the cached result is stale.
    - **Suggested fix:** Include a stable identity for the Ghidra executable/version,
      BinExport extension/script, and relevant export options in the cache metadata.
      Invalidate and regenerate the export when that identity differs; add a regression
      test that changes the tool/script identity while keeping the input binary fixed.

## Validation performed

- Reproduced finding #20 using valid ZIP files: the prior archive contained a Java class,
  the fixed archive did not, and Stage 1 emitted no result and reported zero errors.
- Reproduced finding #21 using a mocked registry response: the layer's SHA-256 differed
  from the advertised digest, but the layer was cached and its altered file was extracted.
- Reproduced finding #18 through Oracle triage and Stage 1 using temporary invalid JAR
  inputs; Stage 1 reported zero errors despite no results for the changed archive.
- Reproduced finding #19 with a JSON list at the top level and with numeric
  `tracked_cves`; both raised uncaught type errors.
- Reproduced finding #22 with a mocked MSSQL extractor and a same-size installer
  replacement whose original `mtime_ns` was restored; extraction ran only once and the
  old engine bytes were reused.
- Reproduced finding #23 with changed SQL files of 8 MiB + 1 byte; Stage 1 reported no
  cards and zero errors.
- Reproduced finding #24 by injecting a directory-enumeration `PermissionError`; the
  affected SQL files disappeared from Oracle triage with zero errors.
- Reproduced finding #25's branch-target mismatch using a synthetic relative jump across
  two disjoint function chunks.
- Reproduced finding #26 with mocked Ghidra/BinExport execution: the first call generated
  an export and input-hash sidecar; the second call for the same binary returned the
  existing export without invoking any subprocess, regardless of a simulated tool update.
- Track 1 (BinDiff) and the remaining shared matching/reporting workflow were reviewed.

### New findings from the current review

#### Medium severity

27. **DB2 Stage 2 overwrites distinct ELF functions that share a local symbol name**
    - **Status:** Fixed (2026-10-26). Same-named distinct functions are keyed `name [file.c]` from STT_FILE context (`#k` / `?` fallbacks); aliases collapse; `reconcile_dup_names()` aligns a copy that is qualified on only one side; attribution ignores the qualifier. DB2 and Oracle parsers.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — DB2 Stage 2; also affects Track 1's function/address mapping.
    - **Location:** `db2/stage2.py` — `_func_map()`; the same name-keyed overwrite exists
      in `oracle/stage2.py` — `_func_map()`.
    - **Trigger:** An ELF `.symtab` contains multiple `STT_FUNC` symbols with the same
      name, and an earlier occurrence changes while the later occurrence does not.
      Duplicate local names can occur when separately compiled functions have the same
      static name.
    - **Failure scenario and observed behavior:** Both parsers store functions in a
      dictionary keyed only by `name`, assigning `out[name] = ...` as they read symbols.
      A focused reproduction built valid ELF files with two local `DuplicateStatic`
      functions: the first function's bytes differed between prior and fixed, while the
      second was identical. The second occurrence replaced the first in both function
      maps. Running the DB2 per-file worker then returned zero function cards and no
      worker failure, although the binary bytes differed.
    - **Impact:** A real change in one of multiple same-named functions can be omitted
      from Normal Track output. Track 1 address-to-name maps use those same incomplete
      function maps, so BinDiff matches for the omitted instance cannot be attached to
      the correct function either.
    - **Suggested fix:** Preserve duplicate symbols as distinct entries (for example,
      by including binding/section/address in the internal key) and pair duplicates
      deterministically across builds. If reliable pairing is not possible, report the
      ambiguous symbols as unanalyzed rather than silently overwriting them. Add a
      regression test with duplicate local names where only the earlier symbol changes.

#### Low severity

28. **Stage 2 silently omits individual functions above the 300,000-byte limit**
    - **Status:** Fixed (2026-10-26). All three function maps record skipped functions as `.oversized` (size + SHA-256 of their bytes). A changed one is listed in Stage 2 `skipped_functions`, counted in `counts.functions_skipped` and flagged by the CLI (exit 3). An unchanged one stays quiet. A function that crosses the limit is no longer misreported as added/removed, and a side whose only functions are oversized is no longer called symbol-less.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Stage 2 function indexing across DB2, Oracle, and MSSQL.
    - **Location:** `db2/stage2.py`, `oracle/stage2.py`, and `mssql/stage2.py` —
      `_func_map()` size guards against `_MAX_FUNC_BYTES`.
    - **Trigger:** A changed binary contains a function larger than 300,000 bytes and at
      least one other function that remains indexable.
    - **Failure scenario and observed behavior:** Each backend's function map skips the
      oversized function. A focused DB2 reproduction used valid ELF inputs with a
      changed 300,001-byte function plus an unchanged small function. The per-file
      worker emitted no function cards for the changed function and returned without
      marking the binary failed. The non-empty map on each side bypasses the existing
      whole-binary empty-map failure check.
    - **Impact:** A genuine large function change can be absent from the report with no
      error count or partial-result warning. The limit may be useful for excluding
      pathological symbol ranges, but the current output does not distinguish that
      intentional skip from a fully analyzed binary.
    - **Suggested fix:** Track skipped symbol names and sizes, and surface them as
      partial-analysis errors/counts; alternatively, analyze the function with a safe
      bounded strategy. Add tests where a binary contains both an oversized changed
      function and ordinary indexable functions.

29. **Track 2 pseudo-C cache does not identify the Ghidra installation contents**
    - **Status:** Fixed (2026-10-26). The pseudo-C cache key uses `tool_paths.decompiler_identity()`: the install path, application.properties (version/build/revisions), the JDK, and the native decompiler binary, all by content, instead of the home folder's basename.
    - **Confidence:** Confirmed.
    - **Track:** Track 2 — shared pseudo-C decompilation cache.
    - **Location:** `_decompile.py` — `_decompiler_identity()` and `decompile_cached()`.
    - **Trigger:** Ghidra is replaced or upgraded in place, or `GHIDRA_HOME` changes to a
      different installation whose directory has the same basename, while the same
      Stage 2 cache is retained.
    - **Failure scenario and observed behavior:** The cache identity hashes only the
      Ghidra home directory's basename and `DecompileFunc.java`; it does not fingerprint
      the installed Ghidra executable/version. A focused reproduction used two different
      Ghidra home paths named `ghidra`: their identities were equal, and the second
      `decompile_cached()` call reused the first tool's pseudo-C without calling the
      decompiler again.
    - **Impact:** The optional pseudo-C view can be stale after a tool replacement,
      potentially misleading a reviewer about the source corresponding to the current
      binary. The normalized assembly diff remains the separate canonical Stage 2 result.
    - **Suggested fix:** Include a reliable Ghidra version/build identity (and relevant
      analysis options) in the decompilation cache key, rather than relying on the
      install directory name. Add a regression test for a Ghidra replacement at a
      different path with the same basename.

## Prior review validation (findings #27–29)

- The duplicate-symbol reproduction used valid ELF inputs and exercised the real DB2
  `_func_map()` and per-file worker: the changed first duplicate was overwritten by the
  unchanged second duplicate, resulting in zero cards and no worker failure.
- The oversized-function reproduction exercised the DB2 parser and per-file worker with
  a changed 300,001-byte function and a normal unchanged neighbor; the function was
  filtered and the worker did not mark the binary failed.
- The Track 2 cache reproduction used two different Ghidra home paths with the same
  basename; the cache identity remained equal and the second call reused cached output.

### New finding from this review

#### Medium severity

30. **Stage 2 normalization treats some semantic x86 operand changes as unchanged**
    - **Status:** Fixed (2026-10-26). `norm()` keeps register width (`R32`/`R64`), memory-access width (`m8`..`m64`) and fs/gs overrides in both lines and shape; register allocation and no-op ds/es/ss/cs prefixes are still normalized away.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — function-level Stage 2; Track 1 — BinDiff-assisted
      function comparisons also use the shared classifier. Track 2's optional pseudo-C
      output is affected indirectly because functions filtered as unchanged never reach
      the decompilation step.
    - **Location:** `_x86diff.py` — `norm()` and its register/memory operand normalization;
      the DB2, MSSQL, and Oracle Stage 2 workers skip functions classified as `"same"`.
    - **Trigger:** A patch changes operand width or a memory segment override without
      changing the mnemonic and normalized operand count.
    - **Failure scenario and observed behavior:** `norm()` replaces every register with
      the same `"R"` token and does not retain a memory operand's segment override. With
      real Capstone decoding, `cmp eax, ebx` (`39 d8`) and `cmp rax, rbx` (`48 39 d8`)
      both normalize to `["cmp R R"]`; `classify()` returns `"same"`. Likewise, a
      `mov` through `fs:[...]` and the corresponding `mov` through the default segment
      normalize identically. The Stage 2 workers discard `"same"` results, so such a
      semantic change does not produce a function card.
    - **Impact:** A real change to arithmetic width, truncation/zero-extension behavior,
      or segment-relative memory access can be omitted from the binary-diff report. This
      creates a false negative in the application's core patch-review signal.
    - **Suggested fix:** Preserve semantically relevant operand properties during
      normalization, including register width and memory segment, while continuing to
      normalize register allocation where safe. Add regression tests that feed these
      instruction pairs through `norm()` and `classify()`, and verify the function is
      reported by each backend's Stage 2 worker.

## Prior review validation (finding #30)

- Reproduced the normalization issue using the installed Capstone decoder: the 32-bit and
  64-bit `cmp` instructions normalized to the same line and were classified as `"same"`;
  the tested FS-segment and default-segment memory accesses also normalized identically.

### New findings from this review

#### Medium severity

31. **MSSQL extraction can reuse cabinets carved from a different installer**
    - **Status:** Fixed (2026-10-26). The carve sentinel records the installer's fingerprint and is reused only for that installer. A stale or older-format sentinel is deleted before re-carving. The MSP staging directory is also cleared before each extraction, because a leftover MSP from another installer could be picked up the same way.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — MSSQL acquisition and extraction.
    - **Location:** `mssql/acquire.py` — `_carve_cabs()` completion-marker check and
      `extract_engine()` retry path.
    - **Trigger:** An extraction fails after CAB carving, then a different installer is
      extracted using the same `cab_dir`.
    - **Failure scenario and observed behavior:** `_carve_cabs()` returns immediately
      whenever `_carve_complete` exists; the marker records no installer identity. A
      focused reproduction carved an `OLD1` CAB, simulated a later MSP extraction failure,
      and retried with a different installer containing a `NEW2` CAB. The retry consumed
      the cached `OLD1` CAB, then `extract_engine()` marked the resulting tree complete
      for the new source. Thus the extraction cache can certify old-build contents as the
      requested new build.
    - **Impact:** After a failed acquisition followed by a retry for another KB or manual
      installer, the comparison can analyze the wrong SQL Server engine while the source
      sidecar claims the requested source. That can invalidate the entire comparison
      without a partial-result warning.
    - **Suggested fix:** Bind the CAB completion marker and cached CAB set to the
      installer’s validated identity (preferably content hash), and recarve when that
      identity differs. Add a regression test for a failed extraction followed by a
      different installer using the same cabinet directory.

#### Low severity

32. **Concurrent MSSQL workers can read a partially written shared PDB cache entry**
    - **Status:** Fixed (2026-10-26). The PDB downloads to a private temp file, is checked against `Content-Length` and the MSF 7.00 superblock (no truncation), then is atomically renamed into place. A cache entry already truncated on disk (left by the old code) is discarded and re-fetched.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — MSSQL Stage 2 symbol lookup; affects function naming and
      CVE attribution.
    - **Location:** `mssql/symbols.py` — `fetch_pdb()`; `mssql/stage2.py` runs changed DLL
      jobs concurrently and uses a shared `_GLOBAL_PDB_CACHE`.
    - **Trigger:** Two concurrent DLL jobs request the same PDB cache key, such as copies
      of a DLL with the same PDB name, GUID, and age.
    - **Failure scenario and observed behavior:** `fetch_pdb()` writes directly to the
      final cache path. A second worker treats any existing non-empty file as a complete
      PDB and returns it while the first download is still in progress. A synchronized
      reproduction paused the first download after writing a 2 MiB chunk; the second
      caller returned the 2 MiB partial file, although the completed file was 2 MiB + 4
      bytes.
    - **Impact:** The second worker may fail to load the PDB or load an incomplete symbol
      set. Stage 2 then silently falls back to less reliable RVA-based names, reducing
      function matching and CVE attribution for that DLL; this can also hide one-sided
      function changes when addresses shifted.
    - **Suggested fix:** Download to a unique temporary file, validate completion, and
      atomically replace the cache destination; coordinate workers for identical keys if
      necessary. Add a concurrent-fetch regression test asserting that no caller can
      observe the destination before the complete PDB is installed.

## Current review validation

- Finding #31 was reproduced with different synthetic installer CAB payloads and a
  simulated failure after the first CAB carve. The retry used the first installer’s CAB
  and committed a completed extraction for the second source.
- Finding #32 was reproduced with concurrent `fetch_pdb()` calls sharing one cache key.
  The second call observed the first call’s partially written file before download
  completion.

### New findings from this review

#### Medium severity

33. **DB2 Stage 1 can miss JAR entry changes when CRC-32 collides**
    - **Status:** Fixed (2026-10-26). `_jar_content()` hashes each entry's actual bytes with SHA-256; reading also makes zipfile verify the CRC. Byte-identical jar pairs are skipped before anything is decompressed.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — DB2 Stage 1 bundled dependency comparison.
    - **Location:** `db2/stage1.py` — `_jar_content()` and the equal-version comparison
      in `run()`.
    - **Trigger:** A prior and fixed JAR have the same version string and contain a
      corresponding non-directory entry with different bytes but the same uncompressed
      size and CRC-32. This can be deliberately constructed; CRC-32 is not a
      collision-resistant content hash.
    - **Failure scenario and observed behavior:** `_jar_content()` records only
      `(ZipInfo.CRC, ZipInfo.file_size)` for each entry. A focused reproduction built
      equal-version JARs with different eight-byte payloads for the same entry, where
      both payloads had the same size and CRC-32. Calling `db2.stage1.run()` emitted no
      dependency change card and reported zero errors, treating the JARs as identical.
    - **Impact:** A changed dependency resource or class can be omitted from the
      readable comparison if an entry's CRC collides. This is especially relevant when
      analyzing untrusted or intentionally crafted packages; ordinary accidental
      collisions are less likely.
    - **Suggested fix:** Compare actual entry bytes or use a cryptographic digest (such
      as SHA-256) rather than CRC-32 as the content identity. Preserve the current
      exclusion of manifest/signature churn, and add a test with distinct same-size
      payloads that have an equal CRC-32.

## Current review validation

- Finding #33 was reproduced end-to-end through `db2.stage1.run()`: the JAR entry
  payloads were different, their sizes and CRC-32 values were equal, and Stage 1
  emitted no dependency change card or error.

### New findings from this review

#### Low severity

34. **One-shot `stages` iterators can make `run_pipeline()` execute no stages**
    - **Status:** Fixed (2026-10-26). `run_pipeline()` turns `stages` into a frozenset once (a plain string is one stage name) and rejects unknown stage names with `ValueError`.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — shared pipeline orchestration API.
    - **Location:** `pipeline.py` — `run_pipeline()` stage loop.
    - **Trigger:** A caller passes a one-shot iterator containing a subset of stages, such
      as `iter(["stage1"])`, to the documented `stages` iterable parameter.
    - **Failure scenario and observed behavior:** The loop checks each stage with
      `if stage not in stages`. Membership testing consumes an iterator while searching;
      checking `"triage"` exhausts `iter(["stage1"])` before the loop reaches `"stage1"`.
      A focused call to `run_pipeline()` with `stages=iter(["stage1"])` returned an empty
      result and invoked no backend stage, without reporting an error.
    - **Impact:** Library/API callers that supply a generator can receive an apparently
      successful empty result even though they requested analysis. The CLI is unaffected
      because it passes tuples of stage names.
    - **Suggested fix:** Materialize the requested stages once (for example, as a set)
      before entering the stage loop, and add a regression test for a one-shot iterator.

## Current review validation

- Finding #34 was reproduced with temporary input directories and a stub backend:
  `stages=iter(["stage1"])` returned `{}` and the backend invocation count was zero.
- The full existing unittest suite passed: 307 tests. The new iterator reproduction was
  run separately; the suite does not currently cover this API input shape.

### New findings from this review

#### Low severity

35. **MSSQL Stage 1 silently suppresses embedded-SQL extraction I/O failures**
    - **Status:** Fixed (2026-10-26). `_embedded_sql()` adds each extraction read failure (and a listing failure) to Stage 1 `errors`.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — MSSQL Stage 1 embedded T-SQL extraction from
      script-bearing PE files.
    - **Location:** `mssql/stage1.py` — `_embedded_sql()`, the `OSError` handler around
      `_extract_strings()`.
    - **Trigger:** A script-bearing PE is present in both builds, but reading either
      binary for printable T-SQL strings fails (for example, due to an access or
      transient I/O error).
    - **Failure scenario and observed behavior:** `_embedded_sql()` catches `OSError`
      and continues without adding an error to the Stage 1 result or identifying the
      skipped binary. A focused Stage 1 reproduction used a script-bearing DLL in both
      input trees and injected an `OSError` for its fixed-side string extraction. With
      resource-database inputs present, Stage 1 returned `available: true`, no
      `unavailable_parts`, `embedded_sql: 0`, `errors: 0`, and no readable cards.
    - **Impact:** Changes to embedded T-SQL—including a security hardening change—can be
      omitted from the Stage 1 report while the result presents no indication that the
      embedded-SQL pass failed for that DLL.
    - **Suggested fix:** Return both cards and per-file extraction errors from
      `_embedded_sql()` and merge those errors into Stage 1's `errors`/count. Add a
      regression test that injects a read failure for either side of a paired
      script-bearing PE.

## Current review validation

- Finding #35 was reproduced end-to-end through `mssql.stage1.run()`: the embedded-SQL
  extractor raised an injected `OSError`, but Stage 1 reported zero embedded SQL cards,
  zero errors, and no unavailable parts.
- The full existing unittest suite passed earlier in this review: 307 tests. The focused
  reproduction was run separately; no existing test covers this failure path.

### New findings from this review

#### Low severity

36. **Oracle triage silently misclassifies files when indexing cannot stat them**
    - **Status:** Fixed (2026-10-26). A file whose size can't be read is recorded in Stage 0 `errors` and is no longer treated as added/removed because the other side has it (same mechanism as #24).
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 0 file indexing.
    - **Location:** `oracle/triage.py` — `_index()`, the `os.path.getsize()` error handler.
    - **Trigger:** A file is listed by the directory walk but `getsize()` raises for it on
      one input side, for example because it becomes inaccessible or disappears during
      indexing.
    - **Failure scenario and observed behavior:** `_index()` catches `OSError` and
      silently omits the file without recording an error. A focused triage run used the
      same relative `.sql` path on both sides and injected a `PermissionError` only when
      statting the prior-side file. The file was then classified as newly added on the
      fixed side: the result showed `added: 1`, `content_changed: 1`, `total: 0`, and
      `errors: 0`, despite the path existing on both sides.
    - **Impact:** Stage 1 can present a common file as wholly added or removed, obscuring
      the actual before/after change. If both sides fail indexing, the file can disappear
      from the comparison with no partial-result indication. This is distinct from
      finding #24, which concerns `os.walk()` silently skipping an unreadable directory.
    - **Suggested fix:** Capture per-file indexing failures and include them in Stage 0
      `errors`; do not treat an incompletely indexed side as authoritative evidence that
      the file was added or removed. Add tests for stat failure on one side and both sides.

## Current review validation

- Finding #36 was reproduced by injecting a prior-side `getsize()` failure for a `.sql`
  file present in both trees. Oracle triage reported it as added, with no error.
- Track 1 (BinDiff), Track 2 (decompilation), Normal Track, and remaining orchestration,
  acquisition, triage, and reporting code were reviewed. The complete existing suite was
  not rerun during this review; the focused reproduction is direct runtime evidence.

### New findings from this review

#### Medium severity

37. **Stage-limited runs leave stale later-stage results visible to `show`**
    - **Status:** Fixed (2026-10-26). Each triage run records a comparison identity (the stage0 JSON plus a stat fingerprint of both input trees) in `result_state.json`. Each stage1/stage2 run records the identity it ran against; its entry is dropped before it runs, so a failed run can't leave an old result marked current. `load_result()`/`show` leave out results that don't match and print a note. Separate stage runs on untouched inputs stay current. Output folders written by older versions (no state file) are read as before.
    - **Status:** Fixed (2026-10-26). Follow-up: the comparison identity was a stat fingerprint, so a same-size edit with its timestamp restored kept old Stage 1/2 results current. It is now the stage0 JSON plus the SHA-256 of every input file's content. An output dir nested inside an input tree is excluded from it.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — partial-stage orchestration and result reporting.
    - **Location:** `pipeline.py` — `run_pipeline()` stage selection and `load_result()`;
      `cli.py` — `cmd_show()`.
    - **Trigger:** Reuse an output directory from a full run, then run a subset that does
      not include a previously completed later stage (for example, run `stage1` after a
      full run, omitting Stage 2).
    - **Failure scenario and observed behavior:** `run_pipeline()` only executes the
      selected stages and does not invalidate persisted result JSON for skipped stages.
      `load_result()` independently loads every existing Stage 0, Stage 1, and Stage 2
      result file, and `show` presents them together without indicating they came from
      different invocations. A focused reproduction seeded an old
      `stage2/functions_diff.json`, invoked a `run_pipeline()` Stage 1-only pass with
      stubbed stages, then called `load_result()`: the newly executed result contained
      only triage/Stage 1, while the loaded result still included the old Stage 2 card
      (`OLD_BUILD :: old_function`).
    - **Impact:** Users can mistake stale function findings, CVE attributions, or counts
      from an earlier input pair for results of the latest stage-limited run. The
      displayed combination may not represent any single analysis invocation.
    - **Suggested fix:** Bind persisted results to a run identity and have `show` display
      only results belonging to the same invocation; alternatively, invalidate
      downstream-stage result files when an earlier stage is rerun or clearly mark them
      stale. Add a regression test that reuses an output folder, runs only Stage 1, and
      verifies that `show` does not present the old Stage 2 results as current.

## Current review validation

- Finding #37 was reproduced with a pre-existing `stage2/functions_diff.json` and a
  Stage 1-only pipeline invocation. `load_result()` continued to load the old Stage 2
  card after the invocation, with no freshness metadata in the returned data.
- The focused reproduction used stubbed stage modules; the stale-file read path is the
  same `load_result()` used by `show`. The full suite was not rerun for this
  documentation-only review update.

### New findings from this review

#### Low severity

38. **Leading whitespace before `KB` breaks MSSQL KB normalization**
    - **Status:** Fixed (2026-10-26). One strict `mssql.acquire.normalize_kb()` (used by the pipeline and the Update Catalog lookup) trims whitespace, removes one optional `KB` prefix and requires ASCII digits; anything else is a `ValueError` before any work starts. `lstrip("KB")` also used to strip any run of K/B characters.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — MSSQL auto-acquisition input handling.
    - **Location:** `pipeline.py` — `_normalize_kb()` and `_acquire_mssql()`.
    - **Trigger:** A caller supplies a KB argument with whitespace before the optional
      `KB` prefix, for example `" KB5084815 "`. The helper's documented behavior says it
      strips both the prefix and whitespace.
    - **Failure scenario and observed behavior:** `_normalize_kb()` applies
      `lstrip("KB")` before `.strip()`. Leading whitespace therefore prevents the prefix
      from being removed. A focused call showed `_normalize_kb(" KB5084815 ")` returns
      `"KB5084815"` rather than `"5084815"`; `_acquire_mssql()` then constructs the
      fixed build label `"KBKB5084815"` and passes the malformed identifier to the
      acquisition layer.
    - **Impact:** A whitespace-padded KB argument can cause an unexpected Update Catalog
      lookup/download failure instead of acquiring the requested patch. It does not
      affect the ordinary unpadded `KB5084815` or numeric `5084815` forms.
    - **Suggested fix:** Strip surrounding whitespace before removing the optional
      prefix, and validate that the remaining value contains only digits. Add tests for
      surrounding whitespace, optional prefix, and malformed inputs.

## Current review validation

- Finding #38 was reproduced through `_acquire_mssql()` with the acquisition function
  stubbed to capture its request: input `" KB5084815 "` became identifier
  `"KB5084815"` and build label `"KBKB5084815"`.
- Track 1 (BinDiff), Track 2 (decompilation), Normal Track, and the remaining
  acquisition, triage, orchestration, and reporting paths were reviewed. No full test
  suite was run during this pass; this finding was validated with a focused runtime call.

### New findings from this review

#### Low severity

39. **Oracle Java decompilation cache misses same-size CFR replacements**
    - **Status:** Fixed (2026-10-26). `java_decompile.identity()` uses the CFR jar's content and the Java runtime's identity instead of name + size; the javap fallback includes the Java runtime too.
    - **Confidence:** Confirmed.
    - **Track:** Track 2 — Oracle OJVM Java decompilation and Stage 1 decompiler cache.
    - **Location:** `oracle/java_decompile.py` — `identity()`; `oracle/stage1.py` —
      `_decompile_cached()`.
    - **Trigger:** The bundled CFR JAR is replaced or updated in place with different
      bytes but the same file name and byte size, while the input OJVM JAR and Stage 1
      cache are unchanged.
    - **Failure scenario and observed behavior:** `identity()` represents CFR using only
      its tool name and `st_size`. `_decompile_cached()` includes that identity in the
      source sidecar used to validate cached Java output. A focused reproduction used
      two different same-size CFR files and an unchanged input JAR: the identity stayed
      equal, the second cache check skipped decompilation, and the old tool's output
      remained in the cache (one decompiler invocation total).
    - **Impact:** Track 2 can serve stale Java source from a prior CFR build after an
      in-place tool replacement, so Stage 1 may compare or report output produced by a
      different decompiler than the one currently installed.
    - **Suggested fix:** Include a content digest of the CFR JAR (and, where practical,
      the Java runtime identity) in `identity()`. Add a test replacing CFR with
      different same-size bytes and verifying that the cache is regenerated.

## Current review validation

- Finding #39 was reproduced with unchanged input-JAR bytes and two distinct, equal-size
  CFR files. `identity()` returned the same value before and after replacement;
  `_decompile_cached()` performed only one decompiler invocation and retained the first
  output.
- The review covered Track 1 (BinDiff), Track 2 (C/Java decompilation), Normal Track,
  plus the remaining acquisition, triage, orchestration, and reporting paths. No full
  test suite was run for this documentation-only update; the cache behavior was tested
  directly.

### New findings from this review

#### Low severity

40. **DB2 experimental data diff ignores binary changes after a leading NUL byte**
    - **Status:** Fixed (2026-10-26). String semantics now apply only when a window actually starts with a C-string. Binary data with an early NUL goes through the binary checks, which still discount relocated pointers and offset tables.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — optional DB2 Stage 2 referenced-data comparison.
    - **Location:** `db2/stage2.py` — `_real_data_change()` and `_data_changes()`.
    - **Trigger:** The optional data-diff feature is enabled with
      `PATCHDIFF_DATA_DIFF=1`, unchanged instructions reference different data windows,
      and both windows contain a NUL at the same position before differing binary bytes.
      For example, `b"\x00AAAA"` versus `b"\x00BBBB"`.
    - **Failure scenario and observed behavior:** `_real_data_change()` treats any
      window containing a NUL as string-like, compares only the bytes before the first
      NUL, and returns `False` when those prefixes match. A focused call through
      `_data_changes()` with identical instruction streams and different referenced
      windows (`b"\x00AAAA"` and `b"\x00BBBB"`) returned no data-change records.
    - **Impact:** With the experimental option enabled, genuine changes in binary
      tables or other non-string data can be omitted from DB2 Stage 2 output when the
      changed bytes follow an early NUL. The option is off by default, limiting exposure.
    - **Suggested fix:** Distinguish actual string data from binary data before applying
      NUL-terminated comparison, or compare bytes after NUL for data known not to be a
      string. Add tests for both NUL-terminated string-pool churn and binary data
      differences containing early NUL bytes.

## Current review validation

- Finding #40 was reproduced through `_data_changes()`: the prior and fixed data windows
  differed, but the function returned an empty list because both began with NUL.
- The full test suite was not run during this documentation-only review update. The
  finding is limited to the opt-in experimental DB2 data-diff path.

### New findings from this review

#### Low severity

41. **A complete leftover DB2 layer download cannot be resumed after interruption**
    - **Status:** Fixed (2026-10-26). On a 416, a `.part` that matches the digest is promoted. Otherwise it is discarded and the download restarts. A digest mismatch after a resume also restarts from scratch once.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — DB2 OCI layer download and retry handling.
    - **Location:** `db2/acquire.py` — `_download_blob()`.
    - **Trigger:** A download writes all layer bytes to `<digest>.tar.gz.part`, but the
      process stops before renaming the temporary file to its final cache path. On retry,
      the registry rejects a range request starting at the end of the blob with HTTP 416.
    - **Failure scenario and observed behavior:** `_download_blob()` sends
      `Range: bytes=<part-size>-` whenever the `.part` file exists, then calls
      `raise_for_status()` before handling the response. A focused reproduction with a
      complete temporary `.part` file and a simulated 416 response raised `HTTPError`;
      the `.part` remained and the final cache file was absent. Repeating the call follows
      the same path and fails again.
    - **Impact:** A recoverable interruption in the narrow interval after transfer
      completion but before finalization can permanently block acquisition of that layer
      until the user removes the partial file manually. Since each requested image needs
      its layers, this can stop the DB2 analysis run.
    - **Suggested fix:** On 416, validate whether the existing partial bytes constitute
      the complete blob (preferably against the manifest digest); if complete, atomically
      promote it, otherwise discard or restart the partial download. Add a regression test
      for a full-size leftover `.part` followed by a 416 response.

## Current review validation

- Finding #41 was reproduced through `_download_blob()` with a leftover partial file and
  a simulated registry 416 response. The function raised `HTTPError`, left the partial
  file in place, and did not create the final cache entry.
- The full existing test suite passed: 307 tests. No application source was changed.
- Track 1 (BinDiff), Track 2 (decompilation), Normal Track, and the remaining acquisition,
  triage, orchestration, caching, and reporting workflow were reviewed. No other new issue
  was confirmed in this pass.

### New findings from this review

#### Low severity

42. **Oracle Stage 1 drops classes added to an existing class-free JAR**
    - **Status:** Fixed (2026-10-26). Fixed by the same per-side class check as #20: a class-free prior side no longer fails decompilation, and the fixed side's classes report as added.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 1 / Java decompilation.
    - **Location:** `oracle/stage1.py` — changed-JAR loop; `_jar_has_classes()` and
      `_decompile_cached()` calls.
    - **Trigger:** A JAR exists on both sides, the prior archive is valid but contains no
      `.class` files, and the fixed archive contains one or more `.class` files.
    - **Failure scenario and observed behavior:** The loop checks only the fixed JAR for
      classes, then attempts to decompile both sides. Decompiling the prior JAR produces
      no Java source and raises `DecompileFailed`; the exception handler skips the entire
      JAR, including the classes available on the fixed side. A focused Stage 1
      reproduction used a prior JAR containing only `README.txt` and a fixed JAR
      containing `pkg/Foo.class`; it returned no readable class cards and one decompile
      error.
    - **Impact:** Newly introduced OJVM Java classes within an existing archive are not
      reported as added. The Stage 1 error indicates the result is partial, but users
      still do not receive the available fixed-side class inventory or diff.
    - **Suggested fix:** Check each JAR side independently for class entries and decompile
      only sides that contain classes. Treat a valid class-free side as an empty class
      map, then report the other side's classes as added. Add a test for an existing JAR
      gaining its first class.

## Current review validation

- Finding #42 was reproduced through `oracle.stage1.run()` with a valid prior JAR
  containing no classes and a fixed JAR containing `pkg/Foo.class`. The decompiler
  behavior was stubbed to model its documented/code-checked zero-output failure for a
  class-free archive; Stage 1 emitted no class card and recorded one error.
- Review coverage included Track 1 (BinDiff), Track 2 (C/Java decompilation), Normal
  Track, and the remaining acquisition, triage, orchestration, caching, and reporting
  workflow. No other new issue was confirmed.
- No application source was changed. The full test suite was not rerun during this pass.

### New findings from this review

#### Low severity

43. **Standalone later-stage runs can analyze a stale Stage 0 change list**
    - **Status:** Fixed (2026-10-26). New `_result_state.py`: `run_pipeline()` runs triage first when the persisted Stage 0 result wasn't produced from these input trees. A backend Stage 1/2 called directly without `stage0` raises `RuntimeError` for a missing, stale or foreign Stage 0 result (`bound_stage0()`) instead of analyzing it. The comparison identity is stat-based (see its docstring for the same-clock-tick limitation).
    - **Status:** Fixed (2026-10-26). Follow-up: with the same preserved-stat edit, `stage0_is_current()` was true and `bound_stage0()` returned the old change list. Both now use the content-based identity. `pipeline.py` calls `_result_state` directly instead of through import-time aliases, so only one implementation is in effect.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — stage selection and persisted triage inputs.
    - **Location:** `oracle/stage1.py` — disk-load fallback for `stage0/changed_files.json`;
      `mssql/stage2.py`, `db2/stage2.py`, and `oracle/stage2.py` — equivalent Stage 0
      fallback; `pipeline.py` — `run_pipeline()` stage selection.
    - **Trigger:** Call `run_pipeline()` with Stage 1 or Stage 2 selected without also
      selecting triage, or call one of the affected backend stages directly, while reusing
      an output directory whose `stage0/changed_files.json` belongs to a previous input
      pair. The selected stage loads that file without checking which input directories
      produced it.
    - **Failure scenario and observed behavior:** A focused Oracle reproduction used
      different `rdbms/admin/demo.sql` files on the prior and fixed sides. Oracle triage
      detected one changed file. After the saved Stage 0 JSON was replaced with an empty
      change list, `run_pipeline(..., stages=("stage1",))` returned zero readable files
      and zero errors, silently omitting the SQL change. This differs from finding #37:
      here the stale Stage 0 data drives the analysis itself, rather than an old later-stage
      result merely remaining visible after a partial run.
    - **Impact:** API users running a later stage independently can receive an apparently
      clean result that reflects the previous pair's triage list, not the directories they
      supplied. The public CLI's `stage1` and `stage2` commands include triage first, so
      those standard commands do not take this path.
    - **Suggested fix:** Require or run fresh triage before later stages, or persist and
      validate the prior/fixed input identities alongside Stage 0 before reusing it. Reject
      a stale or unbound Stage 0 result instead of treating it as an empty change list.
      Add a regression test that reuses an output directory with a different input pair and
      invokes a later stage without triage.

## Current review validation

- The finding was reproduced through `pipeline.run_pipeline()` with Oracle input files:
  `oracle.triage.run()` found one changed readable file, but a Stage 1-only run using an
  empty persisted Stage 0 list emitted zero readable files and zero errors.
- The review covered Normal Track, Track 1 (BinDiff), Track 2 (C/Java decompilation), and
  the remaining acquisition, triage, orchestration, caching, and reporting workflow.
- No application code was changed. The full test suite was not rerun during that review;
  validation was focused on the stale-input behavior.

### New findings from this review

#### Low severity

44. **MSSQL download treats any resumed HTTP 416 as a complete installer**
    - **Status:** Fixed (2026-10-26). A 416 means the file is complete only if the server-reported size (from the 416, a 206 or the probe) equals the `.part` size, or, with no size known, the previous page in the same run ended exactly there. Otherwise the `.part` is discarded and the download restarts once. A `.part` longer than the file is discarded.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — MSSQL patch download and resume handling.
    - **Location:** `mssql/acquire.py` — `download()`.
    - **Trigger:** A `.part` file exists, the initial range probe does not provide a
      `Content-Range` total, and the subsequent resumed range request receives HTTP 416.
      This can occur when a partial file is invalid or the server cannot satisfy the
      requested byte range.
    - **Failure scenario and observed behavior:** With an incomplete `.part` file and
      mocked responses modeling a probe without `Content-Range` followed by HTTP 416,
      `download()` breaks out of its loop and unconditionally renames the partial file to
      the final installer path. A focused call returned the destination path, left the
      incomplete bytes as the final file, and removed the `.part` name. `acquire()` then
      sees that final path on retries and skips downloading it, so extraction repeatedly
      receives the same invalid installer.
    - **Impact:** A resumable MSSQL download can become a persistent acquisition failure
      until the user manually deletes the bad final installer. The app may repeatedly
      fail to carve cabinets or extract the engine instead of restarting the download.
    - **Suggested fix:** Do not treat HTTP 416 as completion unless the existing partial
      file is independently verified as complete (by known total length and preferably a
      trusted digest). Otherwise discard or restart the partial download, and avoid
      retaining an unverified final installer. Add tests for incomplete and complete
      partial files when a resumed request returns 416.

## Current review validation

- Reproduced through `mssql.acquire.download()` using an incomplete `.part` file, a
  probe response without `Content-Range`, and a resumed HTTP 416 response. The function
  promoted the incomplete bytes to the final installer path.
- Review coverage included Normal Track, Track 1 (BinDiff), Track 2 (decompilation), and
  the remaining acquisition, triage, orchestration, caching, and reporting workflow.
- No application code was changed. The full test suite passed: 307 tests. Validation of
  this finding was additionally focused on the MSSQL downloader behavior.

### New finding from this review

#### Medium severity

45. **Oracle silently accepts truncated static archives as complete**
    - **Status:** Fixed (2026-10-26). `ar_members()` validates magic, each header terminator, size field and body length, and raises `MalformedArchive`; Stage 2 reports the archive as `error` (counted in `failed`). Only a missing alignment byte after the last member is tolerated.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 2 archive-member analysis.
    - **Location:** `oracle/_ar.py` — `ar_members()` and `extract_o()`;
      `oracle/stage2.py` — `_archive_members()`.
    - **Trigger:** A changed Oracle `.a` archive is truncated in the middle of a member
      header or body. `ar_members()` stops parsing when fewer than 60 header bytes remain,
      and does not check that the declared member body and alignment byte are present.
    - **Failure scenario and observed behavior:** A focused Stage 2 run used a prior archive
      containing `common.o` and `victim.o` and a fixed archive whose valid `common.o` was
      followed by a truncated next-member header. The parser returned only `common.o`;
      Stage 2 reported `victim.o` as a normal removed member, reported zero failed binaries,
      and did not signal that the fixed archive was malformed. Thus archive corruption is
      indistinguishable from an intentional member removal.
    - **Impact:** Oracle Stage 2 can produce misleading member-level verdicts and present a
      partial archive analysis as successful. Reviewers may trust a false removal result
      and overlook that the archive could not be fully read.
    - **Suggested fix:** Validate every archive header, declared body length, and alignment
      boundary. Reject malformed or truncated archives and propagate a member/archive error
      into Stage 2's partial-failure reporting. Add regression cases for a short header, a
      body shorter than its declared size, and a missing alignment byte.

## Current review validation

- Reproduced through `oracle.stage2.run()` with a valid prior archive and a fixed archive
  truncated during the next member header. Stage 2 emitted a normal `removed` verdict for
  the missing parsed member and reported `counts.failed == 0`; `extract_o()` returned only
  the first member.
- Review coverage included Normal Track, Track 1 (BinDiff), Track 2 (decompilation), and
  the remaining acquisition, triage, orchestration, caching, and reporting workflow.
- No application code was changed. Validation was focused on the truncated-archive path;
  the full test suite was not rerun during this review.

### New finding from this review

#### Medium severity

46. **Track 1 caches a failed partial BinExport as a valid export**
    - **Status:** Fixed (2026-10-26). The export's exit code and Ghidra's `REPORT SCRIPT ERROR` / headless-abort markers are checked. The `.sha256` sidecar is removed before re-exporting, and any failure, timeout or interrupt deletes the export, so nothing partial is cached.
    - **Confidence:** Confirmed.
    - **Track:** Track 1 — Ghidra BinExport generation and cache.
    - **Location:** `_bindiff.py` — `ghidra_binexport()`, export subprocess and cache
      validation.
    - **Trigger:** Ghidra's export process fails after writing some non-empty output to
      the pre-created `.BinExport` path.
    - **Failure scenario and observed behavior:** The export subprocess return code is not
      checked. `ghidra_binexport()` considers any non-empty output successful and writes a
      `.sha256` sidecar containing the input binary's hash. A focused reproduction mocked
      an export failure (return code 2) that left non-empty invalid bytes: the function
      returned the export path, wrote the sidecar, and a second call reused the failed
      output without invoking Ghidra again.
    - **Impact:** Track 1 may pass an incomplete or invalid export to BinDiff and either
      report a secondary analysis failure or derive matches from a bad artifact. The
      cache sidecar makes the failure persistent across reruns until the cached export is
      removed.
    - **Suggested fix:** Check the export process status according to Ghidra's documented
      warning/exit behavior and validate the generated BinExport format before writing its
      cache sidecar. Remove the export and sidecar when validation fails; add a regression
      test where a failed subprocess leaves a non-empty partial file.

## Current review validation

- Reproduced by mocking Ghidra's export process to return a failure code after writing
  non-empty invalid bytes. The application treated the output as success, saved its input
  hash sidecar, and reused it on the next call without rerunning Ghidra.
- The full test suite passed: 307 tests. Coverage included Normal Track, Track 1 (BinDiff),
  Track 2 (decompilation), and the remaining acquisition, triage, orchestration, caching,
  and reporting workflow. No application code was changed.

### New finding from this review

#### Low severity

47. **MSSQL download can loop forever on an empty partial-content response**
    - **Status:** Fixed (2026-10-26). A 206 response with no data while bytes remain is an error (the `.part` is kept for a later resume). A 206 that starts at the wrong offset, an empty 200, and a final size mismatch are also errors.
    - **Confidence:** Confirmed.
    - **Track:** Remaining workflow — MSSQL patch download and resume handling.
    - **Location:** `mssql/acquire.py` — `download()`, range-request loop.
    - **Trigger:** The initial range probe supplies a total size, but a subsequent range
      request returns HTTP 206 with an empty body while the partial file is still shorter
      than that total.
    - **Failure scenario and observed behavior:** The loop updates `have` from the partial
      file size. With no response bytes, `have` does not advance, and because `total` is
      known the `total is None and got < chunk` termination condition does not apply.
      A focused reproduction returned an empty 206 for each request and observed the
      downloader issue `bytes=0-9` repeatedly, retain a zero-byte `.part` file, and never
      produce a final installer. The reproduction bounded the mock after repeated
      identical requests to avoid an actual endless loop.
    - **Impact:** A malformed or prematurely empty range response can leave MSSQL
      acquisition running indefinitely, repeatedly requesting the same bytes and blocking
      the comparison from starting.
    - **Suggested fix:** Treat a 206 response that yields no bytes while bytes remain as
      an explicit download failure, or add a bounded retry policy that detects no
      progress. Do not promote the partial file; add a regression test asserting the
      downloader exits with a clear error after an empty known-total range response.

## Current review validation

- Reproduced using a mocked probe advertising a 10-byte total and repeated empty 206
  responses. Every subsequent request used the same `bytes=0-9` range; the `.part` file
  remained empty and no final file was produced.
- The full test suite passed: 307 tests. Review coverage included Normal Track, Track 1
  (BinDiff), Track 2 (decompilation), and the remaining acquisition, triage,
  orchestration, caching, and reporting workflow. No application code was changed.

### New finding from this review

#### Major severity

48. **DB2 triage trusts an acquisition manifest after an extracted input is modified**
    - **Status:** Fixed (2026-10-26). After pruning, the acquisition manifest records a content snapshot (path, size, SHA-256) of each remaining tree. Triage takes the fast path only while both trees still match it, and otherwise does a full walk. That walk no longer reports "pruned against a different partner" for trees pruned against each other, since walking them is sound.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — DB2 Stage 0 triage and acquisition-manifest fast path.
    - **Location:** `db2/triage.py` — `run()`; `_acquire_state.py` —
      `manifest_applies()`.
    - **Trigger:** A user or another process changes a file under an acquired DB2 version
      directory after acquisition, then reuses the output directory containing the
      acquisition manifest and sidecar. The input paths and extraction IDs remain the
      same.
    - **Failure scenario and observed behavior:** `manifest_applies()` checks canonical
      tree paths and the sidecar extraction IDs, but does not verify current tree
      contents against the manifest. A focused reproduction created two acquired-tree
      sidecars and a valid bound manifest for identical `config.sql` files, then changed
      the fixed file from `SELECT 1;` to same-length `SELECT 2;`. `db2.triage.run()`
      applied the old manifest and returned `identical: 1`, `content_changed: 0`, and
      `errors: 0`. Removing the manifest forced the full walk, which correctly returned
      `content_changed: 1`.
    - **Impact:** A real source or code change made after extraction can be excluded from
      Stage 1/Stage 2 inputs while triage reports a clean, error-free comparison. This is
      distinct from the earlier stale-manifest issue involving different input trees:
      here the manifest paths and extraction IDs match, but the contents have changed.
    - **Suggested fix:** Validate that the current trees still match a complete
      content-level snapshot before using the manifest fast path; record enough
      per-file identity to detect modifications, additions, and removals. If validation
      fails, discard the fast path and perform a full comparison, or report that the
      acquired trees must be re-acquired.

## Current review validation

- Reproduced finding #48 through `db2.triage.run()` using same-length SQL inputs and
  unchanged tree paths/extraction IDs. The bound manifest hid the change with zero
  errors; a full walk after removing the manifest detected it.
- The full test suite passed: 307 tests. Review coverage included Normal Track, Track 1
  (BinDiff), Track 2 (decompilation), and the remaining acquisition, triage,
  orchestration, caching, and reporting workflow. No application code was changed.

### New finding from this review

#### Major severity

49. **DB2 full-walk triage misses same-size changes in generic files**
    - **Status:** Fixed (2026-10-26). Every same-size, relevant non-ELF (or unparseable-ELF) common file is now SHA-256 compared, not only dependency/script/text kinds.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — DB2 Stage 0 full-tree comparison.
    - **Location:** `db2/triage.py` — `run()`, non-ELF comparison path.
    - **Trigger:** The comparison uses manually supplied or otherwise unmanifested trees
      (including when a manifest does not apply), and a common file that is not recognized
      as an ELF, JAR, script, or text file changes bytes without changing its size.
    - **Failure scenario and observed behavior:** For non-ELF files, the full walk compares
      size first and hashes equal-size files only when their kind is `dependency`, `script`,
      or `text`. A focused reproduction compared `payload.bin` containing `AAAA` against
      the same-size file containing `BBBB`. `db2.triage.run()` returned `identical: 1`,
      `content_changed: 0`, and `errors: 0`, with empty `content_changed` and `errors`
      lists.
    - **Impact:** A changed binary or other generic payload can disappear from the
      comparison entirely, with Stage 0 reporting a clean, error-free result. This is
      separate from finding #48: #48 concerns an outdated acquisition manifest after a
      tree is modified; this finding occurs in the full-walk path even without a valid
      manifest.
    - **Suggested fix:** Hash same-size common files not covered by ELF section comparison
      before classifying them as identical. If some file classes are intentionally not
      checked for performance reasons, surface that limitation explicitly instead of
      counting them as identical. Add a regression test with distinct same-size generic
      file contents.

## Current review validation

- Reproduced finding #49 through `db2.triage.run()` on manually supplied trees containing
  distinct same-size `payload.bin` files; triage reported one identical file, no changes,
  and no errors.
- The full test suite passed: 307 tests. Review coverage included Normal Track, Track 1
  (BinDiff), Track 2 (decompilation), and the remaining acquisition, triage,
  orchestration, caching, and reporting workflow. No application code was changed.

### New finding from this review

#### Major severity

50. **Oracle Stage 1 silently hides changes when both wrapped PL/SQL payloads fail to unwrap**
    - **Status:** Fixed (2026-10-26). The unwrap-failure marker carries a digest of the unit's payload, and Stage 1 records an error when failed units differ between sides. Also fixed while verifying: text after a wrapped unit's `/` terminator (e.g. a changed GRANT) used to be swallowed with the unit and is now kept.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — Oracle Stage 1 wrapped PL/SQL comparison.
    - **Location:** `oracle/unwrap.py` — `unwrap_text()`; `oracle/stage1.py` — `_read_source()`
      and `run()`'s readable-file comparison.
    - **Trigger:** A changed wrapped PL/SQL file has payloads on both sides that the
      wrapper decoder cannot unwrap, such as an unsupported wrapper form or damaged
      payload.
    - **Failure scenario and observed behavior:** `unwrap_text()` replaces each
      undecodable unit with the same `-- [unwrap failed]` marker. A focused end-to-end
      reproduction supplied a changed package whose prior and fixed wrapped payloads
      differed, but both were undecodable. `oracle.stage1.run()` reported
      `wrapped: 1`, `errors: 0`, and `readable_changed: 0`, and emitted no readable
      comparison. The only differing data had been discarded before the comparison.
    - **Impact:** Stage 1 can report a clean result for a changed wrapped security
      package even though it could not inspect the source on either side. An unsupported
      wrapper format can therefore hide changes across all affected wrapped units.
    - **Suggested fix:** Preserve and compare the original wrapped payload when decoding
      fails, or record an explicit per-file/per-unit analysis error and ensure that
      `errors`/partial-failure reporting prevents the result from appearing complete.
      Add a regression test with two different undecodable payloads.

## Current review validation

- Reproduced finding #50 through `oracle.stage1.run()` using different wrapped payloads
  that both fail decoding. Stage 1 emitted no readable file and reported zero errors.
- Review coverage included Normal Track, Track 1 (BinDiff), Track 2 (decompilation), and
  the remaining acquisition, triage, orchestration, caching, and reporting workflow.
- The full test suite passed: 307 tests. No application source was changed.

### New findings from this review

#### Medium severity

51. **DB2 extraction silently drops hardlinked archive members**
    - **Status:** Fixed (2026-10-26). All three DB2 extractors write hard-link members as copies of their target; a layer link whose target was skipped gets a second pass over that layer; an unresolvable link raises instead of silently dropping the path.
    - **Confidence:** Confirmed.
    - **Track:** Normal Track — DB2 acquisition (OCI layer and fixpack tar extraction).
    - **Location:** `db2/acquire.py` — the layer-flattening loop and `_extract_tar()`; both
      write a member only when `m.isfile()`.
    - **Trigger:** An image layer or fixpack tar stores a file as a hard link (tar type
      `LNKTYPE`) to another member, which `tar` and container builders do for files that
      share an inode, such as versioned shared-library names.
    - **Failure scenario and observed behavior:** `TarInfo.isfile()` is true only for
      regular members, so a hard-link member is skipped with no error. A focused
      reproduction extracted a tar containing `lib/libdb2.so.1` (regular) and
      `lib/libdb2.so` (hard link to it); only `lib/libdb2.so.1` was written.
    - **Impact:** The linked path is missing from the extracted tree. If the link exists on
      only one side, or the two sides link it differently, triage reports it as
      added/removed or omits it, and Stage 2 never analyzes the binary under that name.
      The run reports no error.
    - **Suggested fix:** For `m.islnk()` members, copy the already-extracted link target
      (resolved through `_member_rel`/`_safe_out`, staying inside the destination), or
      record an explicit extraction error. Add a regression test with a hard-link member.

#### Low severity

52. **MSSQL `decompile_function()` raises `TypeError` before Ghidra is launched**
    - **Status:** Fixed (2026-10-26). `_one_func_pe()` lays out the chunks with Stage 2's `_extract_func_bytes()` (the #25 layout) and adds the partial-C note. `decompile_function()` now reads PDBs from the shared `_GLOBAL_PDB_CACHE` Stage 2 fills. It used to look in `<out>/pdb`, so even without the TypeError every function would have come back unsymbolized.
    - **Confidence:** Confirmed.
    - **Track:** Track 2 — MSSQL on-demand decompilation helper.
    - **Location:** `mssql/decompile.py` — `_one_func_pe()` and `decompile_function()`.
    - **Trigger:** Any call to `mssql.decompile.decompile_function()` for a symbol that is
      found on at least one side.
    - **Failure scenario and observed behavior:** `mssql/stage2.py`'s `_func_map()` returns
      `{name: (primary_rva, chunks)}`, where `chunks` is a list of `(rva, bytes)` pairs.
      `_one_func_pe()` returns that list as if it were code bytes, and `_dc.decompile_pair()`
      then fails writing it to a file. A focused reproduction, with a realistic `_func_map`
      result and Ghidra subprocess launches blocked, raised
      `TypeError: a bytes-like object is required, not 'list'`.
    - **Impact:** No current code path calls this helper (Stage 2's `--decompile` uses its own
      path), so the pipeline is unaffected today. Any API or future caller always fails. The
      DB2 equivalent in `db2/decompile.py` does not have this defect.
    - **Suggested fix:** Either remove the unused helper, or reuse Stage 2's chunk handling
      (and its fix for finding #25) rather than passing raw chunks. Add a test that runs it with
      a mocked Ghidra.

## Current review validation

- Reproduced finding #51 through `db2.acquire._extract_tar()` with a tar containing a regular
  member and a hard-link member; only the regular member was extracted, with no error.
- Reproduced finding #52 through `mssql.decompile.decompile_function()` with a stubbed
  symbolizer and `_func_map`; it raised `TypeError` before any Ghidra process was started.
- No application source was changed.

## Fix validation (findings #18, #20, #23, #25, #27, #30, #42, #45, #49, #50, #51)

- Regression tests: `tests/test_silent_loss_fixes.py` (44 tests). Patching each fix's old
  behaviour back in makes that finding's tests fail; with the fixes they pass.
- Full suite: 351 tests passed (307 existing + 44 new).
- End-to-end CLI runs on synthetic inputs: Oracle exits 3, with the undecodable wrapped
  package reported as a changed card plus an error and the truncated archive as `error`.
  DB2 reports the same-size `payload.bin` change and diffs `dup [a.c]`.
- Not covered: the #25 layout was checked with Capstone, but not with a live Ghidra
  decompile.

## Fix validation (findings #19, #21, #31, #32, #41, #44, #46, #47)

- Regression tests: `tests/test_acquire_cache_integrity.py` (34 tests), with fake HTTP
  servers, registry, PDB server and Ghidra subprocesses. Patching each pre-fix function back
  in makes that finding's tests fail (the #47 test stops the old infinite loop with an
  assertion).
- Full suite: 385 tests passed.
- End-to-end: a DB2 CLI run with `meta.json` = `[1, 2]` warns and exits 0 (it used to
  abort Stage 2).
- Not covered: no real network download was run. The MSF size check was not tried on a
  real PDB (none on this machine), so it only rejects a file smaller than its superblock
  declares, never a larger or non-MSF file.

## Fix validation (findings #24, #28, #35, #36, #37, #38)

- Regression tests: `tests/test_partial_result_reporting.py` (26 tests). Patching each
  fix's old behaviour back in makes that finding's tests fail.
- Full suite: 411 tests passed.
- End-to-end CLI runs:
  - #24: a real ACL-denied prior folder (icacls) gives exit 3 with
    `rdbms/secret -> prior tree could not be indexed`, and its file is not misreported
    as added.
  - #37: after a full run, a same-length input change and a `stage1`-only run, `show`
    hides the old Stage 2 result with a note.
  - #38: `--fixed-kb " KB5084815 "` is accepted, while `KBKB5084815` fails with a clear
    error and exit 1.
- Found and fixed during review (#37): a digest of the stage0 JSON alone was not enough,
  because a same-size content change produced identical triage JSON. The identity now
  also covers the input trees.

## Fix validation (findings #22, #26, #29, #33, #34, #39, #40, #43, #48, #52)

- Regression tests: `tests/test_identity_and_inputs.py` (26 tests; #33 uses a real CRC-32
  collision found by a seeded birthday search). Putting each fix's old behaviour back in
  makes that finding's tests fail. #34's old loop was also checked directly: it ran nothing
  for `iter(["stage1"])`.
- Full suite: 437 tests passed in six consecutive runs.
- Measured on the bundled tools: the BinExport, decompiler and CFR identities each take
  17-59 ms.
- End-to-end CLI runs: Oracle and DB2 `run` exit 0, and earlier fixes still show in the
  results.
- Found and fixed during review:
  - The first versions memoized the content identities by file stats, which defeated the
    same-size, same-timestamp case they exist to catch (#22, #39). The memos were removed.
  - The #48 snapshot was first stat-based. NTFS timestamps update in coarse ticks, so a
    quick same-length edit kept size and mtime and slipped through (a flaky test exposed
    this). It is now content-based.
  - #52 also needed the PDB cache path fix described in its status line.

## Fix validation (follow-ups to #21, #37, #43: preserved-stat edits)

- Regression tests: `tests/test_preserved_stat_edits.py` (6 tests). Each replaces a file
  with different bytes of the same size and restores its original timestamps, then checks
  that the change is detected. With the previous stat-based `_layer_ok()` /
  `comparison_identity()` put back, each finding's tests fail. The earlier #37/#43 tests
  no longer move mtime forward artificially, so same-tick edits are covered too.
- Full suite: 443 tests passed in five consecutive runs.
- End-to-end CLI run: full run, then a preserved-stat edit, then `stage1`. `show` hides
  the old Stage 2 result with a note, and Stage 1 diffs the current content.
- Cost: the comparison identity now reads both input trees in full on every triage run,
  and once more for a standalone later stage. On this machine that was about 90 MiB/s
  (2 x 1 GiB of small files in a OneDrive folder took 22-26 s; raw SHA-256 runs at
  ~450 MiB/s, so per-file I/O dominates).
