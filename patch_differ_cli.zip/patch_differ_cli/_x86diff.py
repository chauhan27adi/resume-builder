"""Shared x86-64 function-diff normalization for Stage 2 (capstone).

Both the DB2 (ELF/.symtab) and MSSQL (PE/.pdata+PDB) Stage-2 backends slice a binary
into per-function byte ranges, then need to tell a *real logic change* apart from
recompilation/relink noise (branch targets, RIP-relative displacements, register
allocation, and __LINE__ renumbering all churn between builds without any behaviour
change). This module is that normalizer, factored out of the original DB2 stage2 so
there is one implementation to reason about.

  norm(md, addr, code) -> (lines, shape, imms)
      lines  — mnemonic + operands, regs->R<bits>, branch/call target->L,
               [rip+disp]->m<bits>[rip]; real (non-address) immediates, small struct
               offsets, operand widths and fs/gs overrides are KEPT.
      shape  — same but every immediate AND every small struct-offset displacement
               blanked (structural fingerprint) — a member access through a shifted
               struct layout must look identical in shape to the same access before
               the shift, or classify()'s pS==fS churn test can never see it.
      imms   — ordered (kind, value) pairs for every kept immediate ("i") and kept
               struct-offset displacement ("d"), interleaved in disassembly order (for
               the __LINE__-renumber / offset-shift churn test; shape equality already
               guarantees same-index entries share the same kind on both sides). The
               kind tag lets classify() require a dominant-shift pattern to hold
               independently per kind, so one real "i" (or "d") change can't be swept
               into "churn" merely by riding alongside an unrelated dominant "d" (or
               "i") shift in the same function.

  classify(pL,pS,pI, fL,fS,fI) -> 'same' | 'churn' | 'const' | 'code'
      'same'  reloc/reg noise only; 'churn' a __LINE__-renumber or struct-offset-shift
      cluster; 'const'/'code' are the real changes worth surfacing.
"""
import difflib
from collections import Counter

try:
    import capstone
    from capstone import Cs, CS_ARCH_X86, CS_MODE_64
    from capstone.x86 import (X86_OP_IMM, X86_OP_MEM, X86_OP_REG,
                              X86_REG_RIP, X86_GRP_JUMP, X86_GRP_CALL)
    AVAILABLE = True
except Exception:                       # pragma: no cover - capstone missing
    AVAILABLE = False


def md():
    m = Cs(CS_ARCH_X86, CS_MODE_64)
    m.detail = True
    return m


def _width(tag, size):
    """'R64' / 'm32' — an operand token carrying its width in bits (bare tag if unknown)."""
    return f"{tag}{size * 8}" if size else tag


def norm(m, addr, code):
    lines, shape, imms = [], [], []
    for ins in m.disasm(code, addr):
        br = X86_GRP_JUMP in ins.groups or X86_GRP_CALL in ins.groups
        ops, shops = [], []
        for op in ins.operands:
            if op.type == X86_OP_IMM:
                if br:
                    ops.append("L"); shops.append("L")
                else:
                    ops.append("i%x" % (op.imm & 0xffffffffffffffff)); shops.append("i")
                    imms.append(("i", op.imm))
            elif op.type == X86_OP_MEM:
                mm = op.mem
                # bugs.md #30: the access width and an fs/gs override are semantic (a
                # dword->qword load, a TLS access), so both are kept in lines AND shape.
                # In 64-bit mode an explicit ds/es/ss/cs override is ignored by the CPU (and
                # 3e doubles as a branch hint), so only fs/gs count.
                sreg = ins.reg_name(mm.segment) if mm.segment else None
                pre = (f"{sreg}:" if sreg in ("fs", "gs") else "") + _width("m", op.size)
                if mm.base == X86_REG_RIP:
                    ops.append(pre + "[rip]"); shops.append(pre + "[rip]")
                else:
                    d = mm.disp
                    # CRIT-NT-3: shops (shape's operand) used to embed this same small disp
                    # value, so a struct-layout shift (any member access at this slot moving
                    # by a few bytes — an ordinary recompile artifact whenever an unrelated
                    # field is added/removed/reordered elsewhere in the struct) changed shape
                    # itself, making classify() see pS != fS and misclassify pure offset churn
                    # as "code". shops now always blanks the disp (mirrors the IMM branch
                    # above, which never puts the real value in shops either); the real value
                    # is still kept in ops/lines ("small struct offsets are KEPT", per this
                    # module's docstring) and also fed into `imms` so classify()'s existing
                    # delta-based churn test — built for __LINE__-renumber noise — can now see
                    # and catch uniform small offset shifts too, the same way it already
                    # catches uniform small immediate shifts.
                    if abs(d) <= 0x2000:
                        seg = "[R+R*%d+d%x]" % (mm.scale, d & 0xffffffffffffffff)
                        imms.append(("d", d))
                    else:
                        seg = "[R+R*%d+D]" % mm.scale
                    ops.append(pre + seg)
                    shops.append(pre + "[R+R*%d+D]" % mm.scale)
            elif op.type == X86_OP_REG:
                # register ALLOCATION is build noise, register WIDTH is not (#30): a
                # 32->64-bit compare/length is a classic integer-overflow fix
                r = _width("R", op.size)
                ops.append(r); shops.append(r)
            else:
                ops.append("?"); shops.append("?")
        lines.append(ins.mnemonic + " " + " ".join(ops))
        shape.append(ins.mnemonic + " " + " ".join(shops))
    return lines, shape, imms


# conditional branches (a fix usually ADDS one to guard a path); jmp/call excluded.
_CJMP = frozenset((
    "je", "jne", "jz", "jnz", "jb", "jbe", "jae", "ja", "jl", "jle", "jg", "jge",
    "js", "jns", "jp", "jnp", "jo", "jno", "jc", "jnc", "jcxz", "jecxz", "jrcxz",
    "cmov" ))  # cmov* handled by prefix match below


def _mnem(line):
    return line.split(" ", 1)[0]


# Compiler/runtime security routines. A call to one of these appearing in the FIXED build
# but not the prior is a strong marker of a memory-safety / validation fix at that site —
# and it's self-evident (no advisory text needed), which is exactly MSSQL's gap. Two tiers:
# HARD = near-certain security failure/guard routines; SOFT = hardened (bounds-checked) CRT
# swaps and parameter validation (weaker — normal new code can also call these).
import re as _re
_HARD_INTRINSICS = _re.compile(
    r"_?_report_rangecheckfailure|_?_report_gsfailure|__GSHandlerCheck|_?_security_check_cookie|"
    r"__fastfail|RtlFailFast|_?_report_securityfailure|__failfast|"       # MSVC / Windows
    r"__stack_chk_fail|__chk_fail\b|__memcpy_chk|__memmove_chk|__strcpy_chk|__strcat_chk|"
    r"__sprintf_chk|__snprintf_chk|__stack_smash",                        # GCC / glibc / DB2
    _re.I)
_SOFT_INTRINSICS = _re.compile(
    r"\b(mem(cpy|move|set)|str(n?cpy|n?cat|cpy)|w?cs(n?cpy|n?cat)|_?sn?printf|_?vsn?printf)_s\b|"
    r"_?invalid_parameter(_noinfo)?|ex_handle_invalid_parameter|RaiseException|"
    r"_wassert|__assert_fail|__cxa_throw",
    _re.I)


def is_security_intrinsic(name):
    return bool(name and (_HARD_INTRINSICS.search(name) or _SOFT_INTRINSICS.search(name)))


def _intrinsic_weight(name):
    if _HARD_INTRINSICS.search(name):
        return 8
    return 4


def _short_sym(n):
    return (n[:44] + "…") if len(n) > 45 else n


def call_targets(m, addr, code, name_at):
    """Resolved callee names for DIRECT (rel32) calls in a function. Indirect/IAT calls have
    no static target and are skipped. `name_at(rva)->name|None` resolves a target RVA (the
    PE Symbolizer, or a DB2 symtab reverse map). Returns a list (multiset)."""
    if name_at is None or not AVAILABLE:
        return []
    out = []
    for ins in m.disasm(code, addr):
        if X86_GRP_CALL not in ins.groups:
            continue
        ops = ins.operands
        if len(ops) == 1 and ops[0].type == X86_OP_IMM:   # direct near call -> abs target RVA
            nm = name_at(ops[0].imm)
            if nm:
                out.append(nm)
    return out


def rip_data_targets(m, addr, code):
    """Parallel to norm(): for each disassembled instruction, the absolute vaddr of its
    RIP-relative DATA reference (mem base==RIP, and NOT a branch/call target), else None.
    norm() collapses these to '[rip]' and throws the target away; this recovers it so a
    data-section diff can follow a code xref (lever 3). The returned list aligns 1:1 with
    norm()'s `lines`, so SequenceMatcher opcodes over the code diff index straight into it."""
    if not AVAILABLE:
        return []
    out = []
    for ins in m.disasm(code, addr):
        tgt = None
        if not (X86_GRP_JUMP in ins.groups or X86_GRP_CALL in ins.groups):
            for op in ins.operands:
                if op.type == X86_OP_MEM and op.mem.base == X86_REG_RIP:
                    tgt = (ins.address + ins.size + op.mem.disp) & 0xffffffffffffffff
                    break
        out.append(tgt)
    return out


def _is_cjmp(m):
    return m in _CJMP or m.startswith("cmov") or (m.startswith("set") and len(m) > 3)


def _has_imm(line):
    """True if a normalized line has a real (non-address) immediate operand — norm() emits
    those as an 'i<hex>' token. A newly-inserted `cmp/test R, i<const>` is a new value/size/
    table-entry guard (e.g. DB2's added `cmp reg,0x55b` codepage check)."""
    parts = line.split()
    return any(t[:1] == "i" and len(t) > 1 and all(c in "0123456789abcdef" for c in t[1:])
               for t in parts[1:])


_MIN_RELOCATED_BLOCK = 2   # single lines (esp. "call L") collide with unrelated deletions too easily


_RELOCATION_WORK_BUDGET = 200_000   # line comparisons per fix_signature() call; past it, stop discounting


def _index_removed(removed_runs):
    idx = {}
    for ri, run in enumerate(removed_runs):
        for k, line in enumerate(run):
            idx.setdefault(line, []).append((ri, k))
    return idx


def _genuinely_new(block, removed_runs, idx, budget, used):
    """Lines of an inserted run NOT explained as relocated code: pieces of at least
    _MIN_RELOCATED_BLOCK lines that appear verbatim and contiguously in a prior-side deleted
    run are dropped (same code moved, not added); everything else — including a relocated
    guard's neighbours that really are new — is kept and still scored.

    `used` is a set of (run, offset) prior-side positions already claimed by an earlier
    match in this call: each deleted line can explain at most ONE relocated line, so a
    single deleted check can't "explain away" several genuinely added copies of it
    (IMP-NT-2 follow-up). `budget` is a one-item list holding the remaining comparison
    budget (shared across the whole call); once spent, remaining lines are conservatively
    treated as new, which is the pre-fix behaviour."""
    out, p = [], 0
    while p < len(block):
        best, best_at = 0, None
        if budget[0] > 0:
            for ri, k in idx.get(block[p], ()):
                run = removed_runs[ri]
                n = 0
                while (p + n < len(block) and k + n < len(run)
                       and (ri, k + n) not in used and block[p + n] == run[k + n]):
                    n += 1
                budget[0] -= n + 1
                if n > best:
                    best, best_at = n, (ri, k)
                if budget[0] <= 0:
                    break
        if best >= _MIN_RELOCATED_BLOCK:
            ri, k = best_at
            used.update((ri, k + i) for i in range(best))
            p += best
        else:
            out.append(block[p])
            p += 1
    return out


def fix_signature(prior_lines, fixed_lines, added_intrinsics=None, opcodes=None):
    """Heuristic 'does this change look like a security FIX?' from the normalized-instruction
    diff. Returns (score:int, reasons:list[str]); higher = more fix-shaped.

    `opcodes` — optional precomputed SequenceMatcher.get_opcodes() for (prior,fixed). Pass it
    when the caller already built the matcher (e.g. for the similarity ratio) to avoid a second
    O(n^2) diff pass over the same inputs.

    Key idea: a security fix is a SMALL block of genuinely NEW code — an added guard/bounds
    check, an integer-overflow check, or a validation/throw call. Whole-engine recompilation
    instead produces lots of *replaced* instructions (same logic, different registers/
    relocations). So we score only the purely INSERTED instructions (difflib 'insert'
    opcodes) plus one out-of-band signal:

      added_intrinsics — callee names (from `call_targets`) called in the FIXED build but not
      the prior that match `is_security_intrinsic`. This is the strongest, most self-evident
      signal (e.g. a newly-added `__report_rangecheckfailure`) and needs no advisory text."""
    inserts = []
    if fixed_lines:
        ops = opcodes if opcodes is not None else difflib.SequenceMatcher(
            a=prior_lines, b=fixed_lines, autojunk=False).get_opcodes()
        # CRIT-NT-6: difflib has no notion of a block that merely MOVED — compiler basic-block
        # reordering / hot-cold splitting / PGO changes relocate an unchanged guard, which
        # difflib reports as 'delete' at the old position + 'insert' at the new one. Scoring
        # that insert as new code manufactures a false fix-signature (which then bypasses the
        # emit cap). Source ranges = prior lines difflib says were DELETED only. Never 'equal'
        # ones (a genuinely NEW copy of a guard that already exists unchanged elsewhere is
        # still new), and never 'replace' ones (IMP-NT-2): a replaced run was rewritten in
        # place — its fixed-side counterpart is right there — so it's no evidence those lines
        # moved, and normalization (regs->R, targets->L) makes 2-line pieces like
        # "test R R / je L" so common that matching against unrelated rewritten code hid
        # genuinely added NULL checks.
        removed_runs = [prior_lines[i1:i2] for tag, i1, i2, j1, j2 in ops
                        if tag == "delete"]
        reloc_idx = _index_removed(removed_runs)
        budget, used = [_RELOCATION_WORK_BUDGET], set()
        for tag, i1, i2, j1, j2 in ops:
            if tag == "insert":                 # genuinely new code, not churn
                inserts += _genuinely_new(fixed_lines[j1:j2], removed_runs, reloc_idx,
                                          budget, used)
    intr = list(dict.fromkeys(added_intrinsics or []))   # dedup, keep order
    if not inserts and not intr:
        return 0, []                            # pure replace/delete = recompilation churn
    ins_cjmp = sum(1 for l in inserts if _is_cjmp(_mnem(l)))
    ins_cmp = sum(1 for l in inserts if _mnem(l) in ("cmp", "test"))
    ins_call = sum(1 for l in inserts if _mnem(l) == "call")
    ins_ovf = sum(1 for l in inserts if _mnem(l) in ("jo", "jno"))  # overflow-flag jump
    # newly-added comparison against a constant = a new size/value/table-entry guard
    ins_constchk = sum(1 for l in inserts if _mnem(l) in ("cmp", "test") and _has_imm(l))
    guards = min(ins_cmp, ins_cjmp)
    if not (intr or guards or ins_cjmp or ins_call or ins_ovf or ins_constchk):
        return 0, []                            # inserted code has no check/call — not a fix
    n = len(inserts)

    score, reasons = 0, []
    if intr:                                    # strongest, self-evident signal (tiered)
        score += min(sum(_intrinsic_weight(x) for x in intr), 24)
        reasons.append("added call to " + ", ".join(_short_sym(x) for x in intr[:3]))
    if ins_ovf:
        score += 4
        reasons.append("added integer-overflow check (jo/jno)")
    if ins_constchk:
        score += 3
        reasons.append(f"added {ins_constchk} constant check(s) (new size/value guard)")
    if guards:
        score += 6
        reasons.append(f"inserted {guards} guard(s) (compare+branch)")
    elif ins_cjmp:
        score += 2
        reasons.append(f"inserted {ins_cjmp} branch(es)")
    if ins_call:
        score += 2 * min(ins_call, 3)
        reasons.append(f"inserted {ins_call} call(s) (validation/throw?)")
    if 0 < n <= 10:
        score += 4
        reasons.append("small surgical insertion")
    elif n <= 30:
        score += 1
    elif n > 100:
        score -= 4            # large new block — less likely a single targeted guard
    return max(0, score), reasons


def classify(pL, pS, pI, fL, fS, fI):
    if pL == fL:
        return "same"
    if pS == fS:                                        # only kept VALUES differ
        if len(pI) == len(fI):
            # pI/fI entries are (kind, value) pairs — kind is "i" (a real immediate) or
            # "d" (a kept small struct-offset displacement). Group deltas BY KIND rather
            # than pooling them: a struct-layout shift (many "d" deltas, uniform) must
            # never be able to launder an unrelated, genuine single-constant change (e.g.
            # a lone "i" delta from an off-by-one correction) into "churn" just because it
            # rode along in the same function. Requiring every kind that has differing
            # values to INDEPENDENTLY look like a dominant uniform shift means one real,
            # isolated change (too few same-kind deltas, or no dominant pattern within its
            # own kind) blocks the whole function from being swept into "churn" — it falls
            # through to "const" instead, which is still surfaced (only "same"/"churn" are
            # skipped by callers).
            by_kind = {}
            for (ka, a), (kb, b) in zip(pI, fI):
                if ka != kb:
                    by_kind = None
                    break
                if a != b:
                    by_kind.setdefault(ka, []).append(b - a)
            if by_kind:
                if all(len(deltas) >= 3 and all(abs(d) <= 256 for d in deltas)
                       and Counter(deltas).most_common(1)[0][1] / len(deltas) >= 0.6
                       for deltas in by_kind.values()):
                    return "churn"                       # every present kind is a dominant shift
        return "const"                                  # few/large/non-uniform changes = meaningful
    return "code"                                       # structural change