"""Shared on-demand C-decompile engine for Stage 2 (both backends).

The Stage-2 assembly diff stays canonical; this is an additive, best-effort readable-C
view of ONE function. Importing a 50-330 MB engine binary into Ghidra is intractable, so we
carve the single function's exact bytes into a tiny raw blob and decompile just that via
Ghidra headless (ghidra/DecompileFunc.java). This module is the format-agnostic core — carve
two blobs, run one JVM over both, read prior.c/fixed.c, normalize address churn. Each backend
supplies the per-format "get one function's bytes" step (ELF .symtab / PE .pdata+PDB).

Cost is Ghidra JVM startup, not analysis; callers cache the result so re-opens are instant.
"""
import glob
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time

from .db2._paths import lp
from . import tool_paths as tp

_BASE = 0x100000                     # blob load base (nonzero; intra-fn control flow is relative)
_TIMEOUT = 360
_SCRIPT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "db2", "ghidra")


# Defined once in tool_paths.py and re-exported here — see that module's docstring and
# _bindiff.py's "Exceptions" section for why this isn't defined separately per module.
GhidraNotConfigured = tp.GhidraNotConfigured


def analyze_headless():
    """Path to analyzeHeadless(.bat) or None if Ghidra isn't configured."""
    return tp.analyze_headless()


def available():
    return analyze_headless() is not None


def _run_tool(cmd, timeout=None, env=None, log_path=None):
    """The one place this module launches Ghidra (tests replace it). Kills the whole process
    tree on timeout — see tool_paths.run_tool() (db2_bugs.md DB2-13)."""
    return tp.run_tool(cmd, timeout=timeout, env=env, log_path=log_path)


# Names Ghidra makes up from an ADDRESS, which shifts between builds (db2_bugs.md DB2-16):
# FUN_/DAT_/LAB_/PTR_/... with or without a leading underscore (_DAT_<addr> is a
# dereferenced global), func_0x<addr> (a call to code outside the blob), and the address
# suffix of string labels s_<text>_<addr>. caseD_<n> is deliberately NOT here: <n> is the
# switch case VALUE, a real constant (it used to be collapsed, hiding a changed case).
_ADDR_LABEL = re.compile(r"(?<![A-Za-z0-9])(_?)(FUN|DAT|LAB|SUB|UNK|EXT|PTR|switchD)_"
                         r"[0-9a-fA-F]+\b")
_FUNC_0X = re.compile(r"\bfunc_0x[0-9a-fA-F]+\b")
_STR_LABEL = re.compile(r"\b([su]_\w*?)_[0-9a-fA-F]{8,16}\b")
_NORM_VERSION = "n2"            # part of the cache key: cached pseudo-C is normalised text
# A call or jump target Ghidra could only name by its address.
_TARGET = re.compile(r"(?<![A-Za-z0-9_])(?:FUN_|func_0x)([0-9a-fA-F]+)\b")


def norm_c(text):
    """Collapse Ghidra's synthetic address-bearing labels (FUN_00xxxx / DAT_00xxxx …) — the
    biggest prior-vs-fixed churn since addresses shift between builds — to a stable token.
    Real constants (e.g. buffer sizes, switch case values) are KEPT so a genuine fix still
    shows."""
    text = _ADDR_LABEL.sub(lambda m: m.group(1) + m.group(2) + "_", text or "")
    text = _FUNC_0X.sub("func_0x", text)
    return _STR_LABEL.sub(lambda m: m.group(1) + "_", text)


def name_targets(text, names):
    """Replace FUN_<addr> / func_0x<addr> with the function's real name where `names`
    ({address: name}, the binary's own symbols) knows it (db2_bugs.md DB2-17). Run BEFORE
    norm_c(): the callee then reads the same on both builds even though its address moved,
    instead of collapsing to an anonymous FUN_."""
    if not text or not names:
        return text

    def sub(m):
        return names.get(int(m.group(1), 16)) or m.group(0)
    return _TARGET.sub(sub, text)


def _write_context(path, ctx):
    """<side>.ctx for DecompileFunc.java: `base <hex>` and `block <hexaddr> <hexbytes>`."""
    lines = []
    if ctx.get("base") is not None:
        lines.append(f"base {ctx['base']:x}")
    for addr, data in ctx.get("blocks") or ():
        if data:
            lines.append(f"block {addr:x} {bytes(data).hex()}")
    with open(lp(path), "w", encoding="ascii", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")


def _ctx_digest(*ctxs):
    """Cache-key part for decompile contexts: the output depends on them."""
    if not any(ctxs):
        return ""
    h = hashlib.sha256(usedforsecurity=False)
    for ctx in ctxs:
        ctx = ctx or {}
        h.update(repr(ctx.get("base")).encode())
        for addr, data in ctx.get("blocks") or ():
            h.update(b"%x:" % addr + hashlib.sha256(bytes(data)).digest())
        for addr, name in sorted((ctx.get("names") or {}).items()):
            h.update(b"%x=" % addr + name.encode("utf-8", "replace"))
        h.update(b"|")
    return "c" + h.hexdigest()[:8]


def decompile_pair(prior_bytes, fixed_bytes, prior_ctx=None, fixed_ctx=None):
    """Decompile two raw x86-64 function blobs to C. Returns (prior_c, fixed_c). Raises
    GhidraNotConfigured if Ghidra is absent, or RuntimeError on timeout / no output.

    prior_ctx / fixed_ctx (optional, db2_bugs.md DB2-16/17): {"base": the function's real
    address, "blocks": [(address, bytes)] of read-only data it references}. Without one,
    a blob is decompiled at the fixed _BASE with no surrounding memory, as before."""
    headless = analyze_headless()
    if not headless:
        raise GhidraNotConfigured(
            "Ghidra not found. Set GHIDRA_HOME (expects support/analyzeHeadless).")
    # IMP-T2-1: DecompileFunc.java (like BinExport.java) is a custom GhidraScript Ghidra
    # dynamically compiles into a per-user OSGi bundle cache keyed implicitly to whichever
    # JDK Ghidra last ran under. A JDK switch since the last run leaves that cache stale,
    # failing with an opaque BundleException while Ghidra itself exits 0 — this is exactly
    # CRIT-T2-1's root cause. Best-effort, never raises — see tool_paths.py.
    tp.clear_stale_ghidra_script_cache()
    tp.warn_if_unsupported_java()          # bugs.md #56
    with tempfile.TemporaryDirectory(prefix="pdff_dc_") as td:
        blobs = os.path.join(td, "blobs"); os.makedirs(blobs)
        outc = os.path.join(td, "out"); os.makedirs(outc)
        proj = os.path.join(td, "proj"); os.makedirs(proj)
        # no extension -> Ghidra program name is exactly "prior"/"fixed"
        if prior_bytes:
            with open(lp(os.path.join(blobs, "prior")), "wb") as _fh:
                _fh.write(prior_bytes)
        if fixed_bytes:
            with open(lp(os.path.join(blobs, "fixed")), "wb") as _fh:
                _fh.write(fixed_bytes)
        script_args = [outc]
        if prior_ctx or fixed_ctx:
            ctxd = os.path.join(td, "ctx"); os.makedirs(ctxd)
            for side, ctx in (("prior", prior_ctx), ("fixed", fixed_ctx)):
                if ctx:
                    _write_context(os.path.join(ctxd, side + ".ctx"), ctx)
            script_args.append(ctxd)
        cmd = [headless, proj, "pdff_decomp", "-import", blobs,
               "-processor", "x86:LE:64:default",
               "-loader", "BinaryLoader", "-loader-baseAddr", hex(_BASE),
               "-scriptPath", _SCRIPT_DIR, "-postScript", "DecompileFunc.java", *script_args,
               "-noanalysis", "-deleteProject"]
        try:
            # A blob is a single function, so Ghidra's default heap is enough;
            # ghidra_env() still applies an explicit PATCHDIFF_GHIDRA_MAXMEM.
            proc = _run_tool(cmd, env=tp.ghidra_env(), timeout=_TIMEOUT)
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"Ghidra decompile timed out after {_TIMEOUT}s") from None
        if proc.returncode not in (0, 1):  # Ghidra exits 1 on warnings — tolerate; mirrors
                                           # _bindiff.py::ghidra_binexport()'s identical check
            # Diagnostic only — doesn't raise here. The "neither side produced output"
            # check below already catches a total failure regardless of exit code (Ghidra
            # can exit 0 even when its postScript failed to load, per CRIT-T2-1), so this
            # is an extra signal for an unexpected exit code specifically, not the primary
            # failure detector.
            tail = (proc.stdout or b"")[-800:].decode("utf-8", "replace")
            print(f"WARNING: Ghidra decompile exited with unexpected code "
                 f"{proc.returncode}:\n{tail}", file=sys.stderr)

        def _read(side):
            p = os.path.join(outc, side + ".c")
            if os.path.isfile(lp(p)):
                with open(lp(p), "r", encoding="utf-8", errors="replace") as _fh:
                    return _fh.read()
            return ""

        prior_c, fixed_c = _read("prior"), _read("fixed")
    if not prior_c and not fixed_c:
        tail = (proc.stdout or b"")[-800:].decode("utf-8", "replace")
        raise RuntimeError("Ghidra produced no C output.\n" + tail)
    return prior_c, fixed_c


def _try_decompile(prior_bytes, fixed_bytes, prior_ctx=None, fixed_ctx=None):
    """Call decompile_pair(); return (prior_c, fixed_c, attempted).

    attempted=False only when Ghidra isn't configured at all — decompile was never tried
    for this function, same as "not requested". attempted=True whenever a real decompile
    was tried, whether it produced output or not: a failure (prior_c == fixed_c == "")
    is NOT silently discarded — the exception is logged to stderr and `attempted=True` is
    still returned, so a caller can tell "nothing warranted decompiling" apart from "we
    tried and Ghidra failed" instead of both looking identical (a total, silent decompile
    failure across an entire run previously had zero diagnostic of any kind — see
    CRIT-T2-1). Never raises — decompilation is best-effort only. Shared by all three
    backends."""
    global _LAST_FAILURE
    if not available():
        return "", "", False
    try:
        prior_c, fixed_c = decompile_pair(prior_bytes, fixed_bytes, prior_ctx, fixed_ctx)
        prior_c = name_targets(prior_c, (prior_ctx or {}).get("names"))
        fixed_c = name_targets(fixed_c, (fixed_ctx or {}).get("names"))
        return norm_c(prior_c), norm_c(fixed_c), True
    except Exception as exc:
        _LAST_FAILURE = (str(exc).splitlines() or [type(exc).__name__])[0][:300]
        print(f"WARNING: decompile failed ({_LAST_FAILURE[:200]}); this "
             f"function's pseudo-C will be missing from the result.", file=sys.stderr)
        return "", "", True


_LAST_FAILURE = None


def failure_record(obj):
    """{"object", "reason"} for a function whose pseudo-C came out missing or one-sided."""
    return {"object": obj, "reason": _LAST_FAILURE or "no pseudo-C produced"}


def last_failure_reason():
    """Why the most recent decompile_cached() call in this process produced missing or
    one-sided pseudo-C, or None (db2_bugs.md DB2-14). A backend reads it right after a
    failed call to record the reason per function in its result, instead of the reason
    existing only as a stderr line. Each Stage 2 worker is one single-threaded process,
    so the most recent call is the one it just made."""
    return _LAST_FAILURE


_IDENTITY = None


def _decompiler_identity():
    """Short digest of which Ghidra install and which DecompileFunc.java produce the
    pseudo-C — part of the cache key, so a Ghidra upgrade or script change doesn't keep
    serving the previous decompiler's output (same staleness class as bugs.md #15)."""
    global _IDENTITY
    if _IDENTITY is None:
        # bugs.md #29: this used to hash only the Ghidra home's BASENAME, so a different
        # install at a different path with the same folder name (or an in-place upgrade)
        # kept serving the old decompiler's pseudo-C. tp.decompiler_identity() covers the
        # install's version/build record, path, JDK and native decompiler by content.
        h = hashlib.sha256(tp.decompiler_identity().encode(), usedforsecurity=False)
        try:
            with open(lp(os.path.join(_SCRIPT_DIR, "DecompileFunc.java")), "rb") as fh:
                h.update(fh.read())
        except OSError:
            pass
        _IDENTITY = h.hexdigest()[:8]
    return _IDENTITY


def decompile_allowed(limit, stats):
    """--decompile-max (db2_bugs.md DB2-12): whether one more function of this binary (one
    object for Oracle) may be decompiled. Each costs a Ghidra JVM start, up to _TIMEOUT
    seconds, and fix-shaped or attributed functions are uncapped otherwise. Cache hits
    count too, so the same functions get pseudo-C on every run; callers try the most
    important functions first (their card order). Over the limit, stats["skipped"] is
    incremented and False returned. `limit` None means no limit."""
    if limit is None or stats["attempted"] < limit:
        return True
    stats["skipped"] = stats.get("skipped", 0) + 1
    return False


def _pair_cache_file(cache_dir, prior_bytes, fixed_bytes, prior_ctx=None, fixed_ctx=None):
    key = hashlib.sha256(prior_bytes + b"|", usedforsecurity=False).hexdigest()[:16]
    key += hashlib.sha256(fixed_bytes, usedforsecurity=False).hexdigest()[:8]
    key += _decompiler_identity() + _NORM_VERSION + _ctx_digest(prior_ctx, fixed_ctx)
    return os.path.join(cache_dir, key + ".json")


def _read_pair_cache(cache_file):
    """(prior_c, fixed_c) from a complete pair entry, else None."""
    if os.path.isfile(lp(cache_file)):
        try:
            with open(lp(cache_file), encoding="utf-8") as fh:
                d = json.load(fh)
            if d.get("prior_c") and d.get("fixed_c"):
                return d["prior_c"], d["fixed_c"]
            # a one-sided entry written by an older version: not a real hit, retry (#7)
        except Exception:
            pass  # corrupt cache entry — fall through and recompute
    return None


_PER_FUNCTION_DIR = "per_function"
_TMP_SWEPT = set()          # per_function dirs whose stale .tmp files this process has swept
_TMP_STALE_SECS = 3600      # only sweep .tmp files this old — a live write completes in ms,
                            # so this never races a concurrent worker's in-progress write


def _sweep_stale_tmp(cache_dir, subdir=_PER_FUNCTION_DIR):
    """Remove *.tmp left by a process killed mid-write (both _write_side_cache and the per-pair
    writer stage a <entry>.<pid>.tmp then os.replace() it). `subdir` selects which directory to
    sweep — the per-function cache (default) or the per-pair cache at the cache root (subdir="").
    Runs once per dir per process and only on files old enough that no live worker could still be
    writing them."""
    pf = os.path.join(cache_dir, subdir) if subdir else cache_dir
    if pf in _TMP_SWEPT:
        return
    _TMP_SWEPT.add(pf)
    cutoff = time.time() - _TMP_STALE_SECS
    try:
        stale = glob.glob(os.path.join(lp(pf), "*.tmp"))
    except OSError:
        return
    for t in stale:
        try:
            if os.path.getmtime(t) < cutoff:
                os.remove(t)
        except OSError:
            pass                               # vanished or in use — leave it


def _side_cache_file(cache_dir, code):
    """One function's (one build's) pseudo-C entry: keyed by its exact bytes and the
    decompiler, so the same function of the same build hits in any pairing."""
    key = hashlib.sha256(code, usedforsecurity=False).hexdigest()[:32]
    return os.path.join(cache_dir, _PER_FUNCTION_DIR,
                        f"{key}_{_decompiler_identity()}{_NORM_VERSION}.json")


def _read_side_cache(path):
    try:
        with open(lp(path), encoding="utf-8") as fh:
            c = json.load(fh).get("c")
        return c or None
    except (OSError, ValueError, AttributeError):
        return None


def _write_side_cache(path, code, c):
    """Atomically: two DLLs can hold byte-identical functions, so two workers may write
    the same entry at once (with the same content)."""
    try:
        os.makedirs(lp(os.path.dirname(path)), exist_ok=True)
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(lp(tmp), "w", encoding="utf-8") as fh:
            json.dump({"c": c, "bytes_sha256": hashlib.sha256(code).hexdigest()}, fh)
        os.replace(lp(tmp), lp(path))
    except OSError:
        pass                                   # a cache write failure is non-fatal


def decompile_cached_per_side(prior_bytes, fixed_bytes, cache_dir):
    """decompile_cached() with the cache kept per function and build instead of per pair
    (used by MSSQL). The two sides are separate Ghidra programs, so neither side's pseudo-C
    depends on the other: a side found in the cache is reused whatever it was paired with
    before, and only the missing side(s) are decompiled — none when both are cached. A
    successful side is cached even when the other one failed; the failure is reported (the
    caller counts it, last_failure_reason() says why) and retried on the next run. A
    complete entry of the old per-pair cache is used when present, so an existing output
    folder is not decompiled again. Same return value as decompile_cached()."""
    global _LAST_FAILURE
    _LAST_FAILURE = None
    os.makedirs(lp(cache_dir), exist_ok=True)
    _sweep_stale_tmp(cache_dir)
    pfile = _side_cache_file(cache_dir, prior_bytes)
    ffile = _side_cache_file(cache_dir, fixed_bytes)
    prior_c, fixed_c = _read_side_cache(pfile), _read_side_cache(ffile)
    if not (prior_c and fixed_c):
        old = _read_pair_cache(_pair_cache_file(cache_dir, prior_bytes, fixed_bytes))
        if old:
            prior_c, fixed_c = old
            _write_side_cache(pfile, prior_bytes, prior_c)
            _write_side_cache(ffile, fixed_bytes, fixed_c)
    if prior_c and fixed_c:
        return prior_c, fixed_c, True
    if not available():
        return "", "", False
    new_p, new_f, attempted = _try_decompile(b"" if prior_c else prior_bytes,
                                             b"" if fixed_c else fixed_bytes)
    if new_p and not prior_c:
        _write_side_cache(pfile, prior_bytes, new_p)
        prior_c = new_p
    if new_f and not fixed_c:
        _write_side_cache(ffile, fixed_bytes, new_f)
        fixed_c = new_f
    if bool(prior_c) != bool(fixed_c):
        missing = "prior" if not prior_c else "fixed"
        _LAST_FAILURE = _LAST_FAILURE or f"no pseudo-C for the {missing} side"
        print(f"WARNING: decompile produced no pseudo-C for the {missing} side; this "
              f"function's before/after decompilation is incomplete.", file=sys.stderr)
    return prior_c or "", fixed_c or "", attempted or bool(prior_c or fixed_c)


def decompile_cached(prior_bytes, fixed_bytes, cache_dir, prior_ctx=None, fixed_ctx=None):
    """SHA256-keyed cache around _try_decompile(). Avoids re-running Ghidra on the same
    function pair across repeated runs (e.g. --reattribute or after a partial failure).
    Cache is written only when BOTH sides produced output. Shared by all three backends.

    Returns (prior_c, fixed_c, attempted) — see _try_decompile(). A cache HIT is always
    attempted=True: decompile_cached() never writes a cache entry for a failed, empty or
    one-sided result (see below), so a cache file existing means a prior attempt fully
    succeeded. Callers should treat `not (prior_c and fixed_c)` as a failed decompile.
    """
    global _LAST_FAILURE
    _LAST_FAILURE = None
    os.makedirs(lp(cache_dir), exist_ok=True)
    _sweep_stale_tmp(cache_dir, "")      # DB2-T2-2: clear per-pair .tmp left by a killed worker
    cache_file = _pair_cache_file(cache_dir, prior_bytes, fixed_bytes, prior_ctx, fixed_ctx)
    hit = _read_pair_cache(cache_file)
    if hit:
        return hit[0], hit[1], True
    if prior_ctx or fixed_ctx:
        prior_c, fixed_c, attempted = _try_decompile(prior_bytes, fixed_bytes,
                                                     prior_ctx, fixed_ctx)
    else:
        prior_c, fixed_c, attempted = _try_decompile(prior_bytes, fixed_bytes)
    if bool(prior_c) != bool(fixed_c):
        # bugs.md #7: only ONE side produced pseudo-C. That used to count as a successful
        # decompile and was cached, so the incomplete pair was served from cache forever.
        # Return what we have (still worth showing) but don't cache it — callers count it
        # as failed, and a later run retries it.
        missing = "prior" if not prior_c else "fixed"
        _LAST_FAILURE = f"no pseudo-C for the {missing} side"
        print(f"WARNING: decompile produced no pseudo-C for the {missing} side; this "
              f"function's before/after decompilation is incomplete.", file=sys.stderr)
        return prior_c, fixed_c, attempted
    if prior_c and fixed_c:
        # DB2-T2-2: stage to <file>.<pid>.tmp then os.replace() so a concurrent worker (DB2 runs
        # one per binary in a pool, sharing this cache) and an interrupted write never leave a
        # torn cache_file — the same atomic scheme _write_side_cache uses for the per-side cache.
        try:
            tmp = f"{cache_file}.{os.getpid()}.tmp"
            with open(lp(tmp), "w", encoding="utf-8") as fh:
                json.dump({"prior_c": prior_c, "fixed_c": fixed_c}, fh)
            os.replace(lp(tmp), lp(cache_file))
        except Exception:
            pass  # cache write failure is non-fatal
    return prior_c, fixed_c, attempted