"""Shared CVE attribution + confidence for Stage-2 function diffs (all backends).

Two independent, deterministic (no-AI) signals decide whether a changed function is the
fix for one of the patch's tracked CVEs:

  1. NAME/CWE match — does the function's symbol name overlap the CVE's vulnerable
     subsystem?  Generic advisory-title words ("elevation", "buffer") match ordinary
     function names and are dropped (`_STOP`); the discriminating signal is the CVE's
     CWE mapped to *code-primitive* stems (CWE-121 -> overflow/boundscheck/ixf, CWE-285
     -> authoriz/sysuserauth/transferown ...) substring-matched against the name.
     `attribute()` returns (cve, why, name_conf) where name_conf in high|med|low|None.

  2. CORROBORATION — is there an *independent* change signal at that function?  A real
     fix has a fix-signature (added guard/bounds/validation call) or is a shared client+
     server change (cross-binary).  A name match with NO change signal is recompilation
     churn that merely shares a word with the CVE.

`resolve()` combines the two into a final confidence and an `attributed` boolean:

      name_conf     corroborated -> confidence   attributed
      high          yes/no       -> high/med      yes    (a specific-subsystem hit WITH independent
                                                          name evidence stands alone — see attribute())
      med           yes          -> med           yes
      med           no           -> low (candidate) no
      low           yes          -> low-med        yes
      low           no           -> low (candidate) no

So `attributed` = (strong name hit) OR (any name hit that a real change corroborates).
This is what fixes cumulative-patch over-attribution: broad name families (e.g. every
function with "auth") still MATCH — preserving recall — but are only ASSERTED when the
diff actually looks like a fix, so churn stays a downgraded "candidate", not a CVE claim.
"""
import re

# generic words that appear in advisory titles/descriptions but also match ordinary
# function names — matching on them produces noise, so they never count as a hit.
_STOP = {"sql", "server", "microsoft", "vulnerability", "remote", "code", "execution",
         "information", "disclosure", "elevation", "privilege", "denial", "service",
         "could", "allow", "attacker", "issue", "exists", "when", "with", "that", "this",
         "from", "into", "user", "data", "database", "engine", "component", "affected",
         "file", "name", "path", "control", "external", "improper", "handling",
         "input", "validation", "based", "buffer", "over", "read", "write",
         "vulnerable", "special", "affects", "using", "would", "which", "these", "there"}

# CWE -> code-primitive stems that actually appear in C/C++/mangled function names. A
# specific subsystem (a deserialization bug lives in serializ*/typeload* code; an authz
# bug in authoriz*/checkperm* code) discriminates; the generic advisory wrapper does not.
# Substring-matched against the lowercased name (so "Deserializer"/"sysuserauth" hit).
_CWE_PRIMITIVES = {
    502: {"deserial", "serializ", "unmarshal", "typeload", "formatter", "readexternal", "clrload"},
    89:  {"executesql", "quotename", "sqltext", "sanitiz", "tokeniz", "dynamicsql", "escapestr", "identifier"},
    22:  {"canonical", "normaliz", "traver", "uncpath", "dospath", "resolvepath", "fullpath"},
    73:  {"canonical", "normaliz", "traver", "uncpath", "dospath", "resolvepath", "fullpath"},
    # memory-safety families (787 OOB-write, 125 OOB-read, 119 bounds, 121 stack, 122 heap)
    787: {"boundscheck", "rangecheck", "overflow", "clamp", "truncat", "memcpy", "memmove"},
    125: {"boundscheck", "rangecheck", "overflow", "clamp", "truncat"},
    119: {"boundscheck", "rangecheck", "overflow", "clamp", "truncat"},
    121: {"boundscheck", "rangecheck", "overflow", "clamp", "truncat", "stackbuf", "ixf", "fmtixf"},
    122: {"boundscheck", "rangecheck", "overflow", "clamp", "heapalloc", "reallocbuf"},
    190: {"overflow", "multiply", "checkmul", "addovf"},
    # untrusted-pointer / out-of-range read (CWE-822) — a missing range/bounds guard on a
    # scan/row-fetch path. Stems match the added validator (e.g. VerifyRowInRange) and the
    # index-scan subsystem it guards.
    822: {"boundscheck", "rangecheck", "verifyrange", "verifyrow", "inrange", "checkrange"},
    # authorization / privilege families (269/266/863/862/285/284). Provider/linked-server
    # stems (oledb/msdasql/createsession/datasource) let a linked-server EoP fix in the OLE DB
    # connect path (e.g. COledbConnect::CreateSession) attribute — 269 is the title fallback
    # for "elevation of privilege" advisories that name no more specific CWE.
    269: {"impersonat", "checkperm", "checkaccess", "authoriz", "securable", "principal", "sysadmin", "sysuserauth", "sysdbauth", "transferown",
          "oledb", "msdasql", "createsession", "datasource", "opendatasource", "linkedserver", "openrowset", "provider"},
    266: {"impersonat", "checkperm", "authoriz", "securable", "principal", "sysuserauth", "sysdbauth"},
    863: {"impersonat", "checkperm", "authoriz", "securable", "principal", "sysuserauth", "sysdbauth", "checkauth"},
    862: {"checkperm", "checkaccess", "authoriz", "checkauth", "missingauth"},
    285: {"authoriz", "checkperm", "checkaccess", "checkauth", "sysuserauth", "sysdbauth",
          "transferown", "transferverify", "grantpriv", "revokepriv", "verifyauth"},
    284: {"impersonat", "checkperm", "authoriz", "securable", "principal", "sysuserauth"},
    611: {"xmlentity", "externalentity", "xmlparse", "resolveentity"},
    200: {"uninit", "disclos", "leak"},
    770: {"quota", "throttle", "ratelimit", "maxconn", "resourcelimit"},
    674: {"recurs", "depth", "nesting"},
}
# broad name FAMILIES per CWE: too generic to assert on their own (they over-match), but
# they preserve RECALL — a match here is a "weak" hit that only becomes attributed when a
# real change corroborates it. Substring-matched, lowercased name.
_CWE_FAMILIES = {
    502: {"serial", "readobject"},
    89:  {"parse", "exec", "query"},
    787: {"ixf", "import", "load", "parse", "copy", "format", "convert", "translate"},
    125: {"ixf", "import", "load", "parse", "read"},
    119: {"ixf", "import", "load", "parse", "buf"},
    121: {"ixf", "import", "load", "parse", "buf", "copy", "format"},
    122: {"alloc", "buf", "copy", "load"},
    190: {"len", "size", "count", "alloc"},
    822: {"index", "scan", "row", "fetch", "next", "getnext", "rowscan", "dataset"},
    # NOTE: the widest stems were pruned (2026-09 accuracy pass) — `connect/session/remote/
    # rowset` (269) and `access/check` (862) matched huge swaths of the engine and only added
    # noise. `auth/priv` stay for recall but never assert alone (family = corroboration-gated).
    269: {"auth", "priv", "grant", "revoke", "transfer", "secur", "role", "owner"},
    266: {"auth", "priv", "grant", "revoke", "role"},
    863: {"auth", "priv", "grant", "revoke", "transfer", "secur", "owner"},
    862: {"auth", "priv"},
    285: {"auth", "priv", "grant", "revoke", "transfer", "secur", "owner", "role"},
    284: {"auth", "priv", "grant", "revoke"},
}
# Fallback when cwe_id is missing/unmapped: read the advisory-title parenthetical/desc.
# Ordered so a specific mechanism wins over the generic "elevation of privilege" wrapper.
_TITLE_CWE = [
    (re.compile(r"deserial", re.I), 502),
    (re.compile(r"sql\s*injection|injection", re.I), 89),
    (re.compile(r"file name or path|path\s*travers|directory\s*travers|external control of", re.I), 22),
    (re.compile(r"out-?of-?bounds|buffer\s*over|heap\s*over", re.I), 122),
    (re.compile(r"stack\s*over", re.I), 121),
    (re.compile(r"integer\s*overflow", re.I), 190),
    # crafted-query AV / untrusted-pointer RCE with no more specific CWE named (e.g. a
    # "specially crafted SQL query triggers a fatal access violation" advisory).
    (re.compile(r"untrusted pointer|access violation|crafted .*query|remote code execution", re.I), 822),
    (re.compile(r"xml\s*external|xxe", re.I), 611),
    (re.compile(r"authoriz|privilege escalation|improper author", re.I), 285),
    (re.compile(r"privilege|elevation", re.I), 269),
]

# CVEs whose fix lives in a bundled THIRD-PARTY component (Java jars / vendored C libs),
# not the native DB engine binary. Their CWE stems otherwise collect spurious engine-function
# matches (e.g. a Netty deserialization CVE lighting up every serial* symbol in libdb2e).
# Stage-1 dep-diff already covers these, so they are excluded from native-symbol attribution.
_THIRDPARTY_RE = re.compile(
    r"\b(netty|corosync|log4j|logback|jackson(?:-databind)?|snakeyaml|xstream|"
    r"bouncy\s?castle|woodstox|xerces|nghttp2|libexpat|expat|tomcat|jetty|struts2?|"
    r"spring\s+(?:framework|security)|guava|okhttp|protobuf|grpc|junit|"
    r"gson|httpclient|httpcomponents|activemq|kafka)\b"
    r"|\bapache\s+commons\b|\bcommons[-\s]\w+", re.I)

# authorization-check primitive stems that, on their own, are too generic to *assert* a CVE
# (they appear on many ordinary permission-check functions). A hit on ONLY these caps the
# name-confidence at 'med' (so it needs an independent change signal to be attributed); a hit
# on a SPECIFIC subsystem primitive (transferown, sysuserauth, deserial, ixf, boundscheck …)
# can reach 'high' — but only with independent corroboration IN THE NAME (a second primitive,
# or two separate description-word overlaps); one lone primitive, even with one incidental
# shared word, stays 'med' (CRIT-NT-7).
_BROAD_STEMS = {"authoriz", "checkperm", "checkaccess", "checkauth"}


def _tokens(name):
    """Split a symbol/description into lowercase word tokens (camelCase + separators)."""
    s = re.sub(r"[^A-Za-z0-9]+", " ", name)
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", s)
    return {t.lower() for t in s.split() if len(t) >= 4}


def _cwe_nums(cwe_id, title):
    nums = [int(x) for x in re.findall(r"\d+", cwe_id or "")]
    if not any(n in _CWE_PRIMITIVES or n in _CWE_FAMILIES for n in nums):
        for rx, n in _TITLE_CWE:
            if rx.search(title or ""):
                nums.append(n)
                break
    return nums


def cwe_tokens(cwe_id, title):
    """(primitives, families) stem-sets for a CVE's CWE (or title fallback)."""
    prims, fams = set(), set()
    for n in _cwe_nums(cwe_id, title):
        prims |= _CWE_PRIMITIVES.get(n, set())
        fams |= _CWE_FAMILIES.get(n, set())
    return prims, fams


def build_attrib(rows):
    """[{cve, tokens, primitives, families, component}] from cves rows
    (cve_id, cve_desc, component, package, cwe_id).

    CRIT-NT-4 (generalized, found in further review): a row whose desc/component/package
    tokenize to nothing but _STOP words, with no cwe_id (or a cwe_id/title the _TITLE_CWE
    fallback can't map), has NO primitives/families/generic tokens to match ANY function
    name against — attribute() will return (None, None, None) for every function, for
    this CVE, no matter how it's named. This is reachable from EITHER caller: load_attrib's
    meta.json bare-CVE-ID tier (desc/cwe_id always blank by construction there) as well as
    the primary --cves.json path (a user-supplied record can just as easily have a blank
    cve_desc/cwe_id, e.g. captured before the advisory was fully enriched). Rather than
    warn in only one of the two callers, every row dropped here for lack of signal is
    reported once, by CVE ID, regardless of which path it came from.
    """
    import sys
    attrib = []
    starved = []
    for r in rows:
        cve_id, desc, component, package, cwe_id = (r[0], r[1] or "", r[2] or "",
                                                    r[3] or "", r[4] or "")
        prims, fams = cwe_tokens(cwe_id, desc)
        generic = (_tokens(desc) | _tokens(component) | _tokens(package)) - _STOP
        # component/package are the caller's explicit subsystem label (e.g. "Linked Server"),
        # unlike free-text advisory prose; attribute() treats a match on these as stronger
        # corroboration than an incidental description word (CRIT-NT-7).
        comp_tokens = (_tokens(component) | _tokens(package)) - _STOP
        # a bundled-library CVE is attributed via Stage-1 dep-diff, never native symbols
        non_native = bool(_THIRDPARTY_RE.search(desc) or _THIRDPARTY_RE.search(package)
                          or _THIRDPARTY_RE.search(component))
        if generic or prims or fams:
            attrib.append({"cve": cve_id, "tokens": generic, "primitives": prims,
                           "families": fams, "component": component, "non_native": non_native,
                           "comp_tokens": comp_tokens})
        else:
            starved.append(cve_id)
    if starved:
        print(
            f"WARNING: {len(starved)} CVE(s) have no usable name/CWE attribution signal "
            f"({', '.join(starved[:5])}{', ...' if len(starved) > 5 else ''}) — their "
            f"description/component/package are empty or all generic words, and no CWE "
            f"maps to a known primitive/family set. These CVEs will NEVER be flagged "
            f"against any function name. Supply a cwe_id and/or a more specific cve_desc "
            f"in --cves for real attribution.",
            file=sys.stderr)
    return attrib


def parse_cves_file(path):
    """(rows, problems) from a --cves JSON file. rows are build_attrib() tuples; problems is
    a list of human-readable reasons for anything unusable. Invalid records are skipped one
    at a time (a single bad record used to discard the whole file), and field values are
    coerced to strings so a null/number field can't crash tokenization later."""
    import json
    try:
        with open(path, encoding="utf-8") as fh:
            records = json.load(fh)
    except (OSError, ValueError) as exc:
        return [], [f"cannot read/parse as JSON ({exc})"]
    if not isinstance(records, list):
        return [], [f"expected a JSON list of CVE records, got {type(records).__name__}"]
    rows, problems = [], []
    for i, r in enumerate(records):
        if not isinstance(r, dict):
            problems.append(f"record {i}: not an object")
            continue
        cid = r.get("cve_id")
        if not isinstance(cid, str) or not cid.strip():
            problems.append(f"record {i}: missing/invalid 'cve_id'")
            continue

        def _s(key):
            v = r.get(key)
            return "" if v is None else str(v)
        rows.append((cid.strip(), _s("cve_desc"), _s("component"), _s("package"), _s("cwe_id")))
    return rows, problems


def load_attrib(workdir):
    """Build the attrib list for a patch's tracked CVEs.

    Priority order:
      1. cves.json in workdir — full records with descriptions (placed by CLI --cves flag)
      2. meta.json tracked_cves — bare CVE IDs only. CRIT-NT-4: a bare CVE ID carries no
         CWE or description text, so build_attrib() has nothing to derive primitives/
         families/generic tokens from — this tier can NEVER produce a usable attrib row,
         by construction. (An earlier comment here claimed "name/CWE primitives still
         score", which was never true for this tier and has been removed.) build_attrib()
         itself now warns, by CVE ID, whenever a row it's given has no usable signal —
         covering this tier and a sparse --cves.json record alike — instead of silently
         returning a report with zero attribution and no indication why.
      3. Nothing available — returns [] so Stage 2 runs unattributed

    Runs in the PARENT; the picklable result is passed down to workers.
    """
    from pathlib import Path
    import json
    import sys

    wd = Path(workdir)

    # 1. Full CVE records supplied by the caller
    cves_json = wd / "cves.json"
    if cves_json.exists():
        rows, problems = parse_cves_file(cves_json)
        if problems:
            # bugs.md #17: this used to be `except Exception: pass` — a malformed or
            # wrongly-shaped cves.json silently produced zero attribution, indistinguishable
            # from a run whose CVEs simply matched nothing.
            print(f"WARNING: {cves_json}: " + "; ".join(problems[:5])
                  + (f" (+{len(problems) - 5} more)" if len(problems) > 5 else ""),
                  file=sys.stderr)
        if rows:
            return build_attrib(rows)
        print("WARNING: cves.json yielded no usable CVE records — falling back to "
              "meta.json tracked_cves (if any); CVE attribution may be empty.",
              file=sys.stderr)

    # 2. Bare CVE IDs from meta.json — see this function's docstring: cannot score.
    meta_path = wd / "meta.json"
    if not meta_path.exists():
        return []
    try:
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"WARNING: {meta_path}: unreadable ({exc}); CVE attribution will be empty.",
              file=sys.stderr)
        return []
    # bugs.md #19: any valid JSON used to be trusted — a list, a non-string/non-list
    # tracked_cves, or non-string items raised AttributeError/TypeError and aborted Stage 2.
    # Only a {"tracked_cves": "id,id" | ["id", ...]} shape is used; anything else is warned
    # about and ignored (attribution is best-effort and must never fail the run).
    raw = meta.get("tracked_cves") if isinstance(meta, dict) else None
    if isinstance(raw, str):
        items = raw.split(",")
    elif isinstance(raw, list):
        items = raw
    else:
        if raw is not None or not isinstance(meta, dict):
            print(f"WARNING: {meta_path}: expected an object with a string or list "
                  f"'tracked_cves'; ignoring it — CVE attribution will be empty.",
                  file=sys.stderr)
        return []
    bad = [c for c in items if not isinstance(c, str)]
    if bad:
        print(f"WARNING: {meta_path}: ignoring {len(bad)} non-string tracked_cves "
              f"entr{'y' if len(bad) == 1 else 'ies'}.", file=sys.stderr)
    cves = [c.strip() for c in items if isinstance(c, str) and c.strip()]
    if not cves:
        return []
    rows = [(cid, "", "", "", "") for cid in cves]
    return build_attrib(rows)  # warns on its own when a row has no usable signal


# bugs.md #27: a function name that several distinct functions share (e.g. same-named
# `static` functions from two TUs of one ELF) is keyed "name [qualifier]" by the Stage 2
# function maps. Raw symbol names never contain a space, so the suffix is unambiguous.
_QUALIFIED = re.compile(r"^(\S+) \[[^\[\]]*\]$")


def qualify_func_name(name, label):
    return f"{name} [{label}]"


def base_func_name(key):
    """The symbol name of a (possibly qualified) Stage 2 function key."""
    m = _QUALIFIED.match(key)
    return m.group(1) if m else key


def attribute(name, attrib):
    """Best (cve, why, name_conf) for a function name against the patch's tracked CVEs.
    name_conf: 'high' (a specific-subsystem primitive plus a second primitive or two
    independent generic-word overlaps), 'med' (a primitive or two generic tokens), 'low'
    (a broad family word only), or None. Returns (None, None, None)
    if nothing matches. A qualified key is matched on its symbol name alone — the
    source-file qualifier is a disambiguator, not evidence."""
    if not attrib:
        return None, None, None
    name = base_func_name(name)
    toks = _tokens(name)
    low = name.lower()
    best = None   # (score, nspec, cve, hits, nprim, nbroad, ngeneric, ncomp)
    for a in attrib:
        if a.get("non_native"):
            continue                                # bundled 3rd-party CVE — not an engine fn
        prims = a.get("primitives", set())
        fams = a.get("families", set())
        generic = toks & (a["tokens"] - prims)
        prim = {p for p in prims if p in low}       # substring: catches Deserializer/sysuserauth
        fam = {p for p in fams if p in low} if not (prim or generic) else set()
        if not (generic or prim or fam):
            continue
        score = 3 * len(prim) + len(generic) + (1 if fam else 0)
        nspec = len(prim - _BROAD_STEMS)            # specific-subsystem primitives only
        cand = (score, nspec, a["cve"],
                sorted(prim) + sorted(generic) + sorted(fam), len(prim),
                len(prim & _BROAD_STEMS), len(generic),
                len(generic & a.get("comp_tokens", frozenset())))
        # rank by score, then by specificity, then by cve id for a stable (order-independent)
        # tie-break — co-located CVEs no longer collapse onto whichever meta.json lists first.
        if (best is None or (score, nspec) > (best[0], best[1])
                or ((score, nspec) == (best[0], best[1]) and a["cve"] < best[2])):
            best = cand
    if not best:
        return None, None, None
    score, nspec, cve, hits, nprim, nbroad, ngeneric, ncomp = best
    # CRIT-NT-7: 'high' is asserted as a CVE claim by resolve() with NO independent
    # corroboration, so it needs evidence that is genuinely independent of one lucky word.
    # Previously `score >= 4` let ONE specific primitive plus ONE incidental generic word
    # (e.g. "memory" shared by a CVE's advisory text and an unrelated function name) pool to
    # 'high' — the same single-primitive evidence the project's own tests rate only 'med'.
    # Description-derived generic words are weak (they are ordinary English/engine words), so
    # a lone specific primitive is promoted only by a SECOND CWE-derived primitive (broad or
    # specific), a match on the caller's explicit component/package label, or at least two
    # independent generic-word overlaps.
    if nspec and (nspec >= 2 or nbroad >= 1 or ngeneric >= 2 or ncomp >= 1):
        conf = "high"                               # specific primitive + independent corroboration
    elif nprim or len(hits) >= 2:
        conf = "med"                                # broad-auth primitive / two generic tokens
    else:
        conf = "low"                                # broad family word only
    return cve, "matched: " + ", ".join(hits[:4]), conf


# final confidence order (index used for counting / sorting)
_ORDER = {"high": 3, "med": 2, "low": 1, None: 0}


def resolve(name_conf, corroborated):
    """Combine the name/CWE match with an independent change signal (fix-shaped diff or
    cross-binary). Returns (confidence, attributed). `attributed` = a CVE claim we stand
    behind; a name match with no corroboration is a downgraded 'candidate' (low, not
    attributed)."""
    if not name_conf:
        return None, False
    if name_conf == "high":
        return ("high" if corroborated else "med"), True
    if name_conf == "med":
        return ("med", True) if corroborated else ("low", False)
    # low (broad family word only)
    return ("med", True) if corroborated else ("low", False)