"""Shared Stage 2 output layout: one folder per build, so each build's results can be
reused on their own.

    <stage2>/disassembled_instructions_<build>_<version>/<binary>_<sha8>/<function>.asm
    <stage2>/decompiled_c_<build>_<version>/<binary>_<sha8>/<function>.c
    <stage2>/disassembled_instructions_<vuln version>_vs_<fixed version>/   (the diffs)

<build> is "vuln" or "fixed"; <version> is the build's label (a KB number, an engine or
fixpack version) or "unversioned". Each <binary>_<sha8>/ folder holds a binary.json saying
which binary and build it is; the content hash in its name keeps two different builds
apart even under the same label. A function's file is named after that build's own
function name, deterministically, so the same function of the same build always lands in
the same file (a later run refreshes it) and pairs by name with the other build's file.

Used by mssql/stage2.py; written backend-neutral so DB2 and Oracle can adopt it.
"""
import hashlib
import json
import os
import re

from .db2._paths import lp, safe_name

UNVERSIONED = "unversioned"


def version_token(label):
    """A build's label (KB5122771, 2022.160.1200.5) as a folder-name part: kept readable
    (no digest — a label is short and controlled), "unversioned" when there is none."""
    token = re.sub(r"[^A-Za-z0-9.-]", "_", label or "").strip("._")[:60]
    return token or UNVERSIONED


def version_dirs(stage2_dir, vuln_version, fixed_version):
    """{"prior"|"fixed": {"label", "build", "asm", "c"}}: each build's own output folders
    (created on first use by binary_folder())."""
    return {side: {"label": ver, "build": build,
                   "asm": os.path.join(stage2_dir, f"disassembled_instructions_{build}_{ver}"),
                   "c": os.path.join(stage2_dir, f"decompiled_c_{build}_{ver}")}
            for side, build, ver in (("prior", "vuln", vuln_version),
                                     ("fixed", "fixed", fixed_version))}


def pair_diff_dir(stage2_dir, vuln_version, fixed_version):
    """The folder for the assembly diffs, which compare the two builds."""
    return os.path.join(stage2_dir,
                        f"disassembled_instructions_{vuln_version}_vs_{fixed_version}")


def file_sha256(path):
    h = hashlib.sha256()
    with open(lp(path), "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def binary_folder(base, rel, path, side_info, display_name=None, digest=None):
    """<base>/<rel>_<sha256[:8]>/ for one build of one binary, created with a binary.json
    (binary, name, sha256, version, build). Pass digest to reuse an already-computed
    sha256 of path (a build's asm and c folders share one) instead of re-hashing."""
    digest = digest or file_sha256(path)
    folder = os.path.join(base, f"{re.sub(r'[^A-Za-z0-9._-]', '_', rel)}_{digest[:8]}")
    os.makedirs(lp(folder), exist_ok=True)
    meta = {"binary": rel, "name": display_name or os.path.basename(rel), "sha256": digest,
            "version": side_info["label"], "build": side_info["build"]}
    with open(lp(os.path.join(folder, "binary.json")), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=1)
    return folder


def function_file(name, ext):
    """A function's file name in a binary folder: readable, plus a digest of the full name
    so distinct (long, templated, case-differing) names never share a file."""
    return safe_name(name, 120) + ext


def listing(md, name, binary_name, start, chunks, address_kind="RVA"):
    """Plain disassembly of one function: a header, then for each (address, code) chunk
    every instruction as `<address>  <bytes>  <mnemonic> <operands>`."""
    lines = [f"; {name}", f"; {binary_name}, primary {address_kind} 0x{start:x}, "
             f"{sum(len(c) for _a, c in chunks)} bytes in {len(chunks)} chunk(s)"]
    for addr, code in chunks:
        lines.append(f"\n; chunk at {address_kind} 0x{addr:x} ({len(code)} bytes)")
        for ins in md.disasm(code, addr):
            lines.append(f"{ins.address:08x}  {ins.bytes.hex():<24} {ins.mnemonic} {ins.op_str}"
                         .rstrip())
    return "\n".join(lines) + "\n"
