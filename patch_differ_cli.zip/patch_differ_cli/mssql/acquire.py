"""Acquire + extract a SQL Server GDR patch's engine binaries — the ONLY online part
of the pipeline (everything after this is offline).

Chain (validated in the spike, no exe execution / no UAC):
  MSRC download page -> direct .exe -> carve embedded CABs (MSCF) -> extract the big
  CABs -> SQL_ENGINE_CORE_INST.MSP -> 7-Zip extract -> named engine files
  (ENG_RE_sqllang_64 = sqllang.dll, ENG_RE_ResourceDb_mdf_64 = resource DB, ...).

Every step is idempotent (skips work whose output already exists) so a run resumes.
"""
import json
import os
import re
import struct
import subprocess

import requests

from ..db2._paths import lp
from .. import tool_paths as tp
from .. import _acquire_state as _state

_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) patch-differ"}
_ENGINE_MSP = "SQL_ENGINE_CORE_INST.MSP"
_CATALOG = "https://www.catalog.update.microsoft.com"


def sevenzip():
    """Path to 7z.exe. Kept here (delegating to tool_paths.sevenzip()) since other
    modules already import `sevenzip` from this file."""
    return tp.sevenzip()


def _from_download_center(page_url):
    """Download-Center details.aspx page -> direct .exe (or None if the page is dead
    / has no link — many familyid= pages 404)."""
    try:
        r = requests.get(page_url, headers=_UA, timeout=60, allow_redirects=True)
        if r.status_code != 200:
            return None
        exes = re.findall(r"https://download\.microsoft\.com/[^\s\"'<>]+?\.exe", r.text)
        x64 = [e for e in exes if "x64" in e.lower()] or exes
        return x64[0] if x64 else None
    except Exception:
        return None


def normalize_kb(kb):
    """A KB argument ('KB5084815', ' kb5084815 ', 5084815) as its bare digits, or None
    when none was given. Raises ValueError for anything else.

    bugs.md #38: callers used `str(kb).upper().lstrip("KB")`, which strips any run of K/B
    CHARACTERS rather than one "KB" prefix and ran before the whitespace strip — so
    " KB5084815 " stayed "KB5084815" (and became the label/lookup "KBKB5084815")."""
    if kb is None or not str(kb).strip():
        return None
    s = str(kb).strip()
    if s[:2].upper() == "KB":
        s = s[2:].strip()
    if not (s.isascii() and s.isdigit()):
        raise ValueError(f"invalid KB number {kb!r} (expected e.g. KB5084815 or 5084815)")
    return s


def _from_update_catalog(kb):
    """Resolve the x64 GDR .exe via the Microsoft Update Catalog by KB — stable for
    every KB, unlike Download-Center familyid pages. Result rows carry the update GUID
    in a goToDetails("<guid>") onclick; the DownloadDialog POST returns the .exe URL."""
    kb = normalize_kb(kb)
    r = requests.get(f"{_CATALOG}/Search.aspx?q=KB{kb}", headers=_UA, timeout=60)
    r.raise_for_status()
    cands, seen = [], set()
    for m in re.finditer(r'goToDetails\("([0-9A-Fa-f-]{36})"\)[^>]*>(.*?)</a>', r.text, re.S):
        guid, title = m.group(1), re.sub(r"\s+", " ", m.group(2)).strip()
        if guid not in seen:
            seen.add(guid)
            cands.append((guid, title))
    if not cands:
        raise RuntimeError(f"Update Catalog: no results for KB{kb}")

    def score(t):
        t = t.lower()
        return (("x64" in t) * 2 + ("gdr" in t) * 2 + ("sql server" in t)
                - ("azure" in t) - ("arm64" in t) - ("x86" in t))
    cands.sort(key=lambda gt: score(gt[1]), reverse=True)
    for guid, _title in cands[:5]:
        try:
            body = "updateIDs=" + requests.utils.quote(
                json.dumps([{"size": 0, "languages": "", "uidInfo": guid, "updateID": guid}]))
            d = requests.post(f"{_CATALOG}/DownloadDialog.aspx", data=body, timeout=60,
                              headers={**_UA, "Content-Type": "application/x-www-form-urlencoded"})
            urls = re.findall(r"(https?://[^'\"]+?\.exe)", d.text)
            x64 = [u for u in urls if "x64" in u.lower()]
            if x64:
                return x64[0]
            if urls:
                return urls[0]
        except Exception:
            continue
    raise RuntimeError(f"Update Catalog: no .exe download for KB{kb}")


def resolve_exe_url(kb, page_url=None):
    """Direct .exe URL for a KB: try the Download-Center page first, then fall back
    to the Update Catalog (which works even when dl_url is missing/dead)."""
    if page_url:
        exe = _from_download_center(page_url)
        if exe:
            return exe
    if not kb:
        raise RuntimeError("no KB / download URL to resolve this build")
    return _from_update_catalog(kb)


def _content_range(resp):
    """(start, total) from a Content-Range header ("bytes S-E/T" or "bytes */T"); either is
    None when absent or not a number (T may be "*")."""
    cr = (resp.headers.get("Content-Range") or "").strip()
    m = re.match(r"bytes\s+(?:(\d+)-\d+|\*)/(\d+|\*)$", cr)
    if not m:
        return None, None
    start = int(m.group(1)) if m.group(1) is not None else None
    total = int(m.group(2)) if m.group(2) != "*" else None
    return start, total


def download(url, dest, progress=None, base_pct=0, span_pct=100):
    """Resumable chunked download (append to .part, resume from its size). progress(pct)
    maps 0..100 of THIS download onto [base_pct, base_pct+span_pct].

    The .part is promoted to `dest` only once it is known complete — `acquire()` treats an
    existing `dest` as done forever, so an unverified promotion is a permanent bad installer:
      * bugs.md #44: any HTTP 416 on a resumed range used to count as "complete", so an
        incomplete or invalid .part was renamed into place. A 416 now completes the file
        only if the server's size (its Content-Range, or the probe's) equals the .part's
        size, or — size unknown — the previous page of THIS run ended exactly there (EOF on
        a chunk boundary). Otherwise the .part can't be trusted and the download restarts.
      * bugs.md #47: a 206 that delivered no bytes while bytes remained left `have`
        unchanged and, with a known total, the loop re-requested the same range forever.
        A response that makes no progress is now an error (the .part is kept for a resume).
    """
    tmp = dest + ".part"
    if os.path.exists(lp(dest)):
        return dest
    # total size via a 1-byte range
    h = requests.get(url, headers={**_UA, "Range": "bytes=0-0"}, timeout=60, stream=True)
    total = _content_range(h)[1] if h.status_code == 206 else None
    h.close()
    have = os.path.getsize(lp(tmp)) if os.path.exists(lp(tmp)) else 0
    if total is not None and have > total:      # longer than the file: not a prefix of it
        os.remove(lp(tmp))
        have = 0
    chunk = 16 * 1024 * 1024
    paged_to_here = False        # True when this run's last 206 was a full chunk ending at `have`
    restarted = False
    while total is None or have < total:
        end = have + chunk - 1
        if total is not None:
            end = min(end, total - 1)
        rr = requests.get(url, headers={**_UA, "Range": f"bytes={have}-{end}"},
                          timeout=300, stream=True)
        if rr.status_code not in (200, 206):
            code = rr.status_code
            size_416 = _content_range(rr)[1] if code == 416 else None
            rr.close()
            if code == 416 and have > 0:
                known = size_416 if size_416 is not None else total
                if known == have or (known is None and paged_to_here):
                    break                                 # requested past EOF: complete
                # the .part is not a verifiable prefix of this file — start over (once)
                os.remove(lp(tmp))
                if restarted:
                    raise RuntimeError(f"download HTTP 416 for {url} again after restarting "
                                       f"from byte 0; the server's size can't be verified")
                have, paged_to_here, restarted = 0, False, True
                continue
            raise RuntimeError(f"download HTTP {code} for {url}")
        # 206 = partial content, safe to append (this is the resume path) — but only if it
        # really starts where the .part ends. 200 = the server ignored the Range header and
        # is streaming the WHOLE file from byte 0; appending that onto an existing .part
        # corrupts it, so truncate and rewrite from the start.
        start, size_206 = _content_range(rr) if rr.status_code == 206 else (None, None)
        if rr.status_code == 206 and start is not None and start != have:
            rr.close()
            raise RuntimeError(f"download: server returned bytes from {start}, "
                               f"expected {have}, for {url}")
        if total is None and size_206 is not None:
            total = size_206
        resumed = rr.status_code == 206 and have > 0
        before = have if resumed else 0
        with open(lp(tmp), "ab" if resumed else "wb") as f:
            for blk in rr.iter_content(1024 * 512):
                if blk:
                    f.write(blk)
        rr.close()
        size = os.path.getsize(lp(tmp))
        got = size - before          # bytes actually delivered this iteration
        have = size
        if progress and total:
            progress(base_pct + int(span_pct * min(have, total) / total))
        if rr.status_code == 200:    # server sent the WHOLE body in one shot — nothing to page
            if not have or (total is not None and have != total):
                raise RuntimeError(f"download: incomplete response ({have} of "
                                   f"{total if total is not None else '?'} bytes) for {url}")
            break
        if got <= 0:
            raise RuntimeError(f"download: server sent no data for bytes {have}-{end} of "
                               f"{url}; the partial file is kept and resumes next run")
        paged_to_here = got == end - before + 1
        # 206 with an unknown total: keep paging until a range comes back short (< chunk),
        # which marks EOF. (Previously this broke after the first chunk and truncated the file.)
        if total is None and got < chunk:
            break
    if total is not None and have != total:       # e.g. a 206 longer than requested
        raise RuntimeError(f"download: got {have} bytes, expected {total}, for {url}")
    os.replace(lp(tmp), lp(dest))
    return dest


_CARVE_DONE = "_carve_complete"   # sentinel: written only after a FULL carve finishes


def _carve_cabs(exe_path, cab_dir):
    """Carve validated (v1.3) MSCF cabinets out of the self-extractor .exe.

    Resume is keyed on a completion sentinel (_CARVE_DONE), not "any .cab file exists" —
    a run interrupted mid-carve leaves some .cab files written and some not, and the old
    "any .cab exists" check would wrongly treat that partial set as a finished carve. If
    the specific cab holding SQL_ENGINE_CORE_INST.MSP happened to be one of the missing
    ones, extract_engine() would then raise a confusing "no cabinet found" error on
    resume instead of re-carving.

    bugs.md #31: the sentinel used to say only "a carve finished here", so a cab_dir
    carved from a DIFFERENT installer (a replaced or re-downloaded .exe, or another KB's
    dir reused) was trusted and the old build's engine extracted. It now records the
    installer's fingerprint (the same identity extract_engine() uses) and is reused only
    for that installer; a stale or older-format sentinel is deleted BEFORE re-carving, so
    an interrupted re-carve can never leave a sentinel vouching for a mixed set of cabs.
    """
    os.makedirs(lp(cab_dir), exist_ok=True)
    done_marker = os.path.join(cab_dir, _CARVE_DONE)
    identity = _state.file_fingerprint(exe_path)
    if os.path.isfile(lp(done_marker)):
        try:
            with open(lp(done_marker), encoding="utf-8") as mf:
                rec = json.load(mf)
        except (OSError, ValueError):
            rec = None
        if isinstance(rec, dict) and rec.get("installer") == identity:
            return rec.get("cabs")   # a FULL carve of THIS installer already completed (resume)
        os.remove(lp(done_marker))
    # Clear any partial .cab files left by an earlier, interrupted carve attempt — the
    # loop below re-derives the same numbering (0000.cab, 0001.cab, ...) from the same
    # exe, so stale leftovers would otherwise just be overwritten anyway, but clearing
    # first avoids any ambiguity if the carve is ever re-run over a different .exe.
    for f in os.listdir(lp(cab_dir)):
        if f.endswith(".cab"):
            try:
                os.remove(lp(os.path.join(cab_dir, f)))
            except OSError:
                pass
    with open(lp(exe_path), "rb") as f:
        data = f.read()
    n = 0
    i = data.find(b"MSCF")
    while i != -1:
        if i + 36 <= len(data):
            res1 = struct.unpack_from("<I", data, i + 4)[0]
            cb = struct.unpack_from("<I", data, i + 8)[0]
            if res1 == 0 and data[i + 24] == 3 and data[i + 25] == 1 and 36 < cb <= len(data) - i:
                with open(lp(os.path.join(cab_dir, f"{n:04d}.cab")), "wb") as cab_f:
                    cab_f.write(data[i:i + cb])
                n += 1
                i = data.find(b"MSCF", i + cb)
                continue
        i = data.find(b"MSCF", i + 4)
    # Written only now that every cab has been carved — this, not file presence, is what
    # a resumed run checks.
    with open(lp(done_marker), "w", encoding="utf-8") as mf:
        json.dump({"installer": identity, "cabs": n}, mf)
    return n


def _7z_extract(archive, out_dir):
    os.makedirs(lp(out_dir), exist_ok=True)
    result = subprocess.run(
        [sevenzip(), "x", "-y", "-aoa", "-o" + out_dir, archive],
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=600,
    )
    # 7-Zip exit codes: 0 = OK, 1 = warning (non-fatal), 2+ = fatal error
    if result.returncode > 1:
        err = result.stderr.decode("utf-8", "replace")[-1000:]
        raise RuntimeError(
            f"7-Zip failed (rc={result.returncode}) extracting {os.path.basename(archive)}:\n{err}"
        )


def _find_engine_msp(root):
    """Locate the DB-engine MSP anywhere under `root`, case-insensitively. Newer
    packages (2019+) extract it as a flat SQL_ENGINE_CORE_INST.MSP; 2016/2017 use a
    directory tree with x64/setup/sql_engine_core_inst.msp."""
    for dirpath, _dirs, files in os.walk(lp(root)):
        for f in files:
            if f.lower() == _ENGINE_MSP.lower():
                return os.path.join(dirpath, f)
    return None


def extract_engine(exe_path, out_dir, cab_dir, source=None):
    """exe -> engine files in out_dir (named ENG_*/MPT_*). Handles both the flat-cab
    layout (2019+) and the nested directory-tree layout (2016/2017).

    Idempotent per SOURCE: an existing out_dir is reused only if it finished extracting
    from the same `source` (default: the installer's name/size/mtime fingerprint; acquire()
    passes the KB). It used to reuse any out_dir containing an ENG_* file — a half-written
    tree from an interrupted run, or the engine of a DIFFERENT KB/installer (#8/#11). The
    extraction now lands in a staging dir and is swapped in only on success."""
    if source is None:
        source = {"installer": _state.file_fingerprint(exe_path)}
    if _state.is_complete(out_dir, source):
        return out_dir   # already extracted from this exact source (resume)
    partial = _state.begin(out_dir)
    try:
        _extract_engine_into(exe_path, partial, cab_dir, str(out_dir) + "_msp")
        if not any(x.startswith("ENG_") for x in os.listdir(lp(partial))):
            raise RuntimeError("engine extraction produced no ENG_* files")
    except BaseException:
        _state.abandon(partial)
        raise
    _state.commit(out_dir, partial, source)
    return out_dir


def _extract_engine_into(exe_path, out_dir, cab_dir, msp_stage):
    _carve_cabs(exe_path, cab_dir)
    # extract the biggest cabs (the engine MSP lives in one of them) until we find it
    cabs = sorted((os.path.join(cab_dir, f) for f in os.listdir(lp(cab_dir)) if f.endswith(".cab")),
                  key=lambda p: os.path.getsize(lp(p)), reverse=True)
    if not cabs:
        raise RuntimeError(
            f"No MSCF cabinet found in {os.path.basename(exe_path)}. "
            "The installer format may have changed — check that the .exe is the correct SQL Server patch."
        )
    # The MSP staging dir is an intermediate of THIS extraction: 7-Zip overwrites into it and
    # _find_engine_msp() takes whatever MSP it finds, so one left by an earlier run over a
    # different installer would be extracted instead of this one's (same class as #31).
    import shutil
    if os.path.isdir(lp(msp_stage)):
        shutil.rmtree(lp(msp_stage))
    os.makedirs(lp(msp_stage), exist_ok=True)
    engine_msp = None
    for cab in cabs[:20]:
        _7z_extract(cab, msp_stage)
        engine_msp = _find_engine_msp(msp_stage)   # recursive + case-insensitive
        if engine_msp:
            break
    if not engine_msp:
        raise RuntimeError("SQL_ENGINE_CORE_INST.MSP not found in patch payload")
    _7z_extract(engine_msp, out_dir)
    return out_dir


def acquire(patch, workdir, progress=None, online=True, sides=("vuln", "fixed")):
    """Download + extract the requested build(s) (default: both). Returns a dict with
    only the key(s) for the requested `sides`, e.g. {'vuln': dir} or {'fixed': dir, 'vuln': dir}.
    `patch` = dict with kb/fixed_build/vuln_build/vuln_kb/dl_url/vuln_dl_url.
    progress(pct, phase) reports 0..100 across the whole acquire step."""
    def rep(pct, phase):
        if progress:
            progress(pct, phase)

    sides_out = {}
    plan_all = [("vuln",  patch.get("vuln_kb"),  patch.get("vuln_build"),  patch.get("vuln_dl_url")),
                ("fixed", patch.get("kb"),        patch.get("fixed_build"), patch.get("dl_url"))]
    # weight: vuln dl 0-35, fixed dl 35-70, extract 70-100 — idx stays tied to each side's
    # fixed position in plan_all (0=vuln, 1=fixed) even when `sides` restricts to one side,
    # so a single-side call still reports sane percentages instead of both starting at 0.
    for idx, (side, kb, build, page) in enumerate(plan_all):
        if side not in sides:
            continue
        sd = os.path.join(workdir, "acquire", side)
        os.makedirs(lp(sd), exist_ok=True)
        eng = os.path.join(sd, "engine")
        source = {"kb": str(kb)}
        # #8/#11: reuse only an engine that finished extracting from THIS KB.
        if _state.is_complete(eng, source):
            sides_out[side] = eng
            rep(70 if side == "fixed" else 35, f"{side} build already extracted")
            continue
        exe = os.path.join(sd, f"KB{kb}.exe")
        if not os.path.exists(lp(exe)):
            if not online:
                raise RuntimeError(f"offline: {side} package not downloaded yet (need internet)")
            rep(5 + idx * 35, f"Resolving {side} download ({build})")
            url = resolve_exe_url(kb, page)
            rep(8 + idx * 35, f"Downloading {side} package KB{kb} ({build})")
            download(url, exe, progress=(lambda p: rep(p, f"Downloading {side} KB{kb}"))
                     if progress else None, base_pct=8 + idx * 35, span_pct=27)
        rep(72 if side == "fixed" else 37, f"Extracting {side} engine files ({build})")
        extract_engine(exe, eng, os.path.join(sd, "cabs"), source=source)
        # temp cleanup: drop the big intermediates now that engine/ is extracted
        _prune(exe, os.path.join(sd, "cabs"), eng + "_msp")
        sides_out[side] = eng
    rep(100, "Acquire complete")
    return sides_out


def _prune(*paths):
    import shutil
    for p in paths:
        try:
            if os.path.isdir(lp(p)):
                shutil.rmtree(lp(p), ignore_errors=True)
            elif os.path.isfile(lp(p)):
                os.remove(lp(p))
        except Exception:
            pass