"""MSSQL Stage-2 symbols: fetch the public PDB, resolve RVA -> function name.

MSSQL engine DLLs are stripped, but Microsoft publishes their PDBs on the public
symbol server. Given an image's CodeView key (name + GUID + age, from `_pe.debug_pdb`)
we download `msdl.microsoft.com/download/symbols/<name>/<GUID><AGE>/<name>` and load it
with the OS `dbghelp.dll` (via ctypes — no pip dependency) to enumerate every function
symbol. That gives us real, undecorated names for BOTH function matching across builds
and CVE attribution — the same leverage the DB2 backend gets from ELF `.symtab`.

Windows-only (dbghelp). On any failure (offline, PDB missing, non-Windows) the caller
falls back to RVA-labelled functions, so Stage 2 still runs, just anonymously.

TLS note: corporate proxies MITM outbound HTTPS. `requests` honours REQUESTS_CA_BUNDLE
automatically; set PATCHDIFF_INSECURE_TLS=1 to skip verification for a spike.
"""
import bisect
import ctypes as _c
import os
import struct
import tempfile

import requests

from ._pe import debug_pdb, symbol_key
from ..db2._paths import lp

_MSDL = "https://msdl.microsoft.com/download/symbols"
_UA = {"User-Agent": "Microsoft-Symbol-Server/10.0"}


def _verify():
    if os.environ.get("PATCHDIFF_INSECURE_TLS") == "1":
        try:
            import urllib3
            urllib3.disable_warnings()
        except Exception:
            pass
        return False
    return os.environ.get("REQUESTS_CA_BUNDLE") or True


def pdb_url(name, guid, age):
    return f"{_MSDL}/{name}/{symbol_key(guid, age)}/{name}"


def server_reachable(timeout=5):
    """True if the Microsoft symbol server responds at all.

    Uses the SAME requests/TLS(_verify)/UA settings as fetch_pdb, so the reachability
    check can't disagree with the real download path. ANY HTTP response counts as
    reachable — the server answering (even 404/403) proves connectivity; only a
    connection error or timeout means offline. This is deliberately different from a
    plain urllib.urlopen probe, which raises on any non-2xx and so falsely reports
    'offline' whenever the host answers with an error status."""
    try:
        r = requests.get(_MSDL, headers=_UA, timeout=timeout,
                         verify=_verify(), stream=True)
        r.close()
        return True
    except Exception:
        return False


def fetch_pdb(dll_path, cache_root, online=True):
    """Download the image's public PDB into `cache_root/<name>_<key>/<name>` and return
    that path (symbol-server-style dir so dbghelp validates by GUID). Returns the local
    path if already cached; None if we can't get it (offline, 404, no debug record)."""
    info = debug_pdb(dll_path)
    if not info:
        return None
    name, guid, age = info
    d = os.path.join(cache_root, f"{name}_{symbol_key(guid, age)}")
    dest = os.path.join(d, name)
    if os.path.isfile(lp(dest)):
        if _pdb_complete(dest):
            return dest
        # a truncated file from an interrupted download by an older version, which wrote
        # straight to `dest` — never trust it; drop it and fetch again
        try:
            os.remove(lp(dest))
        except OSError:
            return None     # can't replace it (e.g. open elsewhere) — and can't trust it
    if not online:
        return None
    os.makedirs(lp(d), exist_ok=True)
    for url in (pdb_url(name, guid, age),):
        tmp = None
        try:
            r = requests.get(url, headers=_UA, timeout=180, verify=_verify(), stream=True)
            if r.status_code != 200:
                r.close(); continue
            # bugs.md #32: this used to write straight to `dest`, so a concurrent worker
            # (Stage 2 runs DLLs in parallel over one shared cache) — or any later run after
            # an interrupted download — saw a non-empty partial PDB and used it. Download to
            # a private temp file, check it's complete, and only then rename it into place
            # (atomic on one volume), so `dest` is either absent or complete.
            fd, tmp = tempfile.mkstemp(prefix=name + ".", suffix=".part", dir=lp(d))
            n = 0
            with os.fdopen(fd, "wb") as f:
                for blk in r.iter_content(1 << 20):
                    if blk:
                        f.write(blk)
                        n += len(blk)
            expected = r.headers.get("Content-Length")
            r.close()
            if not n or (expected and expected.isdigit()
                         and int(expected) != n and not r.headers.get("Content-Encoding")):
                continue
            if not _pdb_complete(tmp):
                continue
            try:
                os.replace(tmp, lp(dest))
            except OSError:
                # another worker installed it first and it's open — theirs is complete too
                if os.path.isfile(lp(dest)) and _pdb_complete(dest):
                    return dest
                raise
            tmp = None
            return dest
        except Exception:
            continue
        finally:
            if tmp is not None:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    return None


_MSF7 = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\0\0\0"


def _pdb_complete(path):
    """False when `path` is empty or an MSF 7.00 PDB shorter than its superblock says
    (BlockSize * NumBlocks) — i.e. truncated. A non-MSF file (some other symbol format) is
    accepted as before, as long as it's non-empty: only provable truncation is rejected."""
    try:
        size = os.path.getsize(lp(path))
        with open(lp(path), "rb") as f:
            hdr = f.read(56)
    except OSError:
        return False
    if not size:
        return False
    if hdr.startswith(_MSF7[:len(hdr)]) and len(hdr) < len(_MSF7) + 24:
        return False                        # cut off inside the superblock itself
    if hdr.startswith(_MSF7):
        block, nblocks = struct.unpack_from("<I", hdr, 32)[0], struct.unpack_from("<I", hdr, 40)[0]
        return block in (512, 1024, 2048, 4096, 8192, 16384, 32768) and size >= block * nblocks
    return True


# --------------------------------------------------------------------------- dbghelp
_SYMOPT_UNDNAME = 0x00000002
_SYMOPT_DEFERRED_LOADS = 0x00000004
_SYMOPT_EXACT_SYMBOLS = 0x00000400
_handle_seq = 0x4000


class _SYMBOL_INFO(_c.Structure):
    _fields_ = [("SizeOfStruct", _c.c_ulong), ("TypeIndex", _c.c_ulong),
                ("Reserved", _c.c_ulonglong * 2), ("Index", _c.c_ulong),
                ("Size", _c.c_ulong), ("ModBase", _c.c_ulonglong),
                ("Flags", _c.c_ulong), ("Value", _c.c_ulonglong),
                ("Address", _c.c_ulonglong), ("Register", _c.c_ulong),
                ("Scope", _c.c_ulong), ("Tag", _c.c_ulong), ("NameLen", _c.c_ulong),
                ("MaxNameLen", _c.c_ulong), ("Name", _c.c_char * 2000)]

_ENUMPROC = _c.WINFUNCTYPE(_c.c_int, _c.POINTER(_SYMBOL_INFO), _c.c_ulong, _c.c_void_p) \
    if os.name == "nt" else None


class Symbolizer:
    """Maps an image's function-start RVAs to names using its PDB (dbghelp).

    Build once per (dll, pdb); call `name_at(begin_rva)` for each `.pdata` range.
    Falls back to None for ranges with no owning symbol."""

    def __init__(self, dll_path, pdb_path):
        self.ok = False
        self._rvas = []
        self._names = {}
        if os.name != "nt" or not pdb_path:
            return
        try:
            self._dbg = _c.WinDLL("dbghelp.dll")
        except Exception:
            return
        global _handle_seq
        _handle_seq += 1
        self._h = _c.c_void_p(_handle_seq)
        self._base = 0x10000000
        self._loaded = False
        self._dbg.SymSetOptions(_SYMOPT_UNDNAME | _SYMOPT_DEFERRED_LOADS
                                | _SYMOPT_EXACT_SYMBOLS)
        search = os.path.dirname(lp(pdb_path))
        if not self._dbg.SymInitialize(self._h, _c.c_char_p(search.encode("latin-1", "replace")), False):
            return
        img = lp(dll_path)
        b = self._dbg.SymLoadModuleExW(self._h, None, _c.c_wchar_p(img), None,
                                       _c.c_ulonglong(self._base), 0, None, 0)
        if not b:
            self._cleanup(); return
        self._loaded = True
        self._enum()
        self.ok = bool(self._names)

    def _enum(self):
        base = self._base
        names = self._names

        def cb(psym, size, ctx):
            s = psym.contents
            rva = int(s.Address) - base
            if rva < 0:
                return True
            nm = s.Name.decode("latin-1", "replace")
            if nm and (rva not in names or len(nm) < len(names[rva])):
                names[rva] = nm         # prefer the shorter/base symbol at a given RVA
            return True

        try:
            self._dbg.SymEnumSymbols(self._h, _c.c_ulonglong(base), _c.c_char_p(b"*"),
                                     _ENUMPROC(cb), None)
        except Exception:
            pass
        self._rvas = sorted(names.keys())

    def name_at(self, begin_rva):
        """Name of the function owning `begin_rva`: exact symbol, else the greatest
        symbol RVA <= begin_rva (a chained/EH-funclet continuation folds to its owner).
        Use for resolving a CALL TARGET (which may land mid-function)."""
        n = self._names.get(begin_rva)
        if n:
            return n
        i = bisect.bisect_right(self._rvas, begin_rva) - 1
        if i >= 0:
            return self._names.get(self._rvas[i])
        return None

    def exact_name(self, begin_rva):
        """Name of the symbol that starts EXACTLY at `begin_rva`, or None. Use for KEYING a
        function: bisect-folding (name_at) would fold an unnamed static function onto its
        named neighbour, so two unrelated functions collide on one name and the larger body
        masks/fabricates a diff (the ISECManager::GetExecuteAsOwnerId false positive)."""
        return self._names.get(begin_rva)

    def _cleanup(self):
        try:
            self._dbg.SymCleanup(self._h)
        except Exception:
            pass

    def close(self):
        if getattr(self, "_loaded", False):
            try:
                self._dbg.SymUnloadModule64(self._h, _c.c_ulonglong(self._base))
            except Exception:
                pass
            self._cleanup()
            self._loaded = False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()