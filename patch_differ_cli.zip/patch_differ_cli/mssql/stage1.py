"""Stage 1 — readable T-SQL diff, fully OFFLINE (no SQL Server instance).

Three passes:
  * System objects — definitions are stored largely as ASCII text inside the resource DB
    (mssqlsystemresource.mdf). We carve them (CREATE PROC/FUNCTION/VIEW/TRIGGER <name>,
    grab the printable run to a 4-byte non-printable boundary), diff prior vs fixed, and
    write one complete unified diff per changed, added or removed object.
  * Loose readable files (msdb_upgrade.sql, XTP codegen headers, ...), incl. added/removed.
  * T-SQL embedded in script-bearing DLLs (sqlscriptupgrade.dll, ...), incl. added/removed.
Only the first pass needs the resource DB. If it's missing on either side, that pass is
skipped and recorded in the result's `unavailable_parts` (logged; the CLI reports it as a
partial failure, exit 3) while the other two passes still run.

Output: <workdir>/stage1/{modules_diff.json, <object>.sql.diff}
Best-effort: definitions spanning >1 MDF page may truncate, but it's deterministic
and stable for diffing (validated: 3605 objects/build).
"""
import difflib
import json
import os
import re
import struct
import sys

from .. import _attribution as _AT
from ..db2._paths import lp, safe_name

_PRINT = set(range(0x20, 0x7f)) | {0x09, 0x0a, 0x0d}

# ---- embedded T-SQL carried inside script-bearing PEs (sqlscriptupgrade.dll etc.) --------
# The msdb/agent + install/upgrade T-SQL ships as string data INSIDE a PE. `_is_text()`
# rejects anything starting with 'MZ', so the loose-text pass never sees it, and Stage 2's
# function diff can't read script text — a blind spot that hid the msdb SQL-injection
# (QUOTENAME) hardening. This pass carves the T-SQL strings from those PEs and diffs them.
_SQL_PE_HINT = re.compile(r"sqlscript|instmsdb|instdist|msdb|upgrade|dbupgrade|script", re.I)
_SQLISH = re.compile(
    r"QUOTENAME|EXEC\s*\(|EXECUTE\s*\(|CREATE\s+PROC|GRANT\s|DENY\s|REVOKE\s|"
    r"sp_[a-z]|xp_[a-z]|DECLARE\s+@|SELECT\s|INSERT\s|UPDATE\s|DELETE\s|sysadmin|sqlagent",
    re.I)
_CRE = re.compile(r"CREATE\s+(?:PROC(?:EDURE)?|FUNCTION|VIEW|TRIGGER)\s+([\[\]\w\.]+)", re.I)
_FILL = re.compile(r"!{4,}")                      # SQL Server record free-space fill run
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]+")

# ---- off-row LOB reconstruction (recovers >8 KB definitions the in-row carve cuts) ----
_PAGE = 8192


def _slot_off(raw, page, slot):
    """Physical offset within `page` of `slot`, read from the page's trailing slot array."""
    return struct.unpack_from("<H", raw, page * _PAGE + _PAGE - 2 - 2 * slot)[0]


def _first_frag(raw, create_off):
    """The (page, slot) of the LOB DATA fragment that holds `create_off`. The module
    text's first fragment lives on a TEXT_MIX page (type 3); it's the slot whose
    physical offset is the greatest one at/below the CREATE offset (slot order on a
    page is not physical order)."""
    pg = create_off // _PAGE
    pbase = pg * _PAGE
    if pbase + 0x18 > len(raw) or raw[pbase + 1] != 3:      # not a TEXT_MIX page
        return None
    within = create_off - pbase
    sc = struct.unpack_from("<H", raw, pbase + 0x16)[0]
    best = None
    for s in range(sc):
        so = _slot_off(raw, pg, s)
        if 96 <= so <= within and (best is None or so > best[1]):
            best = (s, so)
    return (pg, best[0]) if best else None


def _walk_links(raw, rid_pos, hw):
    """Parse a LOB link array whose FIRST entry's RowID sits at `rid_pos`. Two on-disk
    layouts exist, selected by `hw` (the header width before each RowID):
      hw=4  in-row LARGE_ROOT      entry = [cumlen(4)][RowID(8)]           (stride 12)
      hw=8  text-tree INTERNAL node entry = [cumlen(4)][pad(4)][RowID(8)]  (stride 16)
    RowID = page(4) file(2) slot(2); cumlen is the cumulative byte length through that
    fragment. Returns [(page, slot, frag_len), ...] of the TEXT_MIX (type 3) data
    fragments in order, or None. The structural checks (>=2 links, all to type-3 pages,
    strictly-increasing cumulatives each <= one page) reject byte-pattern collisions, so
    we don't need to know where the root lives."""
    stride = hw + 8
    p, prev, parts = rid_pos - hw, 0, []
    while p >= 0 and p + stride <= len(raw) and len(parts) < 4096:
        cum = struct.unpack_from("<I", raw, p)[0]
        pid, fid, slot = struct.unpack_from("<IHH", raw, p + hw)
        delta = cum - prev
        if (not 0 < pid < len(raw) // _PAGE or fid != 1 or raw[pid * _PAGE + 1] != 3
                or delta < 1 or delta > _PAGE):
            break
        parts.append((pid, slot, delta))
        prev = cum
        p += stride
    return parts if len(parts) >= 2 else None


def _lob_reconstruct(raw, create_off):
    """Recover a full module definition stored off-row as a LOB.

    Large system-object text is stored as an off-row LOB: the first fragment sits on a
    TEXT_MIX page (type 3) and begins with `CREATE ...` (so the in-row carve finds it) but
    holds only ~8 KB; the rest live on other TEXT_MIX pages. An ordered link array points
    at every fragment — held in-row as a LARGE_ROOT for medium blobs, or on an INTERNAL
    text-tree node (type 4) for larger ones. We locate that array by the first fragment's
    RowID, validate the chain structurally (handling both layouts and rejecting collisions),
    take the longest valid chain, and concatenate each fragment's exact byte slice.

    Returns the full text, or None if the chain can't be followed offline (e.g. a
    multi-level text-tree) — the caller then keeps the truncated in-row carve.
    """
    try:
        ff = _first_frag(raw, create_off)
        if not ff:
            return None
        fp, fs = ff
        rid = struct.pack("<IHH", fp, 1, fs)
        best, i = None, 0
        while True:
            j = raw.find(rid, i)
            if j < 0:
                break
            for hw in (4, 8):                    # try both root/internal-node layouts
                parts = _walk_links(raw, j, hw)  # j is link #1's RowID => chain starts here
                if parts and (best is None or len(parts) > len(best)):
                    best = parts                 # the real chain lists ALL fragments (longest)
            i = j + 1
        if not best:
            return None
        out = bytearray()
        for pg, sl, ln in best:
            s = pg * _PAGE + _slot_off(raw, pg, sl) + 14    # 14-byte fragment header
            out += raw[s:s + ln]
        txt = _CTRL.sub("", out.decode("latin-1")).rstrip(" \t\r\n`")
        # guard against a wrong-stride chain: real module text is ~100% printable SQL.
        if not txt:
            return None
        printable = sum(1 for c in txt if 0x20 <= ord(c) < 0x7f or ord(c) in (9, 10, 13))
        if printable / len(txt) < 0.98:
            return None
        return txt
    except Exception:
        return None


def _find_resource_mdf(engine_dir):
    for f in os.listdir(lp(engine_dir)):
        if "ResourceDb" in f and f.endswith("mdf_64"):
            return os.path.join(engine_dir, f)
    # fallback: any *ResourceDb*mdf*
    for f in os.listdir(lp(engine_dir)):
        if "ResourceDb" in f and "mdf" in f.lower():
            return os.path.join(engine_dir, f)
    return None


def _carve(mdf_path):
    """Extract each system object's definition text. Keeps the LONGEST clean copy per
    object (the resource DB holds an in-row copy that can truncate at ~8 KB plus a
    fuller LOB copy), stops at record free-space fill (`!!!!`) or a run of non-printable
    bytes, and strips trailing record padding. Returns {name: (text, truncated)}.

    Definitions over ~8 KB overflow off-row to non-adjacent LOB pages; when the in-row
    carve hits that limit we follow the LOB link chain (`_lob_reconstruct`) to recover
    the full text. Only the rare cases that reconstruction can't follow (text-trees with
    INTERNAL nodes) stay flagged truncated."""
    with open(lp(mdf_path), "rb") as f:
        raw = f.read()
    b = raw.decode("latin-1")                  # latin-1 is 1:1 so char offset == byte offset
    best = {}                                  # name -> (text, truncated)
    for m in _CRE.finditer(b):
        start = m.start()
        name = m.group(1).strip("[]").lower()
        i, run, cap = m.end(), 0, start + 200000
        while i < len(b) and i < cap:
            if ord(b[i]) in _PRINT:
                run = 0
            else:
                run += 1
                if run >= 4:
                    break
            i += 1
        # The run>=4 terminator tolerates <=3 isolated control bytes, which lets a value
        # stitch across small in-row chunk gaps (fuller text). Those interior bytes are
        # byte-split joins, so drop ALL control bytes (keeping only \t \r \n) to rejoin
        # the text cleanly, then cut '!!!!' free-space fill and trim trailing padding.
        seg = _CTRL.sub("", b[start:i])
        fm = _FILL.search(seg)
        if fm:
            seg = seg[:fm.start()]
        seg = seg.rstrip(" \t\r\n`")
        # A definition that reaches the ~8 KB single-page limit has overflowed off-row to
        # a LOB -> follow the link chain to recover the rest; only fall back to the
        # (truncated) in-row copy if the LOB isn't a flat-root we can walk offline.
        trunc = len(seg) >= 7900
        if trunc:
            full = _lob_reconstruct(raw, start)
            if full and len(full) > len(seg):
                seg, trunc = full, False
        if len(seg) > 40 and len(seg) > len(best.get(name, ("",))[0]):
            best[name] = (seg, trunc)      # keep the fullest copy across occurrences
    return best


def _safe(name):
    return safe_name(name, 120)


def _is_text(path):
    """True if a file is readable text (not a PE, not the binary resource DB)."""
    try:
        with open(lp(path), "rb") as f:
            b = f.read(16384)
    except OSError:
        return False
    if not b or b[:2] == b"MZ":               # PE (dll/exe)
        return False
    printable = sum(1 for c in b if 0x20 <= c < 0x7f or c in (9, 10, 13))
    return printable / len(b) > 0.90


def _pretty_file(name):
    """ENG_RE_/MPT_ cab key -> a friendly file name (MPT_msdb_upgrade_sql_64 ->
    msdb_upgrade.sql, ENG_XTP_Gen_hkrtdef_64 -> hkrtdef)."""
    n = name
    for pre in ("ENG_RE_", "ENG_SEI_", "ENG_XTP_Gen_", "ENG_", "MPT_", "KF"):
        if n.startswith(pre):
            n = n[len(pre):]
            break
    return n.replace("_sql_64", ".sql").replace("_64", "")


def _extract_strings(path, minlen=8):
    """Long printable strings (ASCII + UTF-16LE) in a file — the T-SQL is stored as both.

    Runs are line-granular (printable bytes only, NOT \\r\\n/\\t): including newlines would
    merge whole statement blocks into one multi-line string, which then differs wholesale
    whenever the build shifts layout — turning a ~50-line real diff into a ~125k-line one."""
    with open(lp(path), "rb") as f:
        d = f.read()
    out = set()
    for m in re.finditer(rb"[\x20-\x7e]{%d,}" % minlen, d):
        out.add(m.group().decode("latin-1"))
    for m in re.finditer(rb"(?:[\x20-\x7e]\x00){%d,}" % minlen, d):
        out.add(m.group().decode("utf-16le"))
    return out


def _paired_files(prior_dir, fixed_dir):
    """[(prior_name|None, fixed_name|None, change)] for every entry of the two engine dirs,
    paired exactly as Stage 0 pairs them (case-insensitive on Windows). change is
    "modified" (both sides; may still be identical), "added" or "removed"."""
    from .triage import _pair_names
    pairs, only_fixed, only_prior = _pair_names(prior_dir, fixed_dir)
    out = ([(p, f, "modified") for p, f in pairs]
           + [(None, f, "added") for f in only_fixed]
           + [(p, None, "removed") for p in only_prior])
    return sorted(out, key=lambda t: ((t[1] or t[0]).lower(), t[2]))


def _embedded_sql(prior_dir, fixed_dir, out, attrib, errors=None):
    """Diff embedded T-SQL between the two builds for every changed script-bearing PE.
    Returns readable_files-shaped cards (same fields the loose-text pass emits, plus a
    fix_score when a hunk adds QUOTENAME()/parameterized EXEC — the SQLi-neutralization
    shape). Never raises for an unreadable file: bugs.md #35 — a read failure used to be
    skipped with no trace, so the DLL's T-SQL changes vanished from a clean-looking
    result; each one is now appended to `errors` (Stage 1's own list -> exit 3)."""
    cards = []
    errors = errors if errors is not None else []
    try:
        entries = _paired_files(prior_dir, fixed_dir)
    except OSError as exc:
        errors.append({"name": "(embedded T-SQL pass)",
                       "error": f"could not list the engine dirs: {exc}"})
        return cards
    # bugs.md #3: an added (or removed) script-bearing DLL's T-SQL is shown too — it used to
    # be skipped because only DLLs present on both sides were looked at.
    for pf, ff, _change in entries:
        f = ff or pf
        if "ResourceDb" in f or not _SQL_PE_HINT.search(f):
            continue
        pa = os.path.join(prior_dir, pf) if pf else None
        pb = os.path.join(fixed_dir, ff) if ff else None
        try:
            present = [p for p in (pa, pb) if p]
            if not all(os.path.isfile(lp(p)) for p in present):
                continue
            with open(lp(present[0]), "rb") as fh:
                if fh.read(2) != b"MZ":          # PE only; loose .sql handled by run()'s text pass
                    continue
            A = {s for s in _extract_strings(pa) if _SQLISH.search(s)} if pa else set()
            B = {s for s in _extract_strings(pb) if _SQLISH.search(s)} if pb else set()
        except OSError as exc:
            errors.append({"name": f, "error": f"embedded T-SQL not extracted: {exc}"})
            continue
        onlyP, onlyF = sorted(A - B), sorted(B - A)
        if not (onlyP or onlyF):
            continue
        name = _pretty_file(f) + " (embedded T-SQL)"
        base = "sql__" + _safe(_pretty_file(f))
        diff = "".join(difflib.unified_diff(
            [l + "\n" for l in onlyP], [l + "\n" for l in onlyF],
            fromfile=f"{name} (prior-only T-SQL)", tofile=f"{name} (fixed-only T-SQL)", n=0))
        with open(lp(os.path.join(out, base + ".diff")), "w", encoding="utf-8") as fh:
            fh.write(diff or "(no T-SQL string differences)\n")
        with open(lp(os.path.join(out, base + ".pair.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": name, "prior": "\n".join(onlyP),
                       "fixed": "\n".join(onlyF), "truncated": False}, fh)
        # fix-shape: fixed adds QUOTENAME()/parameterized EXEC where prior concatenated raw
        norm = lambda s: s.replace(" ", "").upper()
        addedq = any("QUOTENAME(" in s.upper() or "EXEC(@" in norm(s) for s in onlyF)
        rawexec = any("EXEC(" in norm(s) and "QUOTENAME" not in s.upper() for s in onlyP)
        fix_score, fix_why = 0, ""
        if addedq:
            fix_score = 9 if rawexec else 6
            fix_why = "added QUOTENAME()/parameterized EXEC (SQL-injection neutralization)"
        # NOTE: tracked CVEs that share a CWE and carry the generic MSRC description (e.g.
        # CVE-2026-32167 and -32176 are both CWE-89 "SQL injection ... in SQL Server" with an
        # identical desc/component in the CVE record) are indistinguishable from metadata; the
        # quoting-primitive match ties and one is chosen. That's a data limit, not a miss — the
        # card is still surfaced and flagged fix-shaped for the analyst to assign.
        cve, why, _conf = _AT.attribute(" ".join(onlyF)[:4000], attrib)
        card = {"object": name, "file": base + ".diff", "pair": base + ".pair.json",
                "src": f, "group": "embedded T-SQL", "kind": "tsql",
                "similarity": 0.0, "fix_score": fix_score, "fix_why": fix_why}
        # assert a CVE only when a real fix corroborates the name/CWE match (else candidate)
        if cve and fix_score > 0:
            card["cve"], card["why"] = cve, why
        elif cve:
            card["cve_candidate"], card["why"] = cve, why
        cards.append(card)
    return cards


def run(prior_dir, fixed_dir, workdir, stage0=None, progress=None):
    """Diff system objects, loose readable files and embedded T-SQL between the two builds.
    Returns a summary and writes stage1/. Without the resource MDF on both sides, the
    system-object pass is skipped and listed in `unavailable_parts`; the rest still runs."""
    out = os.path.join(workdir, "stage1")
    os.makedirs(lp(out), exist_ok=True)
    if progress:
        progress(5, "Locating resource database")
    a_mdf = _find_resource_mdf(prior_dir)
    b_mdf = _find_resource_mdf(fixed_dir)
    # Only the system-object diff needs the resource DB. It used to gate the WHOLE stage:
    # without it, loose readable scripts and embedded T-SQL — which don't depend on it —
    # were skipped too. Now just this part is marked unavailable (still flagged by the CLI
    # as a partial failure) and the other passes run regardless. With the resource DB on
    # only ONE side its objects are NOT reported as all-added/all-removed: that would flood
    # the report with thousands of false "added" system procedures.
    unavailable_parts = []
    missing = [s for s, m in (("prior", a_mdf), ("fixed", b_mdf)) if not m]
    if missing:
        reason = (f"resource DB (mssqlsystemresource.mdf) not found on the "
                  f"{' and '.join(missing)} side{'s' if len(missing) > 1 else ''}")
        unavailable_parts.append({"part": "system objects", "reason": reason})
        print(f"WARNING: {reason} — system objects (procedures, views, functions) could not "
              f"be diffed; loose readable files and embedded T-SQL are still diffed.",
              file=sys.stderr)
        A = B = {}
    else:
        if progress:
            progress(30, "Carving prior system objects")
        A = _carve(a_mdf)
        if progress:
            progress(60, "Carving fixed system objects")
        B = _carve(b_mdf)
    if progress:
        progress(85, "Diffing system-object definitions")

    changed, added, removed, files = [], [], [], []
    for n in sorted(set(A) & set(B)):
        a_txt, a_tr = A[n]
        b_txt, b_tr = B[n]
        if a_txt != b_txt:
            changed.append(n)
            trunc = a_tr or b_tr
            # full-context unified diff (whole proc, not just hunks) for the raw view
            diff = "".join(difflib.unified_diff(
                a_txt.splitlines(keepends=True), b_txt.splitlines(keepends=True),
                fromfile=f"{n} (prior)", tofile=f"{n} (fixed)", n=100000))
            fn = _safe(n) + ".sql.diff"
            with open(lp(os.path.join(out, fn)), "w", encoding="utf-8") as f:
                f.write(diff)
            # full before/after for the split-view popup
            pair_fn = _safe(n) + ".pair.json"
            with open(lp(os.path.join(out, pair_fn)), "w", encoding="utf-8") as f:
                json.dump({"object": n, "prior": a_txt, "fixed": b_txt, "truncated": trunc}, f)
            files.append({"object": n, "file": fn, "pair": pair_fn, "truncated": trunc,
                          "change": "modified"})
    added = sorted(set(B) - set(A))
    removed = sorted(set(A) - set(B))
    # bugs.md #3: an added/removed system object used to be listed by NAME only — a new
    # validation procedure shipped by a fix showed up without its definition. Write its
    # full text as a one-sided pair, same as a changed object.
    for n, (txt, tr), change in ([(n, B[n], "added") for n in added]
                                 + [(n, A[n], "removed") for n in removed]):
        a_side, b_side = ("", txt) if change == "added" else (txt, "")
        diff = "".join(difflib.unified_diff(
            a_side.splitlines(keepends=True), b_side.splitlines(keepends=True),
            fromfile=f"{n} (prior)", tofile=f"{n} (fixed)", n=100000))
        fn = _safe(n) + ".sql.diff"
        with open(lp(os.path.join(out, fn)), "w", encoding="utf-8") as f:
            f.write(diff)
        pair_fn = _safe(n) + ".pair.json"
        with open(lp(os.path.join(out, pair_fn)), "w", encoding="utf-8") as f:
            json.dump({"object": n, "prior": a_side, "fixed": b_side, "truncated": tr}, f)
        files.append({"object": n, "file": fn, "pair": pair_fn, "truncated": tr,
                      "change": change})

    # ---- loose readable text files (msdb_upgrade.sql, XTP codegen headers, ...) ----
    if progress:
        progress(92, "Diffing readable files")
    readable_files, errors = [], []
    # bugs.md #3: every readable file, not just the ones present on BOTH sides — an added
    # script (e.g. a new hardening .sql) or a removed one used to get no diff at all. Pairing
    # matches triage (case-insensitive on Windows), so the two stages agree on what's
    # "the same file".
    for pf, ff, change in _paired_files(prior_dir, fixed_dir):
        f = ff or pf
        try:
            if "ResourceDb" in f:
                continue
            if not all(_is_text(os.path.join(d, n)) for d, n in ((prior_dir, pf), (fixed_dir, ff)) if n):
                continue
            ta = tb = ""
            if pf:
                with open(lp(os.path.join(prior_dir, pf)), encoding="latin-1") as fh:
                    ta = fh.read()
            if ff:
                with open(lp(os.path.join(fixed_dir, ff)), encoding="latin-1") as fh:
                    tb = fh.read()
            if change == "modified" and ta == tb:
                continue
            name = _pretty_file(f)
            base = "file__" + _safe(name)
            # small raw diff (n=3 — these files can be huge; the popup shows full via pair)
            diff = "".join(difflib.unified_diff(ta.splitlines(keepends=True),
                                                tb.splitlines(keepends=True),
                                                fromfile=f"{name} (prior)", tofile=f"{name} (fixed)", n=3))
            with open(lp(os.path.join(out, base + ".diff")), "w", encoding="utf-8") as fh:
                fh.write(diff)
            with open(lp(os.path.join(out, base + ".pair.json")), "w", encoding="utf-8") as fh:
                json.dump({"object": name, "prior": ta, "fixed": tb, "truncated": False}, fh)
            readable_files.append({"object": name, "file": base + ".diff",
                                   "pair": base + ".pair.json", "src": f, "change": change})
        except Exception as exc:
            # One unreadable/vanished file must not abort the whole Stage 1 run — record
            # it and keep going (the same per-item isolation Stage 0 already applies).
            errors.append({"name": f, "error": str(exc)})

    # ---- embedded T-SQL inside script-bearing PEs (sqlscriptupgrade.dll, ...) ----
    if progress:
        progress(96, "Diffing embedded T-SQL in script binaries")
    try:
        attrib = _AT.load_attrib(workdir)
    except Exception:
        attrib = []
    embedded = _embedded_sql(prior_dir, fixed_dir, out, attrib, errors)
    readable_files.extend(embedded)

    result = {
        "available": True,
        "counts": {"prior": len(A), "fixed": len(B),
                   "changed": len(changed), "added": len(added), "removed": len(removed),
                   "truncated": sum(1 for f in files if f.get("truncated")),
                   "readable_changed": len(readable_files),
                   "embedded_sql": len(embedded), "errors": len(errors)},
        "changed": changed, "added": added, "removed": removed,
        "files": files, "readable_files": readable_files, "errors": errors,
        # parts of this stage that could not run, with why (empty when everything ran)
        "unavailable_parts": unavailable_parts,
    }
    with open(lp(os.path.join(out, "modules_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 1 complete")
    return result