"""Stage 0 — file triage by PE CODE SECTION, not whole-file hash.

MS recompiles the whole engine every servicing release, so ~all files differ by
whole-file hash (version/.rdata/.rsrc churn). Comparing executable sections (.text)
separates real code changes from rebuild noise. Non-PE files (resource-db .mdf,
.sql, .lib) fall back to a whole-file hash compare.

Output: <workdir>/stage0/changed_files.json — the categorized work set.
"""
import hashlib
import json
import os

import pefile

from ..db2._paths import lp


class PEParseError(Exception):
    """A file that IS a PE (MZ header) could not be parsed, or is truncated."""


def _code_sig(path):
    """Hashes of executable sections; None if the file is not a PE at all.

    Raises PEParseError for a file that looks like a PE but can't be trusted (bugs.md #6).
    Both cases used to return None, so a damaged or partially-downloaded DLL was treated as
    ordinary non-PE "content" (never reaching Stage 2, never counted as an error), and a
    DLL truncated AFTER its code section hashed identically to the good build and was
    discarded as rebuild-only."""
    try:
        with open(lp(path), "rb") as fh:
            is_mz = fh.read(2) == b"MZ"
    except OSError as exc:
        raise PEParseError(f"cannot read file: {exc}") from exc
    try:
        pe = pefile.PE(lp(path), fast_load=True)
    except Exception as exc:
        if is_mz:
            raise PEParseError(f"has a PE (MZ) header but could not be parsed: {exc}") from exc
        return None
    try:
        size = len(pe.__data__)
        sig, seen = {}, {}
        for s in pe.sections:
            nm = s.Name.rstrip(b"\x00").decode("latin-1", "replace")
            if s.SizeOfRawData and s.PointerToRawData + s.SizeOfRawData > size:
                raise PEParseError(f"truncated: section {nm!r} extends past end of file "
                                   f"({s.PointerToRawData + s.SizeOfRawData} > {size} bytes)")
            if (s.Characteristics & 0x20000000) or nm == ".text":   # MEM_EXECUTE
                # name + occurrence, not name alone (bugs.md #13: a later same-named exec
                # section overwrote the earlier one's hash) and not section index (which
                # shifts when an unrelated section is added, faking a code change)
                key = nm or "<unnamed>"
                seen[key] = seen.get(key, 0) + 1
                sig[key if seen[key] == 1 else f"{key}#{seen[key]}"] = \
                    hashlib.sha256(s.get_data()).hexdigest()
        return sig
    except PEParseError:
        raise
    except Exception as exc:
        raise PEParseError(f"PE section table could not be read: {exc}") from exc
    finally:
        pe.close()


def _sha(path):
    h = hashlib.sha256()
    with open(lp(path), "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


# label -> real dll/file name (best-effort; ENG_RE_<x>_64 -> <x>.dll)
def _pretty(name):
    n = name
    for pre in ("ENG_RE_", "ENG_SEI_", "ENG_XTP_Gen_", "ENG_", "MPT_", "KF"):
        if n.startswith(pre):
            n = n[len(pre):]
            break
    n = n.replace("_dll_64", ".dll").replace("_exe_64", ".exe").replace("_64", "")
    if not n.lower().endswith((".dll", ".exe")):
        n += ".dll"
    return n


def _pair_names(prior_dir, fixed_dir):
    """(common, added, removed) entry names across the two engine dirs. `common` is a list
    of (prior_name, fixed_name) pairs. Matching is case-insensitive on Windows, where the
    filesystem is too — a name differing only in case between the two drops used to drop
    the file from BOTH sides (IMP-NT-3); elsewhere case-different names are different files."""
    pri, fix = os.listdir(lp(prior_dir)), os.listdir(lp(fixed_dir))
    fold = (lambda n: n.casefold()) if os.name == "nt" else (lambda n: n)
    pmap, fmap = {fold(n): n for n in pri}, {fold(n): n for n in fix}
    if len(pmap) != len(pri) or len(fmap) != len(fix):
        # a case-sensitive directory (e.g. WSL-enabled NTFS) holds names differing only by
        # case — folding would silently merge them, so match exactly instead
        pmap, fmap = {n: n for n in pri}, {n: n for n in fix}
    common = sorted((pmap[k], fmap[k]) for k in pmap.keys() & fmap.keys())
    added = sorted(fmap[k] for k in fmap.keys() - pmap.keys())
    removed = sorted(pmap[k] for k in pmap.keys() - fmap.keys())
    return common, added, removed


def _one_sided(names, root, tag, errors):
    """Record files present on only one side (IMP-NT-3: MSSQL triage used to drop them
    without a trace, so a new or removed DLL was invisible in the report — DB2/Oracle triage
    already record theirs). Informational: Stage 2 needs both sides to diff a binary."""
    out = []
    for n in names:
        path = os.path.join(root, n)
        try:
            if not os.path.isfile(lp(path)):
                continue
            try:
                kind = "pe" if _code_sig(path) is not None else "content"
            except PEParseError as exc:
                kind = "pe"
                errors.append({"name": n, "error": str(exc)})
            out.append({"name": n, "pretty": _pretty(n), "change": tag, "kind": kind,
                        "size": os.path.getsize(lp(path))})
        except Exception as exc:
            errors.append({"name": n, "error": str(exc)})
    return out


def run(prior_dir, fixed_dir, workdir, progress=None):
    """Compare the two engine dirs; write stage0/changed_files.json; return the summary."""
    pairs, only_fixed, only_prior = _pair_names(prior_dir, fixed_dir)
    names = [fn for _pn, fn in pairs]
    prior_name = dict((fn, pn) for pn, fn in pairs)
    total = len(names) or 1
    code_changed, rebuild_only, content_changed, identical, errors = [], [], [], [], []
    for i, n in enumerate(names):
        try:
            pa, pb = os.path.join(prior_dir, prior_name[n]), os.path.join(fixed_dir, n)
            if not (os.path.isfile(lp(pa)) and os.path.isfile(lp(pb))):
                continue
            ca, cb = _code_sig(pa), _code_sig(pb)
            entry = {"name": n, "pretty": _pretty(n), "size": os.path.getsize(lp(pb))}
            if ca is None or cb is None:            # non-PE content file
                if _sha(pa) != _sha(pb):
                    kind = ("resource-db" if "ResourceDb" in n else
                            ("sql" if n.lower().endswith(("sql", "_sql_64")) or "_sql" in n.lower() else "content"))
                    entry["route"] = "stage1" if kind in ("resource-db", "sql") else "other"
                    entry["kind"] = kind
                    content_changed.append(entry)
                else:
                    identical.append(n)
            else:
                if ca != cb:
                    entry["route"] = "stage2"
                    code_changed.append(entry)
                elif _sha(pa) != _sha(pb):
                    rebuild_only.append(n)
                else:
                    identical.append(n)
        except Exception as exc:
            # One unreadable/corrupt file must not abort the whole triage run — record it
            # and keep going (the same per-item isolation Stage 2 already applies).
            errors.append({"name": n, "error": str(exc)})
        if progress:
            progress(int(100 * (i + 1) / total),
                     f"Comparing code sections ({i + 1}/{total})")

    added = _one_sided(only_fixed, fixed_dir, "added", errors)
    removed = _one_sided(only_prior, prior_dir, "removed", errors)

    code_changed.sort(key=lambda e: -e["size"])
    result = {
        "counts": {"identical": len(identical), "rebuild_only": len(rebuild_only),
                   "code_changed": len(code_changed), "content_changed": len(content_changed),
                   "added": len(added), "removed": len(removed),
                   "errors": len(errors), "total": len(names)},
        "code_changed": code_changed,          # -> Stage 2 candidates
        "content_changed": content_changed,    # resource-db / .sql -> Stage 1
        "rebuild_only": rebuild_only,          # discarded (only version/rsrc changed)
        "added": added,                        # only in fixed (new binaries/files)
        "removed": removed,                    # only in prior
        "errors": errors,                      # files that could not be compared
    }
    out = os.path.join(workdir, "stage0")
    os.makedirs(lp(out), exist_ok=True)
    with open(lp(os.path.join(out, "changed_files.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    return result