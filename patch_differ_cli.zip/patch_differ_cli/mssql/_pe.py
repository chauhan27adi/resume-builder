"""PE (x64) helpers for MSSQL Stage 2.

Two things the binary gives us for free, no symbols required:

  debug_pdb(path)  -> (pdb_name, guid_hex, age)  from the CodeView RSDS debug record,
                      i.e. the exact key to fetch this image's public PDB from the
                      Microsoft symbol server.

  FuncImage(path)  -> function byte ranges from the .pdata exception directory
                      (every x64 function with unwind info has a RUNTIME_FUNCTION),
                      plus .text byte extraction by RVA. Chained continuations
                      (BeginAddress inside an already-seen range) are merged so each
                      logical function is one contiguous range.

Names come from the PDB (see symbols.py); this module supplies the boundaries + bytes.
"""
import struct

import pefile

from ..db2._paths import lp   # reuse the shared \\?\ long-path guard


def debug_pdb(path):
    """(pdb_basename, guid_hex_32, age) for the image's RSDS CodeView record, or None.

    guid_hex is formatted exactly as the symbol server expects: Data1/2/3 as their
    integer values (the fields are little-endian in the file), Data4 as raw bytes."""
    try:
        pe = pefile.PE(lp(path), fast_load=True)
    except Exception:
        return None
    try:
        pe.parse_data_directories(
            directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_DEBUG']])
        data = pe.__data__
        for d in getattr(pe, 'DIRECTORY_ENTRY_DEBUG', []) or []:
            st = d.struct
            raw = bytes(data[st.PointerToRawData:st.PointerToRawData + st.SizeOfData])
            if raw[:4] != b'RSDS' or len(raw) < 24:
                continue
            g1, g2, g3 = struct.unpack_from('<IHH', raw, 4)
            d4 = raw[12:20]
            age = struct.unpack_from('<I', raw, 20)[0]
            name = raw[24:].split(b'\x00', 1)[0].decode('latin-1', 'replace')
            name = name.replace('\\', '/').split('/')[-1]
            guid = "%08X%04X%04X%s" % (g1, g2, g3, d4.hex().upper())
            return name, guid, age
    except Exception:
        return None
    finally:
        pe.close()
    return None


def symbol_key(guid, age):
    """Symbol-server directory key: <32-hex-guid><age-hex-upper>."""
    return "%s%X" % (guid, age)


class FuncImage:
    """Loaded PE with .pdata function ranges + RVA byte access. Use as a context
    manager (holds a pefile handle).

    `groups` maps each *logical* function's primary begin RVA to the sorted list of its
    (begin, end) code chunks. x64 functions are frequently split into non-adjacent hot/cold
    fragments, each with its own RUNTIME_FUNCTION; the unwind info's CHAININFO flag (0x4)
    links a fragment to its parent. We follow that chain to fold every fragment under its
    primary, so each function is diffed as one reassembled body.

    This is deliberately NOT the old "merge adjacent ranges" heuristic: two independent
    functions whose .pdata entries happen to abut would merge there, making a diff run past
    a `ret` into the next function (the false-positive class, e.g. a tiny 53-byte function
    reported with +263 "guard" lines). CHAININFO groups only true fragments of one function.

    `ranges` (sorted [(begin, end)] of every primary's entry chunk) is kept for any
    back-compat consumer; Stage 2 uses `groups`.
    """

    def __init__(self, path):
        self.path = path
        self.pe = pefile.PE(lp(path), fast_load=True)
        try:
            self.image_base = self.pe.OPTIONAL_HEADER.ImageBase
            self._img = None
            self.groups = self._pdata_groups()
            self.ranges = sorted((min(b for b, _ in v), max(e for _, e in v))
                                 for v in self.groups.values())
        except Exception:
            self.pe.close()
            raise

    def _mm(self):
        """Lazy memory-mapped image (RVA-indexed) for reading unwind info."""
        if self._img is None:
            self._img = self.pe.get_memory_mapped_image()
        return self._img

    def _primary_of(self, begin, end, unw):
        """Follow UNWIND_INFO CHAININFO (flag 0x4) to the function's primary begin RVA.
        Layout: byte0 low 3 bits = version, high 5 = flags; byte2 = count of unwind codes;
        after the (padded-to-even) codes, CHAININFO carries the parent RUNTIME_FUNCTION
        (BeginAddress, EndAddress, UnwindInfoAddress)."""
        img = self._mm()
        seen = 0
        while unw and unw + 4 <= len(img) and seen < 8:
            flags = img[unw] >> 3
            if not (flags & 0x4):                 # no CHAININFO -> this IS the primary
                return begin
            cnt = img[unw + 2]
            off = unw + 4 + ((cnt + 1) & ~1) * 2  # skip unwind codes (padded to even count)
            if off + 12 > len(img):
                return begin
            begin = int.from_bytes(bytes(img[off:off + 4]), 'little')
            unw = int.from_bytes(bytes(img[off + 8:off + 12]), 'little')
            seen += 1
        return begin

    def _pdata_groups(self):
        pe = self.pe
        pe.parse_data_directories(
            directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_EXCEPTION']])
        rf = getattr(pe, 'DIRECTORY_ENTRY_EXCEPTION', None) or []
        groups = {}
        for e in rf:
            b, en = e.struct.BeginAddress, e.struct.EndAddress
            unw = getattr(e.struct, 'UnwindData', 0)
            if en <= b:
                continue
            try:
                primary = self._primary_of(b, en, unw)
            except Exception:
                primary = b
            groups.setdefault(primary, set()).add((b, en))
        return {p: sorted(v) for p, v in groups.items()}

    def bytes_at(self, rva, size):
        try:
            return self.pe.get_data(rva, size)
        except Exception:
            return b""

    def close(self):
        try:
            self.pe.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()