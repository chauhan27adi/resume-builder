"""Stage 2 — symbol-based function diff of the changed MSSQL engine DLLs (PE/x64).

Mirrors the DB2 Stage-2 design, but sources function boundaries + names differently:
DB2 reads the ELF `.symtab`; MSSQL DLLs are stripped, so we take boundaries from the
PE `.pdata` exception directory (`_pe.FuncImage`) and names from the image's public PDB
off the Microsoft symbol server (`symbols.Symbolizer`, via dbghelp). With names in hand
the flow is identical to DB2:

  1. cheap pass  — slice each build's `.text` into per-function byte ranges, key by name;
                   set-diff by name -> new / removed / raw-byte-changed.
  2. disasm pass — only the raw-changed set: capstone-disassemble both sides and NORMALIZE
                   away recompile/relink noise (branch/call->L, [rip+disp]->[rip], regs->R<bits>,
                   __LINE__-renumber churn filtered). What survives is a real logic change,
                   and because we kept the symbol it is NAMED and attributable to a CVE.

If the PDB can't be fetched, or simply has no public entry for a given function (routine
for internal/static engine helpers — a successful PDB fetch does not mean every function in
it got a name), that function is keyed by RVA instead (sub_<rva>) and cannot be attributed
— Stage 2 degrades, never fails. Byte-changed detection for such a function still runs
exactly like a named one WHEN its RVA is shared by both builds (present in `common`): a
shared RVA key already means "the same code slot in both builds", so a byte difference
there is a real, reliable signal worth surfacing unattributed. An RVA appearing on only
ONE side is a much weaker signal for an unnamed function specifically — any unrelated
layout shift elsewhere in the module changes every downstream RVA, which would manufacture
phantom added/removed entries rather than catch a real one — so new/removed detection stays
name-only; an unnamed function is never reported as added or removed, only as changed.

PARALLELISM: the per-DLL diff is embarrassingly parallel (matching is by name *within* a
DLL, classification is per-function) and deterministic (the final list is sorted), so each
changed DLL runs in its own process via a ProcessPoolExecutor. This is multi-*processing*,
not threading, on purpose: the hot path (`_x86diff.norm`) is pure-Python/GIL-bound, and
dbghelp is single-threaded — process isolation sidesteps both. The two ~50 MB giants
(sqlmin, sqllang) then run concurrently instead of back-to-back. Progress is reported live
via a shared queue and weighted by file size (so the bar tracks real work, not lib count).

Output: `<workdir>/stage2/functions_diff.json` (+ per-function .asm.diff/.detail.json —
.asm.diff is the normalized-instruction assembly diff; .detail.json is the full record,
always carrying the assembly text and, only with --decompile, the prior_c/fixed_c
pseudo-C too), the same shape the detail template + `/split` renderer already consume
for DB2. Permanent copies also land in per-version folders, so each build's results can
be reused on their own (see `_version_dirs()`; <V>/<F> = each build's KB or engine
version, "unversioned" if unknown):
  disassembled_instructions_vuln_<V>/<binary>_<sha8>/<function>.asm   plain disassembly
  disassembled_instructions_fixed_<F>/<binary>_<sha8>/<function>.asm  (always)
  decompiled_c_vuln_<V>/<binary>_<sha8>/<function>.c                  pseudo-C
  decompiled_c_fixed_<F>/<binary>_<sha8>/<function>.c                 (with --decompile)
  disassembled_instructions_<V>_vs_<F>/<vuln>_<fixed>_<run_ts>__fn__<dll>_<func>.asm.diff
    — the assembly diffs, which compare the two builds, one timestamped set per run.
Each <binary>_<sha8>/ holds a binary.json (binary, sha256, version, build). None of
these is ever cleaned up by this project.
"""
import contextlib
import difflib
import hashlib
import json
import os
import re
import time
from collections import Counter
from pathlib import Path

import pefile as _pefile

from .. import _x86diff as X
from .. import _parallel
from .. import _attribution as _AT
from .. import _result_state as _rs
from .. import _results
from ._pe import FuncImage
from . import symbols as sym
from ..db2._paths import lp, safe_name
from .. import _layout
# MSSQL caches pseudo-C per function and build, so a build's functions decompiled in one
# pairing are reused in any other (the name `decompile_cached` is kept: same call shape).
from .._decompile import decompile_cached_per_side as decompile_cached
from .._decompile import decompile_allowed
from .._decompile import failure_record as _dc_failure_record

_EMIT_CAP = 500
_MAX_FUNC_BYTES = 300_000


# ---------------------------------------------------------------------------
# Pseudo-C decompilation helpers (opt-in via --decompile)
# ---------------------------------------------------------------------------

_MAX_DECOMP_SPAN = 16 * 1024 * 1024   # widest primary..cold-chunk span laid out for Ghidra


def _extract_func_bytes(chunks, primary):
    """(blob, omitted) — one function's hot+cold chunks as a single blob for
    decompile_pair(), plus how many chunks had to be left out of it.

    bugs.md #25: the chunks used to be concatenated back to back. Branches between hot and
    cold fragments are PC-relative, so once the gap between them was squeezed out every
    such branch landed on the wrong bytes and the pseudo-C was wrong. Each chunk is now
    placed at its TRUE offset from the primary (the blob start, which DecompileFunc.java
    takes as the entry), with the gap filled with int3. A chunk below the primary can't be
    placed (it would precede the entry), and a span over _MAX_DECOMP_SPAN keeps only the
    primary chunk; both are counted in `omitted` so the caller can say the C is partial.
    No chunk at the primary at all -> (b"", n): nothing sound to decompile."""
    chunks = sorted(chunks)
    keep = [(r, c) for r, c in chunks if r >= primary]
    if not keep or keep[0][0] != primary:
        return b"", len(chunks)
    span = max(r + len(c) for r, c in keep) - primary
    if span > _MAX_DECOMP_SPAN:
        keep = keep[:1]
        span = len(keep[0][1])
    blob = bytearray(b"\xcc" * span)
    for r, c in keep:
        blob[r - primary:r - primary + len(c)] = c
    return bytes(blob), len(chunks) - len(keep)


def _partial_c_note(omitted, c):
    """Prefix pseudo-C built without some of its function's chunks with a visible note."""
    if not (omitted and c):
        return c
    return (f"// NOTE: {omitted} cold fragment(s) of this function could not be laid out for "
            f"the decompiler; branches into them appear unresolved.\n" + c)


# _try_decompile / the SHA256-keyed cache now live in `.._decompile.decompile_cached`,
# shared across all three backends (MSSQL's PE chunks are laid out into one blob via
# _extract_func_bytes above; DB2/Oracle's ELF function maps already store one
# contiguous blob per function, so they call decompile_cached() directly).


# Shared PDB cache that persists across runs. Keyed by <name>_<GUID><age>/ so the
# same DLL from two different patches never re-downloads its symbols.
_GLOBAL_PDB_CACHE = Path(__file__).parent.parent / "patches" / "mssql" / ".pdb_cache"
# MSVC EH/compiler funclets: separate .pdata functions, but not the fix itself — rank below.
_ARTIFACT = re.compile(r"\$(catch|dtor|fin|unwind|filt)\b|::`|`dynamic|`vftable|`vcall")


def available():
    return X.AVAILABLE


def _pretty(name):
    """ENG_RE_sqlmin_64 -> sqlmin.dll (best-effort; matches Stage 0's labelling)."""
    n = name
    for pre in ("ENG_RE_", "ENG_SEI_", "ENG_XTP_Gen_", "ENG_", "MPT_", "KF"):
        if n.startswith(pre):
            n = n[len(pre):]
            break
    n = n.replace("_dll_64", ".dll").replace("_exe_64", ".exe").replace("_64", "")
    if not n.lower().endswith((".dll", ".exe")):
        n += ".dll"
    return n


def _safe(s):
    return safe_name(s, 120)


# Per-version output layout: shared with the other backends in .._layout (see there).
_version_token = _layout.version_token
_version_dirs = _layout.version_dirs


def _binary_folder(base, rel, path, side_info, digest=None):
    """This DLL's folder in one build's output (_layout.binary_folder), with its display
    name (sqlmin.dll) in binary.json. digest reuses an already-computed sha256 of path."""
    return _layout.binary_folder(base, rel, path, side_info, _pretty(rel), digest)


def _listing(md, name, pretty, entry):
    """Plain disassembly of one function: every chunk, addresses are RVAs."""
    primary, chunks = entry
    return _layout.listing(md, name, pretty, primary, chunks, "RVA")


class _FuncMap(dict):
    """{name: (primary_rva, chunks)} plus `.oversized` — functions skipped as larger
    than _MAX_FUNC_BYTES: {name: [(size, sha256)]} (bugs.md #28)."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.oversized = {}


def _func_map(path, symbolizer):
    """{name: (primary_rva, chunks)} for every logical .pdata function, where chunks is a
    sorted list of (rva, code_bytes) — the function's hot/cold fragments reassembled via
    CHAININFO (see FuncImage.groups). Named via the PDB; functions with no owning symbol get
    an RVA label (sub_<rva>) instead — a key that only lines up across the two builds when
    the function's address happens to be unchanged (nothing earlier in the module shifted
    its layout). The caller (stage2.py's name-mode branch) relies on exactly that: a shared
    sub_<rva> key means "the same code slot in both builds", so it's used to detect a real
    byte-level change there, but NOT to detect an unnamed function being added or removed —
    an RVA appearing on only one side is just as likely a layout shift as a real add/remove.
    Each chunk keeps its own base RVA so branch/call targets disassemble correctly (a single
    concatenated base would misresolve the cold fragment)."""
    from .. import _results
    limit = _results.max_func_bytes(_MAX_FUNC_BYTES)       # db2_bugs.md DB2-2: configurable
    out = _FuncMap()
    entries = []                                           # (key, primary, chunks), deduped below
    with FuncImage(path) as img:
        for primary, ranges in img.groups.items():
            total = sum(e - b for b, e in ranges)
            if total <= 0:
                continue
            # EXACT symbol at the primary — never bisect-fold (name_at), which would fold an
            # unnamed static function onto its named neighbour and let the larger body mask or
            # fabricate a diff. Unnamed primaries become sub_<rva> (won't match across builds).
            nm = symbolizer.exact_name(primary) if (symbolizer and symbolizer.ok) else None
            key = nm or ("sub_%x" % primary)
            if total > limit:
                # bugs.md #28: recorded (size + digest of its bytes in address order), not
                # silently dropped — see _results.skipped_oversized()
                h = hashlib.sha256()
                for b, e in sorted(ranges):
                    h.update(img.bytes_at(b, e - b) or b"")
                out.oversized.setdefault(key, []).append((total, h.hexdigest()))
                continue
            chunks = []
            for b, e in ranges:
                code = img.bytes_at(b, e - b)
                if code:
                    chunks.append((b, code))
            if not chunks:
                continue
            entries.append((key, primary, chunks))
    # bug.md MSSQL-NT-1: a PDB can give two DISTINCT .pdata functions the same public name
    # (exact_name is an RVA->name dict whose values aren't unique). Keep each distinct one
    # (qualified), folding only byte-identical COMDAT/ICF copies, instead of dropping all but
    # the largest — matching DB2/Oracle's _dedupe_func_names (bugs.md #27). Unique names and
    # sub_<rva> keys (always unique) keep their bare key, so nothing changes for the common case.
    groups = {}
    for key, primary, chunks in entries:
        groups.setdefault(key, []).append((primary, chunks))
    for key, g in groups.items():
        if len(g) == 1:
            out[key] = g[0]
            continue
        distinct = []                                      # (primary, chunks, blob)
        for primary, chunks in g:
            blob = _blob(chunks)
            if not any(blob == d[2] for d in distinct):    # fold byte-identical COMDAT copies
                distinct.append((primary, chunks, blob))
        # The LARGEST distinct copy keeps the bare key — exactly the previous keep-largest
        # behaviour, so nothing regresses (a bare name on one side still pairs with the other
        # side's largest) — and any OTHER distinct same-named function, previously dropped, is
        # now surfaced under a qualified "name [#k]" key (MSSQL-NT-1; cf. #27). Attribution
        # tokenises the bracketed qualifier away, so a CVE match is unaffected.
        distinct.sort(key=lambda d: (-_blob_len(d[1]), d[0]))
        out[key] = (distinct[0][0], distinct[0][1])
        for k, (primary, chunks, _b) in enumerate(sorted(distinct[1:], key=lambda d: d[0]), 2):
            out[_AT.qualify_func_name(key, "#%d" % k)] = (primary, chunks)
    return out


def _blob(chunks):
    """Concatenated bytes of a function's chunks (address order) — for raw-change equality."""
    if len(chunks) == 1:
        return chunks[0][1]
    return b"".join(c for _, c in sorted(chunks))


def _blob_len(chunks):
    return sum(len(c) for _, c in chunks)


def _norm_chunks(md, chunks):
    """X.norm over every chunk at its own base RVA; concatenate (lines, shape, imms)."""
    L, S, I = [], [], []
    for addr, code in sorted(chunks):
        l, s, i = X.norm(md, addr, code)
        L += l; S += s; I += i
    return L, S, I


def _norm_chunk_pair(md, pchunks, fchunks, pprimary=None, fprimary=None):
    """Normalize hot+cold chunk pairs independently, classify per-chunk.

    Returns (pL_all, fL_all, pL_scored, fL_scored, cls) where:
      pL_all / fL_all   — full concatenation used for the diff output (unchanged)
      pL_scored / fL_scored — lines from genuinely changed chunks only; used for
                              similarity and fix_score so an identical hot path
                              doesn't dilute a real cold-path fix
      cls               — overall classification (worst across all chunks)

    When chunk counts differ (structural change), falls back to full concatenation
    for both all and scored to preserve the existing behaviour.

    bug.md MSSQL-NT-2: chunks are paired by ROLE — the primary (hot) chunk of each side
    first, then the cold fragments by address — not by raw sorted position, so a cold
    fragment reordered relative to the hot entry on one side only no longer pairs hot
    against cold (which would skew the similarity/fix-score ranking). Identical to the old
    sorted-position pairing in the common case (hot is the lowest-RVA chunk)."""
    def _by_role(chunks, primary):
        hot = [c for c in chunks if c[0] == primary]
        return hot + sorted(c for c in chunks if c[0] != primary)
    sp = _by_role(pchunks, pprimary) if pprimary is not None else sorted(pchunks)
    sf = _by_role(fchunks, fprimary) if fprimary is not None else sorted(fchunks)
    pL_all, fL_all = [], []
    pL_scored, fL_scored = [], []
    overall_cls = "same"

    if len(sp) != len(sf):
        # Cannot pair by position — fall back to existing concatenated path.
        pL_all, pS, pI = _norm_chunks(md, pchunks)
        fL_all, fS, fI = _norm_chunks(md, fchunks)
        overall_cls = X.classify(pL_all, pS, pI, fL_all, fS, fI)
        return pL_all, fL_all, pL_all, fL_all, overall_cls

    for (pa, pc), (fa, fc) in zip(sp, sf):
        pL, pS, pI = X.norm(md, pa, pc)
        fL, fS, fI = X.norm(md, fa, fc)
        pL_all += pL
        fL_all += fL
        chunk_cls = X.classify(pL, pS, pI, fL, fS, fI)
        # upgrade overall: code > const > churn > same
        if chunk_cls == "code":
            overall_cls = "code"
        elif chunk_cls == "const" and overall_cls != "code":
            overall_cls = "const"
        elif chunk_cls == "churn" and overall_cls == "same":
            overall_cls = "churn"
        # only code/const chunks contribute to the scored set
        if chunk_cls in ("code", "const"):
            pL_scored += pL
            fL_scored += fL

    # if no chunks were "code" or "const" (all same/churn) scored set is empty;
    # fall back to full so downstream callers always receive non-empty lists
    if not pL_scored:
        pL_scored, fL_scored = pL_all, fL_all

    return pL_all, fL_all, pL_scored, fL_scored, overall_cls


def _calls_chunks(md, chunks, name_at):
    """X.call_targets over every chunk (each at its own base RVA)."""
    out = []
    for addr, code in sorted(chunks):
        out += X.call_targets(md, addr, code, name_at)
    return out


# --------------------------------------------------------------------------- attribution
# CVE name/CWE attribution lives in the shared `_attribution` module (used by every backend);
# Stage 2 calls `_AT.load_attrib(workdir)` / `_AT.attribute(name, attrib)` / `_AT.resolve(...)`.
# It is a LABELLING layer only — emission (below) never depends on it, so a real fix is
# surfaced whether or not its symbol name happens to match the advisory text.
# Callees a fix newly introduces that signal a validation/range guard but aren't compiler
# intrinsics (e.g. IndexRowScanner::VerifyRowInRange) — counted as fix corroboration.
_VALIDATION_CALLEE = re.compile(r"verify|rangecheck|checkrange|inrange|bounds|validate", re.I)


def _rank(r):
    return (r.get("cve") is None,                       # asserted (corroborated) first
            r.get("cve_candidate") is None,             # then name-matched candidates
            -r.get("fix_score", 0),                     # then fix-shaped changes
            bool(_ARTIFACT.search(r.get("object", ""))),  # funclets down
            r.get("change") in ("added", "removed"),
            r.get("similarity", 1.0),
            r.get("object", ""))                        # final tie-breaker: deterministic
                                                         # order regardless of worker-pool
                                                         # completion order (list.sort() is
                                                         # stable, so ties otherwise keep
                                                         # whatever order workers finished in)


class _NoSymbolizer:
    """Stand-in for the absent side of a one-sided (added/removed) DLL."""
    ok = False

    def name_at(self, rva):
        return None


_NO_SYMBOLS = _NoSymbolizer()


# --------------------------------------------------------------------------- per-DLL worker
def _process_dll(job, report=None):
    """Diff ONE changed DLL (both sides). Module-level + picklable args so it runs in a
    ProcessPoolExecutor child. Writes its own fn__*.asm.diff/.detail.json (uniquely named — no
    cross-DLL collisions) and returns its readable-card list + stats for the parent to
    aggregate. `report(rel, pct, phase)` streams 0..100 local progress (optional)."""
    prior_dir, fixed_dir, rel = job["prior_dir"], job["fixed_dir"], job["rel"]
    out, attrib = job["out"], job["attrib"]
    online, pdb_cache = job["online"], job["pdb_cache"]
    pretty = _pretty(rel)

    def rep(pct, phase):
        if report:
            report(rel, pct, phase)

    # bugs.md #3: a DLL present on only ONE side ("added" / "removed") gets a one-sided
    # function inventory (every function becomes an added/removed card) instead of no
    # function-level analysis at all. The absent side is simply an empty function map.
    one_sided = job.get("one_sided")
    rep(2, f"{pretty}: fetching symbols")
    md = X.md()
    p_path, f_path = os.path.join(prior_dir, rel), os.path.join(fixed_dir, rel)
    pp = None if one_sided == "added" else sym.fetch_pdb(p_path, pdb_cache, online=online)
    fp = None if one_sided == "removed" else sym.fetch_pdb(f_path, pdb_cache, online=online)
    with (contextlib.nullcontext(_NO_SYMBOLS) if one_sided == "added"
          else sym.Symbolizer(p_path, pp)) as ps, \
            (contextlib.nullcontext(_NO_SYMBOLS) if one_sided == "removed"
             else sym.Symbolizer(f_path, fp)) as fs:
        symbolized = bool(ps.ok or fs.ok)
        P = {} if one_sided == "added" else _func_map(p_path, ps)
        F = {} if one_sided == "removed" else _func_map(f_path, fs)
        # bugs.md #58: with a PDB for only ONE build, that side was keyed by name and the
        # other by sub_<rva>, so no key was shared: every named function read as "removed"
        # and the real change was never diffed, in a result marked ok. Key BOTH sides by
        # address instead (a shared RVA = the same code slot, the rule sub_ keys already
        # follow), so same-slot changes are still diffed, and report the binary as only
        # partially analyzed below (functions whose address moved can't be paired).
        one_side_symbols = None
        if not one_sided and bool(ps.ok) != bool(fs.ok):
            one_side_symbols = "prior" if ps.ok else "fixed"
            P, F = _func_map(p_path, None), _func_map(f_path, None)
            symbolized = False
    # bugs.md #28: changed functions too large to diff are reported, not silently dropped
    skipped = [{"rel": rel, "pretty": pretty, **s}
               for s in _results.skipped_oversized(P, F, one_sided)]
    expected = {"added": (("fixed", F),), "removed": (("prior", P),)}.get(
        one_sided, (("prior", P), ("fixed", F)))
    if any(not m and not getattr(m, "oversized", None) for _s, m in expected):
        # CRIT-NT-9: this DLL is on triage's code_changed list, so an empty function map
        # (no usable .pdata/function table on a side) means real code changes went
        # unanalyzed. Report WHY so run() records it as a failed binary instead of it
        # silently vanishing from a result that would otherwise look clean (and exit 0).
        sides = [s for s, m in expected if not m]
        return {"rel": rel, "pretty": pretty, "readable": [], "funcs_total": 0,
                "symbolized": symbolized, "ok": False,
                "error": f"no functions recovered on {' and '.join(sides)} side{'s' if len(sides) > 1 else ''} "
                         f"(no usable function table) — changed code could not be analyzed",
                "decompile_attempted": 0, "decompile_failed": 0}

    rep(6, f"{pretty}: comparing functions")
    # Unnamed sub_<rva> keys are excluded from added/removed in a two-sided diff (an RVA
    # present on one side only is no identity across builds; CRIT-NT-1). For a one-sided
    # binary every function genuinely is added/removed, so nothing is filtered.
    _named = ((lambda ks: list(ks)) if one_sided
              else (lambda ks: [k for k in ks if not k.startswith("sub_")]))

    readable = []
    # Mutable so the emit() closure below can increment it. "attempted" counts every
    # function where decompile was actually tried (Ghidra configured, gate passed);
    # "failed" counts the subset of those where it produced no output at all. Lets a
    # caller distinguish "nothing was fix-shaped/attributed enough to decompile" (a
    # legitimate empty result) from "decompile was tried and failed every time" (e.g. a
    # stale Ghidra script cache) — previously both looked identical: zero .c files, no
    # diagnostic anywhere.
    decompile_stats = {"attempted": 0, "failed": 0, "skipped": 0}
    decompile_failures = []      # {"object", "reason"} per failed pseudo-C (DB2-14)
    folders = {}                 # (kind, side) -> this DLL's folder in that build's output
    side_digest = {}             # side -> sha256 of its DLL (asm and c share one hash)

    def version_folder(kind, side):
        """This DLL's folder in one build's per-version output ("asm" or "c"), created on
        first use; None for a job without per-version folders (written the old way)."""
        info = (job.get("version_dirs") or {}).get(side)
        if not info:
            return None
        if (kind, side) not in folders:
            path = p_path if side == "prior" else f_path
            if side not in side_digest:
                side_digest[side] = _layout.file_sha256(path)
            folders[(kind, side)] = _binary_folder(info[kind], rel, path, info,
                                                   side_digest[side])
        return folders[(kind, side)]

    def emit(prior_name, fixed_name, kind, simr, prior_txt, fixed_txt,
             bd_sim=None, bd_conf=None):
        """Write one function diff card. prior_name/fixed_name may differ (renamed) or one
        may be None (added/removed). bd_sim/bd_conf are present only in BinDiff mode."""
        key = prior_name if prior_name else fixed_name
        cve, why, conf = attr_cache[key]
        # For BinDiff-mode renames: if the primary side has no CVE but the renamed
        # counterpart does, prefer the side that has attribution.  The emit guard
        # already checked both; this ensures the record carries the right CVE.
        if cve is None and fixed_name and fixed_name != key:
            cve_f, why_f, conf_f = attr_cache.get(fixed_name, (None, None, None))
            if cve_f is not None:
                cve, why, conf = cve_f, why_f, conf_f
        added_intr = None
        if kind not in ("added", "removed") and prior_name in P and fixed_name in F:
            # resolve direct-call targets both sides; flag security intrinsics AND added
            # validation/range-guard callees (e.g. VerifyRowInRange) introduced by the fix.
            pcalls = Counter(_calls_chunks(md, P[prior_name][1], ps.name_at))
            fcalls = Counter(_calls_chunks(md, F[fixed_name][1], fs.name_at))
            gained = list((fcalls - pcalls).elements())
            added_intr = ([c for c in gained if X.is_security_intrinsic(c)]
                          + [c for c in gained if _VALIDATION_CALLEE.search(c or "")])
        fscore, freasons = (X.fix_signature(prior_txt, fixed_txt, added_intrinsics=added_intr)
                            if kind not in ("added", "removed") else (0, []))
        display_name = prior_name or fixed_name
        if prior_name and fixed_name and prior_name != fixed_name:
            display_name = f"{prior_name} → {fixed_name}"
        obj = f"{pretty} :: {display_name}"
        fbase = "fn__" + _safe(f"{rel}_{prior_name or fixed_name}")
        pname_label = prior_name or "(absent)"
        fname_label = fixed_name or "(absent)"
        diff = "".join(difflib.unified_diff(
            [l + "\n" for l in prior_txt], [l + "\n" for l in fixed_txt],
            fromfile=f"{pname_label} (prior, normalized)",
            tofile=f"{fname_label} (fixed, normalized)", n=3))
        diff_text = diff or "(no normalized-instruction differences)\n"
        with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
            fh.write(diff_text)
        # Permanent, version+timestamp-tagged copy for later reference — the per-build
        # pseudo-C (decompiled_c_<build>_<version>/ below) is written the same way, but
        # this is the assembly diff, which (unlike decompile) runs unconditionally, so
        # every matched function lands here every run.
        asm_prefix = f"{job['vuln_label']}_{job['fixed_label']}_{job['run_ts']}__{fbase}"
        with open(lp(os.path.join(job["disassembled_dir"], asm_prefix + ".asm.diff")),
                  "w", encoding="utf-8") as fh:
            fh.write(diff_text)
        # Each build's own copy of the function's plain disassembly, in that build's
        # folder, named by that build's function name (a renamed function is filed under
        # each side's own name), so one build's listings can be reused on their own.
        for side, name, fmap in (("prior", prior_name, P), ("fixed", fixed_name, F)):
            if name and name in fmap:
                folder = version_folder("asm", side)
                if folder:
                    with open(lp(os.path.join(folder, _layout.function_file(name, ".asm"))), "w",
                              encoding="utf-8") as fh:
                        fh.write(_listing(md, name, pretty, fmap[name]))
        # Pseudo-C decompilation (opt-in via --decompile, best-effort, scoped to
        # fix-shaped or CVE-attributed functions only to keep runtime reasonable)
        prior_c, fixed_c = "", ""
        if (job.get("decompile")
                and kind not in ("added", "removed")
                and prior_name in P and fixed_name in F
                and (fscore > 0 or cve is not None)
                and decompile_allowed(job.get("decompile_max"), decompile_stats)):
            pb, p_omit = _extract_func_bytes(P[prior_name][1], P[prior_name][0])
            fb, f_omit = _extract_func_bytes(F[fixed_name][1], F[fixed_name][0])
            prior_c, fixed_c, attempted = decompile_cached(pb, fb, job["decompile_cache"])
            prior_c = _partial_c_note(p_omit, prior_c)
            fixed_c = _partial_c_note(f_omit, fixed_c)
            if attempted:
                decompile_stats["attempted"] += 1
                # bugs.md #7: one-sided output is a (partial) failure too
                if not (prior_c and fixed_c):
                    decompile_stats["failed"] += 1
                    decompile_failures.append(_dc_failure_record(obj))     # DB2-14
            if (prior_c or fixed_c) and job.get("version_dirs"):
                # Each build's pseudo-C in that build's own folder, by its own function
                # name; the same build and function always give the same file, so a later
                # run refreshes it instead of adding a copy. (decompile_cache/per_function/
                # is the internal cache behind it, keyed by each function's bytes.)
                for side, name, text in (("prior", prior_name, prior_c),
                                         ("fixed", fixed_name, fixed_c)):
                    if text:
                        with open(lp(os.path.join(version_folder("c", side),
                                                  _layout.function_file(name, ".c"))),
                                  "w", encoding="utf-8") as cf:
                            cf.write(text)
            elif (prior_c or fixed_c) and job.get("decompiled_c_dir"):
                # a job built without per-version folders: one shared folder, as before
                c_prefix = (f"{job['vuln_label']}_{job['fixed_label']}_"
                            f"{job['run_ts']}__{fbase}")
                for suffix, text in ((".prior.c", prior_c), (".fixed.c", fixed_c)):
                    if text:
                        with open(lp(os.path.join(job["decompiled_c_dir"],
                                                  c_prefix + suffix)),
                                  "w", encoding="utf-8") as cf:
                            cf.write(text)
        with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": "\n".join(prior_txt),
                       "fixed": "\n".join(fixed_txt),
                       "prior_c": prior_c, "fixed_c": fixed_c,
                       "truncated": False}, fh)
        # cve/confidence finalised in run() once corroboration (intrinsic/fix/cross-binary) known
        record = {"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                  "src": rel, "group": pretty, "kind": "function", "cve": cve,
                  "why": why, "name_conf": conf, "intrinsic": bool(added_intr),
                  "change": kind, "similarity": simr,
                  "fix_score": fscore, "fix_why": "; ".join(freasons)}
        if one_sided:
            record["binary_change"] = one_sided       # the whole DLL is added/removed
        if bd_sim is not None:
            record["bindiff_similarity"] = bd_sim
            record["bindiff_confidence"] = bd_conf
            record["match_algorithm"] = "bindiff"
        else:
            record["match_algorithm"] = "name"
        readable.append(record)

    bd_failed_reason = None
    use_bd = job.get("use_bindiff") and not one_sided   # BinDiff needs both builds
    if use_bd:
        try:
            from patch_differ_cli._bindiff import diff_pair as _bd_diff_pair
            prior_path = os.path.join(prior_dir, rel)
            fixed_path = os.path.join(fixed_dir, rel)
            # Use a per-DLL subdirectory so concurrent workers (ProcessPoolExecutor) each
            # get their own Ghidra project directory.  A shared workdir=out means all
            # workers write to the same out/bindiff/ghidra_proj/, which Ghidra has no
            # locking for, causing project corruption when sqlmin.dll, sqllang.dll etc.
            # are processed in parallel. bug.md DB2-T1-3: the intermediates (Ghidra project +
            # .BinExport + logs) go to a sibling of stage2/, not inside it, so the per-version
            # result tree stays clean; fallback to `out` keeps jobs built without
            # "bindiff_dir" (test fakes) working.
            bd_workdir = os.path.join(job.get("bindiff_dir") or out, _safe(rel))

            # Offset RVAs by each side's ImageBase to match BinDiff's virtual addresses.
            # _func_map() stores RVAs; Ghidra imports the PE at its declared ImageBase
            # (e.g. 0x180000000), so BinDiff records VAs, not RVAs.
            _pe_p = _pefile.PE(lp(prior_path), fast_load=True)
            try:
                p_ib = _pe_p.OPTIONAL_HEADER.ImageBase
            finally:
                _pe_p.close()
            _pe_f = _pefile.PE(lp(fixed_path), fast_load=True)
            try:
                f_ib = _pe_f.OPTIONAL_HEADER.ImageBase
            finally:
                _pe_f.close()
            rep(8, f"{pretty}: running BinDiff")
            matches = _bd_diff_pair(prior_path, fixed_path, bd_workdir,
                                    progress=lambda p, m: rep(8 + int(72 * p / 100), m))
            # bugs.md #60: map with the offset measured from BinDiff's names when possible;
            # each side's ImageBase is the default. No match resolving at all raises (the
            # except below falls back to name matching and records it) instead of emitting
            # every function as phantom added/removed.
            from patch_differ_cli._bindiff import map_matches as _bd_map
            addr_to_name_P, addr_to_name_F = _bd_map(matches, P, F, p_ib, f_ib)
        except Exception as exc:
            # A BinDiff/Ghidra hiccup on THIS ONE binary (timeout, misconfiguration, a
            # transient resource issue) must not lose the whole binary's result set —
            # fall back to plain name-based matching for it instead, same as when
            # --use-bindiff isn't passed at all. Other binaries in the run are unaffected
            # either way (each is already its own isolated job via _parallel.py).
            bd_failed_reason = str(exc) or type(exc).__name__
            import sys
            print(f"WARNING: BinDiff failed for {pretty} ({bd_failed_reason}); "
                 f"falling back to name-based matching for this binary.", file=sys.stderr)

    if use_bd and bd_failed_reason is None:
        matched_p_vas, matched_f_vas = set(), set()
        raw_bd = []
        for va1, m in matches.items():
            name_p = addr_to_name_P.get(va1)
            name_f = addr_to_name_F.get(m.addr2)
            if name_p is not None and name_f is not None:
                # Only mark BOTH sides "matched" when BOTH resolve to a known function.
                # A one-sided resolution means BinDiff correctly CFG-matched this pair,
                # but our own PDB-derived function map couldn't place one side (e.g. the
                # fixed-side function grew past _MAX_FUNC_BYTES, a real security fix can
                # easily do that). If the resolved side were marked matched anyway, it
                # would ALSO be excluded from the new/removed derivation below — the
                # function would then be reported nowhere at all: not changed, not added,
                # not removed. Leaving it unmatched here lets it fall through to
                # new/removed instead, same as the default name-based mode would report it.
                matched_p_vas.add(va1)
                matched_f_vas.add(m.addr2)
            if name_p is None or name_f is None:
                continue  # address outside _func_map range
            # bugs.md #53: a BinDiff similarity of 1.0 used to be skipped outright as
            # "CFG-identical". BinDiff scores graph structure and mnemonics, NOT operands,
            # so a changed bounds constant / register width / struct offset scored 1.0 and
            # was never diffed (live-verified: cmp edi,0x100 -> 0xff, zero cards). Only
            # byte-identical functions are skipped; everything else goes through the same
            # norm()/classify() as name mode, which discards relocation-only churn.
            if m.similarity >= 1.0 and _blob(P[name_p][1]) == _blob(F[name_f][1]):
                continue  # truly identical bytes
            # bugs.md #62: a pair of UNNAMED functions (sub_<addr>: no PDB / no symbol) used
            # to be dropped here as "unattributable" — so for a stripped or unsymbolized
            # binary, the very case BinDiff's structural matching is for, Track 1 reported
            # nothing. They go through classify() like any pair; only the added/removed
            # derivation below still excludes sub_ keys (no identity across builds there).
            raw_bd.append((name_p, name_f, m.similarity, m.confidence))

        # Derive new/removed from unmatched address sets.
        # Filter both unnamed stubs (sub_) and MSVC compiler-generated funclets
        # ($catch, $unwind, $vcall etc.) — BinDiff rarely matches these across
        # builds, producing phantom added/removed entries with no attribution value.
        removed = sorted(
            name for va, name in addr_to_name_P.items()
            if va not in matched_p_vas
            and not name.startswith("sub_")
            and not _ARTIFACT.search(name)
        )
        new = sorted(
            name for va, name in addr_to_name_F.items()
            if va not in matched_f_vas
            and not name.startswith("sub_")
            and not _ARTIFACT.search(name)
        )

        # bugs.md #63: BinDiff leaves a function unmatched when the fix restructures it
        # (added guards/branches) or when several functions look alike — and for MSSQL,
        # Ghidra sees the PE without its PDB, so BinDiff can't fall back on names. Such a
        # function was reported as BOTH removed and added and never diffed (and a pure
        # reorder made phantom cards). Pair what's still unmatched on both sides under
        # the same (non-sub_) name, by name, as name mode does; byte-identical pairs are
        # unchanged. Only names left over are added/removed.
        _unp = {n for va, n in addr_to_name_P.items()
                if va not in matched_p_vas and not n.startswith("sub_")}
        _unf = {n for va, n in addr_to_name_F.items()
                if va not in matched_f_vas and not n.startswith("sub_")}
        _by_name = _unp & _unf
        for name in sorted(_by_name):
            if _blob(P[name][1]) != _blob(F[name][1]):
                raw_bd.append((name, name, None, None))   # no BinDiff sim: name-paired
        removed = [n for n in removed if n not in _by_name]
        new = [n for n in new if n not in _by_name]

        # attr_cache must cover BOTH sides of each renamed pair so emit() never KeyErrors.
        attr_cache = {}
        for pn, fn, _, _ in raw_bd:
            for k in (pn, fn):
                if k not in attr_cache:
                    attr_cache[k] = _AT.attribute(k, attrib)
        for k in new + removed:
            if k not in attr_cache:
                attr_cache[k] = _AT.attribute(k, attrib)

        hits = []
        for prior_name, fixed_name, bd_sim, bd_conf in raw_bd:
            pchunks = P[prior_name][1]; fchunks = F[fixed_name][1]
            pL, fL, pL_sc, fL_sc, cls = _norm_chunk_pair(md, pchunks, fchunks,
                                                         P[prior_name][0], F[fixed_name][0])
            if cls in ("same", "churn"):
                continue
            sm = difflib.SequenceMatcher(a=pL_sc, b=fL_sc, autojunk=False)
            simr = sm.ratio()
            fpre = X.fix_signature(pL_sc, fL_sc, opcodes=sm.get_opcodes())[0]
            kind = "size" if _blob_len(pchunks) != _blob_len(fchunks) else cls
            hits.append((prior_name, fixed_name, kind, round(simr, 4), pL, fL, fpre,
                         bd_sim, bd_conf))

        funcs_total = len(hits) + len(new) + len(removed)
        # BinDiff hits: h[0]=prior_name, h[1]=fixed_name, h[6]=fpre, h[3]=simr.
        # A renamed function's CVE may sit on either name; sort attributed entries
        # (either name matches) before unattributed ones. Final tie-breakers (h[0], h[1])
        # make which functions survive the _EMIT_CAP truncation below deterministic
        # regardless of `matches`' row order: `hits`' pre-sort order inherits directly
        # from `raw_bd`, which inherits from `matches.items()` (mssql/_bindiff.py's
        # parse_matches() builds `matches` from a plain `SELECT ... FROM function` with no
        # ORDER BY, so row order is whatever SQLite's B-tree happens to return — not
        # something this code should rely on staying stable). Without this tie-breaker, two
        # exactly-tied candidates could swap places across two BinDiff runs of the identical
        # input, silently changing which ~N of a large tied group the cap truncates away
        # (the same class of bug as IMP-NT-1, fixed earlier for the name-mode sorts below —
        # there the non-determinism is proven to come from PYTHONHASHSEED-dependent
        # dict_keys-set-intersection order; here it's the same missing-tie-breaker shape
        # applied defensively, since this sort has no deterministic ordering guarantee to
        # fall back on either).
        hits.sort(key=lambda h: (attr_cache[h[0]][0] is None and attr_cache[h[1]][0] is None,
                                  -h[6], h[3], h[0], h[1]))

        rep(82, f"{pretty}: writing diffs")
        rel_cards = capped = 0
        for name in new:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            fL, _s, _i = _norm_chunks(md, F[name][1])
            emit(None, name, "added", 0.0, [], fL); rel_cards += 1
        for name in removed:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            pL, _s, _i = _norm_chunks(md, P[name][1])
            emit(name, None, "removed", 0.0, pL, []); rel_cards += 1
        for prior_name, fixed_name, kind, simr, pL, fL, fpre, bd_sim, bd_conf in hits:
            # Check attribution on BOTH sides: a rename may carry the CVE token on the new
            # name (fixed_name) while the old name (prior_name) has no match.
            if attr_cache[prior_name][0] or attr_cache[fixed_name][0] or fpre > 0 or rel_cards < _EMIT_CAP:
                emit(prior_name, fixed_name, kind, simr, pL, fL,
                     bd_sim=bd_sim, bd_conf=bd_conf); rel_cards += 1
            else:
                capped += 1

    else:
        common = P.keys() & F.keys()
        new = sorted(_named(F.keys() - P.keys()))
        removed = sorted(_named(P.keys() - F.keys()))
        # CRIT-NT-1: an unnamed function (no public PDB symbol -> keyed "sub_<rva>" by
        # _func_map()) used to be excluded here outright, so a genuine byte-level change
        # in it was reported nowhere — not changed, not added, not removed — contradicting
        # this module's own docstring ("the function is still diffed but labelled by
        # RVA... Stage 2 degrades, never fails"). An RVA shared by both builds (i.e. a key
        # present in `common`) is itself the identity signal for an unnamed function here
        # — it's the same code slot in both builds, undisturbed by any layout shift — so a
        # byte difference at that slot is a real, reliable change worth surfacing,
        # unattributed, exactly as documented.
        #
        # new/removed are deliberately NOT given the same treatment: an RVA that appears
        # on only one side is a far weaker signal for an unnamed function specifically,
        # since any unrelated layout shift elsewhere in the module changes every
        # downstream RVA — that would manufacture phantom added/removed entries for
        # functions that didn't actually change, not a missed one. _named() still filters
        # sub_-prefixed keys out of new/removed for exactly that reason.
        raw = [k for k in common if _blob(P[k][1]) != _blob(F[k][1])]

        hits = []
        for j, k in enumerate(raw):
            if j % 500 == 0:
                rep(6 + int(84 * j / max(1, len(raw))),
                    f"{pretty}: analyzing {j}/{len(raw)} changed")
            pchunks = P[k][1]; fchunks = F[k][1]
            # Per-chunk classification: if hot and cold paths changed independently,
            # classify each separately so an identical hot path doesn't mask a cold-path fix.
            # pL/fL = full concatenation for the diff output; pL_sc/fL_sc = changed chunks only
            # for similarity and pre-score (avoids hot-path inflation of the ratio).
            pL, fL, pL_sc, fL_sc, cls = _norm_chunk_pair(md, pchunks, fchunks,
                                                         P[k][0], F[k][0])
            if cls in ("same", "churn"):
                continue
            # one matcher on the scored (changed-chunk) lines — reused for ratio and pre-score
            # to avoid a second O(n^2) diff pass.
            sm = difflib.SequenceMatcher(a=pL_sc, b=fL_sc, autojunk=False)
            simr = sm.ratio()
            # pre-score from changed chunks only so fix-shaped cold-path changes are never
            # buried by the large identical hot path.
            fpre = X.fix_signature(pL_sc, fL_sc, opcodes=sm.get_opcodes())[0]
            kind = "size" if _blob_len(pchunks) != _blob_len(fchunks) else cls
            # store full pL/fL in hits so emit() writes the complete diff output
            hits.append((k, kind, round(simr, 4), pL, fL, fpre))

        funcs_total = len(hits) + len(new) + len(removed)
        # pre-compute attribution once per name; reused for sort key, emit, and cap-bypass checks
        attr_cache = {k: _AT.attribute(k, attrib)
                      for k in [h[0] for h in hits] + new + removed}
        # Name-mode hits: h[0]=name, h[5]=fpre, h[2]=simr. Final tie-breaker (h[0], the
        # name itself) makes which functions survive the _EMIT_CAP truncation below
        # deterministic across runs — without it, `common` (a dict_keys & dict_keys set
        # intersection) iterates in a hash-seed-dependent order, so two exactly-tied
        # candidates could swap places between runs of the SAME input, silently changing
        # which ~N of a large tied group get truncated away by the cap.
        hits.sort(key=lambda h: (attr_cache[h[0]][0] is None, -h[5], h[2], h[0]))

        rep(92, f"{pretty}: writing diffs")
        rel_cards = capped = 0
        for name in new:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            fL, _s, _i = _norm_chunks(md, F[name][1])
            emit(None, name, "added", 0.0, [], fL); rel_cards += 1
        for name in removed:
            if not (attr_cache[name][0] or rel_cards < _EMIT_CAP):
                capped += 1
                continue
            pL, _s, _i = _norm_chunks(md, P[name][1])
            emit(name, None, "removed", 0.0, pL, []); rel_cards += 1
        # A fix-shaped change (added guard/validation call -> fpre>0) is ALWAYS emitted, even if
        # unattributed and past the cap: this is what surfaced the small linked-server/index-guard
        # fixes the cap+similarity sort used to drop. The cap only bounds the remaining churn.
        for name, kind, simr, pL, fL, fpre in hits:
            if attr_cache[name][0] or fpre > 0 or rel_cards < _EMIT_CAP:
                emit(name, name, kind, simr, pL, fL); rel_cards += 1
            else:
                capped += 1

    rep(100, f"{pretty}: done")
    result = {"rel": rel, "pretty": pretty, "readable": readable, "funcs_total": funcs_total,
              "symbolized": symbolized, "ok": True, "skipped_functions": skipped,
              # db2_bugs.md DB2-4 (same cap here): ordinary changed functions not written
              "functions_capped": capped,
              "decompile_attempted": decompile_stats["attempted"],
              "decompile_failed": decompile_stats["failed"],
              "decompile_skipped": decompile_stats["skipped"],
              "decompile_failures": decompile_failures,
              # bugs.md #57: a requested BinDiff run that fell back used to be only a
              # stderr print; it's now part of the result (counted, exit 3)
              "bindiff_fallback": ({"rel": rel, "pretty": pretty,
                                   "reason": bd_failed_reason}
                                  if bd_failed_reason else None)}
    if one_side_symbols:                                    # bugs.md #58 (see above)
        result["ok"] = False                                # -> failed_binaries, exit 3;
        result["error"] = (                                 # its cards are still kept
            f"public symbols (PDB) were found for the {one_side_symbols} build only — both "
            f"sides were compared by address, without function names; a function whose "
            f"address moved between the builds could not be paired or compared")
    return result


# --------------------------------------------------------------------------- entry
def _empty_result(out, progress):
    result = {"available": True, "symbolized": 0,
              "counts": {"libs": 0, "changed_functions": 0, "readable_changed": 0,
                         "attributed": 0, "candidates": 0, "failed": 0,
                         "decompile_attempted": 0, "decompile_failed": 0},
              "libs": [], "failed_binaries": [], "files": [], "readable_files": []}
    with open(lp(os.path.join(out, "functions_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 2 complete — no changed binaries")
    return result


def run(prior_dir, fixed_dir, workdir, stage0=None, progress=None, use_bindiff=False,
        decompile=False, vuln_label=None, fixed_label=None, bindiff_only=None,
        decompile_max=None):
    out = os.path.join(workdir, "stage2")
    os.makedirs(lp(out), exist_ok=True)
    if not X.AVAILABLE:
        raise RuntimeError("Stage 2 needs capstone (pip install capstone)")
    pdb_cache = str(_GLOBAL_PDB_CACHE)
    os.makedirs(lp(pdb_cache), exist_ok=True)
    attrib = _AT.load_attrib(workdir)
    # Reachability of the Microsoft symbol server. Uses sym.server_reachable(), which
    # probes with the same requests/TLS/UA as the actual PDB download and treats any HTTP
    # response as reachable — so a healthy host that answers a probe with a non-2xx status
    # is no longer misread as offline (which silently zeroed out attribution).
    online = sym.server_reachable()

    if stage0 is None:
        # bugs.md #43: only a Stage 0 result produced by triage of THESE inputs is used. Any
        # changed_files.json found here used to be trusted — one written for another input
        # pair was analyzed as current (an empty one meant "nothing changed"); a missing,
        # stale or foreign one now raises instead.
        stage0 = _rs.bound_stage0(workdir, prior_dir, fixed_dir)

    # bugs.md #3: route every listed binary instead of filtering. Present on both sides ->
    # two-sided diff; on one side only -> one-sided inventory; on neither -> a recorded
    # failure. (A code_changed entry that exists on one side only — e.g. a changed_files.json
    # from an older triage reused by a Stage-2-only run — used to be dropped silently here.)
    changed, one_sided, missing = [], {}, []
    for c in [e["name"] for e in (stage0 or {}).get("code_changed", [])]:
        in_p = os.path.isfile(lp(os.path.join(prior_dir, c)))
        in_f = os.path.isfile(lp(os.path.join(fixed_dir, c)))
        if in_p and in_f:
            changed.append(c)
        elif in_p or in_f:
            one_sided[c] = "added" if in_f else "removed"
        else:
            missing.append(c)
    # PE binaries triage found on only one side -> one-sided inventory jobs
    for tag, root in (("added", fixed_dir), ("removed", prior_dir)):
        for e in (stage0 or {}).get(tag, []) or []:
            name = e.get("name") if isinstance(e, dict) else None
            if (name and e.get("kind") == "pe" and name not in changed
                    and os.path.isfile(lp(os.path.join(root, name)))):
                one_sided[name] = tag
    if not changed and not one_sided and not missing:
        return _empty_result(out, progress)

    # weight the progress bar by file size so it tracks real work, not lib count
    # (the two ~50 MB giants dominate; a count-weighted bar barely moved through them).
    weights = {}
    for rel in changed + list(one_sided):
        root = prior_dir if one_sided.get(rel) == "removed" else fixed_dir
        try:
            weights[rel] = max(1, os.path.getsize(lp(os.path.join(root, rel))))
        except OSError:
            weights[rel] = 1
    decompile_cache = os.path.join(out, "decompile_cache")
    # Per-version output: each build gets its own folders, so one build's disassembly and
    # pseudo-C can be reused later on its own (see _version_dirs()). The assembly DIFFS
    # compare the two builds, so they keep one folder per pair, as permanent per-run
    # copies named <vuln>_<fixed>_<run_ts>__fn__<dll>_<func>.asm.diff — one timestamp
    # computed ONCE per run so every file from this run shares it. Assembly diffing is
    # always on; the pseudo-C folders are only created with --decompile.
    run_ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    vver, fver = _version_token(vuln_label), _version_token(fixed_label)
    vlabel = vver if vuln_label else "vuln"
    flabel = fver if fixed_label else "fixed"
    version_dirs = _version_dirs(out, vver, fver)
    disassembled_dir = _layout.pair_diff_dir(out, vver, fver)
    os.makedirs(lp(disassembled_dir), exist_ok=True)
    # the per-version folders are created by the first file written into them
    # (_binary_folder), so a run with nothing to write leaves no empty folder
    if decompile:
        os.makedirs(lp(decompile_cache), exist_ok=True)
    # bug.md DB2-T1-3: BinDiff working data (Ghidra project + .BinExport + logs) lives beside
    # stage2/, not inside it, so the result tree stays clean and a re-run still finds the cache.
    bindiff_dir = os.path.join(workdir, "bindiff_work")
    from .._bindiff import bindiff_selected
    jobs_list = [{"prior_dir": prior_dir, "fixed_dir": fixed_dir, "rel": rel, "out": out,
                  "attrib": attrib, "online": online, "pdb_cache": pdb_cache,
                  "use_bindiff": use_bindiff and (bindiff_selected(rel, bindiff_only)
                                                  or bindiff_selected(_pretty(rel),
                                                                      bindiff_only)),
                  "decompile": decompile, "decompile_max": decompile_max,
                  "decompile_cache": decompile_cache, "bindiff_dir": bindiff_dir,
                  "disassembled_dir": disassembled_dir,
                  "version_dirs": version_dirs,
                  "run_ts": run_ts, "vuln_label": vlabel, "fixed_label": flabel,
                  "one_sided": one_sided.get(rel)}
                 for rel in changed + sorted(one_sided)]
    # db2_bugs.md DB2-12: binaries --bindiff-only left to name matching (by choice)
    not_selected = sorted(j["rel"] for j in jobs_list
                          if use_bindiff and not j["use_bindiff"] and not j["one_sided"])

    readable, funcs_total, libs_done, symbolized, failed = [], 0, [], 0, []
    failed += [{"rel": c, "pretty": _pretty(c), "error": "listed as changed by triage but "
                "present on neither side — could not be analyzed"} for c in missing]
    decompile_attempted = decompile_failed = decompile_skipped = 0

    skipped = []                 # changed functions too large to diff (#28)
    bd_fallbacks = []            # binaries --use-bindiff fell back to name matching (#57)
    capped_libs = []             # binaries that reached the card cap (db2_bugs.md DB2-4)
    dc_failures = []             # per-function pseudo-C failure reasons (DB2-14)

    def absorb(r):
        nonlocal funcs_total, symbolized, decompile_attempted, decompile_failed
        nonlocal decompile_skipped
        decompile_skipped += r.get("decompile_skipped", 0)
        dc_failures.extend(dict(f, rel=r["rel"]) for f in r.get("decompile_failures") or ())
        if r.get("functions_capped"):
            capped_libs.append({"rel": r["rel"], "count": r["functions_capped"]})
        if r.get("ok"):
            libs_done.append(r["pretty"])
        else:
            failed.append({"rel": r["rel"], "pretty": r["pretty"],
                           "error": r.get("error") or "binary could not be analyzed"})
        readable.extend(r["readable"])
        skipped.extend(r.get("skipped_functions") or [])
        if r.get("bindiff_fallback"):
            bd_fallbacks.append(r["bindiff_fallback"])
        funcs_total += r["funcs_total"]
        symbolized += 1 if r["symbolized"] else 0
        decompile_attempted += r.get("decompile_attempted", 0)
        decompile_failed += r.get("decompile_failed", 0)

    def on_error(rel, exc):
        # A binary whose worker raised (anything NOT already caught/handled inside
        # _process_dll, e.g. a symbol-fetch or capstone failure unrelated to BinDiff)
        # must not just vanish — record it so the result can't be mistaken for a clean
        # "this binary had no real changes".
        failed.append({"rel": rel, "pretty": _pretty(rel), "error": str(exc)[:300]})

    # Each changed DLL is diffed in its own process (host-friendly cap + below-normal
    # priority live in _parallel). Deterministic — output is sorted below regardless of
    # completion order.
    _parallel.run_jobs(jobs_list, _process_dll, weights, progress=progress,
                       on_result=absorb, on_error=on_error)

    from .. import _results
    _results.mark_cross_binary(readable)          # client+server / shared-code fix signal
    # Finalise attribution via _AT.resolve(): a 'high' name/CWE match (a specific-subsystem
    # hit) stands alone as an asserted CVE, corroboration only raising its confidence
    # med->high; a weaker ('med'/'low') match is asserted ONLY when corroborated by an
    # independent change signal (added security intrinsic, fix-shaped diff, or cross-binary),
    # else downgraded to a 'candidate', not a CVE claim.
    for r in readable:
        corrob = (bool(r.get("intrinsic")) or (r.get("fix_score") or 0) > 0
                  or bool(r.get("cross_binary")))
        conf, asserted = _AT.resolve(r.pop("name_conf", None), corrob)
        r["confidence"] = conf
        if not asserted and r.get("cve"):
            r["cve_candidate"] = r.pop("cve")
            r["cve"] = None
    readable.sort(key=_rank)
    result = {
        "available": True,
        "symbolized": symbolized,
        "counts": {"libs": len(libs_done), "changed_functions": funcs_total,
                   "readable_changed": len(readable),
                   "attributed": sum(1 for r in readable if r.get("cve")),
                   "candidates": sum(1 for r in readable if r.get("cve_candidate")),
                   "failed": len(failed),
                   "functions_skipped": len(skipped),
                   "bindiff_fallbacks": len(bd_fallbacks),
                   "functions_capped": sum(c["count"] for c in capped_libs),
                   "decompile_attempted": decompile_attempted,
                   "decompile_failed": decompile_failed,
                   "decompile_skipped": decompile_skipped},
        "bindiff_not_selected": not_selected,
        "decompile_failures": sorted(dc_failures, key=lambda f: (f["rel"], f["object"])),
        "capped_functions": sorted(capped_libs, key=lambda c: c["rel"]),
        "libs": libs_done,
        "failed_binaries": failed,
        "skipped_functions": sorted(skipped, key=lambda s: (s["rel"], s["name"])),
        "bindiff_fallbacks": sorted(bd_fallbacks, key=lambda b: b["rel"]),
        "files": [], "readable_files": readable,
    }
    with open(lp(os.path.join(out, "functions_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 2 complete")
    return result