"""DEPRECATED / SUPERSEDED — not wired into production (bug.md MSSQL-T2-1).

MSSQL Stage 2's `--decompile` pseudo-C is produced inside `mssql/stage2.py` through the shared,
backend-neutral `patch_differ_cli._decompile` (`decompile_cached_per_side`, see that module's
import of it). The `pipeline` only ever loads `mssql.{triage,stage1,stage2}`, so THIS module is
reached by no production code path — only a unit test imports it. It is retained for reference
(and for a possible future on-demand/viewer feature) and is wired to nothing. Do NOT import it
in new code — use `.._decompile` instead. Note two deliberate divergences from the Stage-2
path, which is why it must not be casually revived as-is:
  * `decompile_function()` calls `_dc.decompile_pair()` DIRECTLY, which RAISES
    (`GhidraNotConfigured` / `RuntimeError`) on no-Ghidra, timeout, or no-output — unlike the
    Stage-2 path's `_try_decompile`, which is best-effort and never raises.
  * it does NOT consult the shared `decompile_cache/per_function/` that a Stage-2 run fills
    (`_decompile._side_cache_file`), so it would re-run a Ghidra JVM for already-cached bytes.
A caller revived here should go through `_decompile.decompile_cached_per_side` instead.
If it is confirmed unneeded it can be removed outright (history: the review and
`docs/olde_bugs_fixed_2.md` #52).

----------------------------------------------------------------------------------------------
On-demand, cached C decompilation of a SINGLE changed MSSQL function (Stage 2).

Additive readable-C view (the assembly diff stays canonical). Reuses the shared Ghidra
blob-decompile engine (`.._decompile`); the only PE-specific part is pulling one function's
exact bytes, which we get from the same `.pdata`+PDB machinery Stage 2 already uses.
"""
import json
import os

from .. import _decompile as _dc
from ..db2._paths import lp
from . import symbols as sym
from .stage2 import (_safe, _func_map, _pretty, _extract_func_bytes, _partial_c_note,
                     _GLOBAL_PDB_CACHE)

GhidraNotConfigured = _dc.GhidraNotConfigured


def available():
    return _dc.available()


def cache_name(rel, name):
    return "fn__" + _safe(f"{rel}_{name}") + ".decomp.pair.json"


def _one_func_pe(dll_path, name, pdb_cache):
    """(begin_rva, code_bytes, omitted_chunks) for one function by name — via the cached PDB
    (offline; it was fetched during the Stage-2 run) + .pdata ranges. (None, None, 0) if
    absent/unsymbolized.

    bugs.md #52: this returned the function map's CHUNK LIST as if it were code bytes, so
    every call failed with TypeError before Ghidra ran. The chunks are now laid out exactly
    as Stage 2's --decompile does (_extract_func_bytes, bugs.md #25)."""
    fp = sym.fetch_pdb(dll_path, pdb_cache, online=False)
    with sym.Symbolizer(dll_path, fp) as s:
        fm = _func_map(dll_path, s)
    v = fm.get(name)
    if not v:
        return None, None, 0
    blob, omitted = _extract_func_bytes(v[1], v[0])
    return v[0], (blob or None), omitted


def decompile_function(prior_dir, fixed_dir, rel, name, out_dir, progress=None):
    """Decompile `name` from `rel` (an ENG_* engine file) on both sides to C, cache a
    .decomp.pair.json under out_dir, and return its path. Cached -> instant re-open."""
    os.makedirs(lp(out_dir), exist_ok=True)
    cache = os.path.join(out_dir, cache_name(rel, name))
    if os.path.isfile(lp(cache)):
        return cache
    # the shared cache Stage 2 fetched the PDBs into (it used to look in <out_dir>/pdb,
    # where nothing is ever downloaded, so every function came back unsymbolized)
    pdb_cache = str(_GLOBAL_PDB_CACHE)
    if progress:
        progress(5, "Carving function bytes")
    _pv, pb, p_omit = _one_func_pe(os.path.join(prior_dir, rel), name, pdb_cache)
    _fv, fb, f_omit = _one_func_pe(os.path.join(fixed_dir, rel), name, pdb_cache)
    if not pb and not fb:
        raise RuntimeError(f"symbol not found / unsymbolized on either side: {name} in {rel}")
    if progress:
        progress(20, "Running Ghidra decompiler")
    prior_c, fixed_c = _dc.decompile_pair(pb, fb)
    payload = {
        "object": f"{_pretty(rel)} :: {name}",
        "prior": (_partial_c_note(p_omit, _dc.norm_c(prior_c)) if pb
                  else "// (function absent in prior build)\n"),
        "fixed": (_partial_c_note(f_omit, _dc.norm_c(fixed_c)) if fb
                  else "// (function absent in fixed build)\n"),
        "truncated": False,
    }
    with open(lp(cache), "w", encoding="utf-8") as fh:
        json.dump(payload, fh)
    if progress:
        progress(100, "Done")
    return cache