"""Dev scratch script — not part of the pipeline, not imported by any package code.
Runs a quick MSSQL triage+stage2 pass using the package's own default layout
(patches/mssql/{vuln,fixed}, runs/mssql, cves.json next to this file), so it works on
any checkout without a hardcoded, machine-specific path."""
import sys, traceback
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

_ROOT = Path(__file__).parent

try:
    from patch_differ_cli.pipeline import run_pipeline
    run_pipeline(
        db="mssql",
        vuln_dir=_ROOT / "patches" / "mssql" / "vuln",
        fixed_dir=_ROOT / "patches" / "mssql" / "fixed",
        out_dir=_ROOT / "runs" / "mssql",
        cves_path=_ROOT / "cves.json",
        stages=("triage", "stage2"),
        verbose=True,
    )
except Exception:
    traceback.print_exc()
