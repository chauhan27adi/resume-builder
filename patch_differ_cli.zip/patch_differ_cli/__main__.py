from patch_differ_cli.cli import main
main()