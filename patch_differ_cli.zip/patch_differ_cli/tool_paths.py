"""Single source of truth for every bundled third-party tool path used by patch_differ_cli.

Covers the five tools needed for --use-bindiff (Track 1) and --decompile (Track 2): a JDK,
Ghidra (with the BinExport extension installed inside it), BinDiff, 7-Zip (MSSQL
acquisition only), and the CFR decompiler jar (Oracle OJVM Stage 1 only). See
docs/PREREQUISITES.md for exact versions and tools/tracks.md for how each one is used.

Resolution order is the same for every tool: an explicit env var override, else the bundled
copy under patch_differ_cli/tools/ (installed per docs/PREREQUISITES.md). There is NO
OS-wide fallback (no C:\\Program Files\\..., no C:\\Tools\\...) — if the env var isn't set
and the bundled copy is missing, the tool is reported as not configured (None / a
not-found exception downstream) instead of silently pointing at a location that may not
exist on this machine.

Every other module resolves these tools through the functions below. To move to a new tool
version, change the *_DIR / *_JAR constant here — nowhere else should a tools/<folder-name>
string or one of these env var names be hardcoded a second time.
"""
import contextlib
import os
import re
import signal
import subprocess
import tempfile
import time

from .db2._paths import lp


class GhidraNotConfigured(RuntimeError):
    """Raised when Ghidra is absent or analyzeHeadless cannot be found.

    Defined once here (not in _bindiff.py / _decompile.py separately) so that
    `except tool_paths.GhidraNotConfigured` reliably catches it regardless of which
    module raised it — _bindiff.py and _decompile.py both import this same class rather
    than each defining their own identically-named but distinct exception type.
    """


_ROOT = os.path.dirname(os.path.abspath(__file__))
TOOLS_DIR = os.path.join(_ROOT, "tools")

# Bundled folder/file names, matched to the exact names in docs/PREREQUISITES.md.
# Bump a tool's version in ONE place here.
JDK_DIR      = os.path.join(TOOLS_DIR, "jdk-17.0.12")
GHIDRA_DIR   = os.path.join(TOOLS_DIR, "ghidra_11.0.3_PUBLIC_20240410")
BINDIFF_BIN  = os.path.join(TOOLS_DIR, "bindiff8-installed", "bin")
SEVENZIP_EXE = os.path.join(TOOLS_DIR, "7-Zip-installed", "7z.exe")
CFR_JAR      = os.path.join(TOOLS_DIR, "cfr-0.152.jar")


def _jdk_present(home):
    return bool(home) and os.path.isfile(lp(os.path.join(
        home, "bin", "java.exe" if os.name == "nt" else "java")))


def java_home():
    """JDK that runs Ghidra (Tracks 1/2) and CFR: PATCHDIFF_JAVA_HOME if set, else the
    bundled JDK, else JAVA_HOME (only when no JDK is bundled).

    bugs.md #56: JAVA_HOME used to win over the bundled JDK. JAVA_HOME is a SYSTEM-wide
    setting, usually pointing at whatever JDK the user installed for other software — on
    the review machine JDK 26, under which Ghidra 11.0.3's OSGi framework reports
    `osgi.ee=UNKNOWN` and every custom Ghidra script (BinExport for Track 1, DecompileFunc
    for Track 2) fails to load. The bundled JDK 17 is the one this toolchain is pinned to,
    so it now wins; PATCHDIFF_JAVA_HOME is the explicit, tool-specific override."""
    explicit = os.environ.get("PATCHDIFF_JAVA_HOME")
    if explicit:
        return explicit
    if _jdk_present(JDK_DIR):
        return JDK_DIR
    return os.environ.get("JAVA_HOME") or JDK_DIR


# Newest Java SE major version Ghidra 11.0.x's OSGi framework recognizes; under a newer JDK
# it reports osgi.ee=UNKNOWN and no Ghidra script loads (bugs.md #56).
_GHIDRA_JAVA_MAX = 21
_JAVA_WARNED = set()


def java_major(home=None):
    """Major version of the JDK at `home` (default java_home()) from its `release` file,
    or None if it can't be determined."""
    import re
    try:
        with open(lp(os.path.join(home or java_home(), "release")), encoding="utf-8",
                  errors="replace") as fh:
            m = re.search(r'^JAVA_VERSION="(\d+)(?:\.(\d+))?', fh.read(), re.M)
    except OSError:
        return None
    if not m:
        return None
    major = int(m.group(1))
    return int(m.group(2) or 0) if major == 1 else major       # "1.8.0" -> 8


def ghidra_java_problem():
    """Why the JDK java_home() picked looks unsuitable for the configured Ghidra, or None
    if it looks fine or can't be determined."""
    major = java_major()
    if major is None:
        return None
    lo = 17
    try:
        with open(lp(os.path.join(ghidra_home() or "", "Ghidra", "application.properties")),
                  encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.startswith("application.java.min="):
                    lo = int(line.split("=", 1)[1].strip() or lo)
    except (OSError, ValueError):
        pass
    if major < lo or major > _GHIDRA_JAVA_MAX:
        return (f"Ghidra will run on JDK {major} ({java_home()}), outside the range it "
                f"supports here ({lo}-{_GHIDRA_JAVA_MAX}); its scripts may fail to load "
                f"(osgi.ee=UNKNOWN). Use the bundled JDK or set PATCHDIFF_JAVA_HOME.")
    return None


def warn_if_unsupported_java():
    """Print ghidra_java_problem() once per process (before a Ghidra launch)."""
    import sys
    msg = ghidra_java_problem()
    if msg and msg not in _JAVA_WARNED:
        _JAVA_WARNED.add(msg)
        print(f"WARNING: {msg}", file=sys.stderr)


def java_exe():
    """Full path to java(.exe) inside java_home()."""
    return os.path.join(java_home(), "bin", "java.exe" if os.name == "nt" else "java")


def child_env():
    """Subprocess environment with JAVA_HOME set and its bin/ prepended to PATH.

    PATH must carry <java_home>/bin: Ghidra's own launch script bootstraps a
    `java -version` check off PATH BEFORE it reads JAVA_HOME (a documented Ghidra gotcha),
    and a service/non-interactive environment may not have the user's PATH at all.
    """
    env = dict(os.environ)
    jh = java_home()
    env["JAVA_HOME"] = jh
    env["PATH"] = os.path.join(jh, "bin") + os.pathsep + env.get("PATH", "")
    return env


# ---------------------------------------------------------------------------
# Ghidra heap (db2_bugs.md DB2-11)
# ---------------------------------------------------------------------------

_MIB = 1 << 20
_GIB = 1 << 30
GHIDRA_DEFAULT_HEAP = 2 * _GIB        # analyzeHeadless(.bat)'s own `MAXMEM=2G`
# Heap per byte of input. sqlmin.dll (49.8 MiB) was fully analysed inside the default 2 GiB
# with no OutOfMemoryError (live MSSQL run), so 40x the input is at least what Ghidra needed.
_HEAP_PER_INPUT_BYTE = 40
HEAP_ENV = "PATCHDIFF_GHIDRA_MAXMEM"


def physical_memory():
    """Total physical RAM in bytes, or None if it can't be read."""
    try:
        if os.name == "nt":
            import ctypes

            class _MemStatus(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong)] + [
                    (n, ctypes.c_ulonglong) for n in (
                        "ullTotalPhys", "ullAvailPhys", "ullTotalPageFile", "ullAvailPageFile",
                        "ullTotalVirtual", "ullAvailVirtual", "ullAvailExtendedVirtual")]

            ms = _MemStatus()
            ms.dwLength = ctypes.sizeof(_MemStatus)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms)):
                return int(ms.ullTotalPhys)
            return None
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    except (AttributeError, OSError, ValueError):
        return None


def _parse_heap(text):
    m = re.fullmatch(r"\s*(\d+)\s*([mMgG])\s*", text)
    n = int(m.group(1)) * (_GIB if m.group(2) in "gG" else _MIB) if m else 0
    if n < 256 * _MIB:
        raise ValueError(f"{HEAP_ENV}={text!r}: expected a Java heap size of at least 256M, "
                         "such as 8G or 6144M")
    return n


def ghidra_heap(binary_size=0):
    """Maximum Java heap, in bytes, for a Ghidra run over a `binary_size`-byte input.

    PATCHDIFF_GHIDRA_MAXMEM (e.g. 8G) wins. Otherwise Ghidra's default 2 GiB, raised to
    40x the input for a large binary but capped at half the physical RAM (never below the
    default). Raises ValueError for an unusable PATCHDIFF_GHIDRA_MAXMEM."""
    v = os.environ.get(HEAP_ENV, "")
    if v.strip():
        return _parse_heap(v)
    step = 256 * _MIB
    need = max(GHIDRA_DEFAULT_HEAP, int(binary_size or 0) * _HEAP_PER_INPUT_BYTE)
    need = -(-need // step) * step
    ram = physical_memory()
    if ram:
        need = min(need, max(GHIDRA_DEFAULT_HEAP, ram // 2 // step * step))
    return need


def ghidra_env(binary_size=0):
    """child_env() plus the Ghidra heap for a `binary_size`-byte input.

    analyzeHeadless.bat hard-codes `set MAXMEM=2G` and ignores any MAXMEM in the
    environment, so the heap goes in _JAVA_OPTIONS: HotSpot applies it AFTER the command
    line, so its -Xmx overrides the script's. Nothing is added when the heap is the
    script's own 2 GiB and PATCHDIFF_GHIDRA_MAXMEM is unset, so that run is unchanged."""
    env = child_env()
    heap = ghidra_heap(binary_size)
    if heap != GHIDRA_DEFAULT_HEAP or os.environ.get(HEAP_ENV, "").strip():
        env["_JAVA_OPTIONS"] = f"{env.get('_JAVA_OPTIONS', '')} -Xmx{heap // _MIB}m".strip()
    return env


# ---------------------------------------------------------------------------
# Running an external tool (db2_bugs.md DB2-13; bugs.md MSSQL-1, MSSQL-4)
# ---------------------------------------------------------------------------

_POLL_SECONDS = 1.0
# A kept log is cut to its start and end once the run is over: Ghidra writes a warning line
# per decompiler hiccup, ~8x the input size for a small DLL, so a 50 MB one would leave
# hundreds of MB per side. The caller still gets the whole output to check for failures.
_LOG_KEEP_HEAD = 1 << 20
_LOG_KEEP_TAIL = 4 << 20


def _trim_log(fh, data):
    if len(data) <= _LOG_KEEP_HEAD + _LOG_KEEP_TAIL:
        return
    cut = len(data) - _LOG_KEEP_HEAD - _LOG_KEEP_TAIL
    fh.seek(0)
    fh.write(data[:_LOG_KEEP_HEAD]
             + f"\n... [{cut} bytes of output omitted] ...\n".encode()
             + data[-_LOG_KEEP_TAIL:])
    fh.truncate()


def _awake_seconds():
    """A clock that does not advance while the machine sleeps or hibernates, so a timeout
    measures work rather than a laptop left asleep overnight (bugs.md MSSQL-4: an import
    that spanned a 7-hour sleep "timed out after -22379 seconds"). Linux's monotonic clock
    already excludes suspend; Windows' needs QueryUnbiasedInterruptTime."""
    if os.name == "nt":
        try:
            import ctypes
            t = ctypes.c_ulonglong()
            if ctypes.windll.kernel32.QueryUnbiasedInterruptTime(ctypes.byref(t)):
                return t.value / 1e7          # 100 ns units
        except (AttributeError, OSError):
            pass
    return time.monotonic()


def _kill_tree(proc):
    """Kill `proc` and every process it started. analyzeHeadless.bat runs java.exe as a
    child of cmd.exe, and Popen.kill() ends only cmd.exe: the JVM went on analysing for
    hours after its timeout (bugs.md MSSQL-1)."""
    if os.name == "nt":
        if proc.poll() is not None:
            # Already gone: its PID may have been reused, so never taskkill it. (A JVM it
            # left behind cannot be found from a dead parent; in fg mode cmd.exe waits for
            # java.exe, so the wrapper is alive whenever the JVM is.)
            return
        taskkill = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                                "System32", "taskkill.exe")
        try:
            subprocess.run([taskkill, "/F", "/T", "/PID", str(proc.pid)],
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=60)
        except (OSError, subprocess.SubprocessError):
            pass
    else:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except OSError:
            pass
    try:
        proc.kill()
    except OSError:
        pass
    try:
        proc.wait(timeout=60)
    except subprocess.TimeoutExpired:
        pass


def run_tool(cmd, timeout=None, env=None, log_path=None, heartbeat=None):
    """Run `cmd` to completion; return subprocess.CompletedProcess whose `stdout` is the
    combined stdout+stderr bytes.

    * Output goes to a file, not a pipe. Every process that inherits a pipe holds it open,
      so after a timeout Python used to block until the surviving JVM exited by itself.
      `log_path` keeps that file as the tool's log; otherwise it is a temporary file.
    * On timeout, Ctrl+C or any other exception the whole process tree is killed. A timeout
      then raises subprocess.TimeoutExpired, carrying the output written so far.
    * `timeout` (seconds; None = no limit) counts awake time only, see _awake_seconds().
    * stdin is closed, so a tool that prompts gets end-of-file instead of hanging the run.
    * `heartbeat(elapsed, output_bytes, idle)` (optional, db2_bugs.md DB2-20) is called about
      once a second while the tool runs: awake seconds so far, the output written so far,
      and awake seconds since that output last grew. A heartbeat that raises is ignored.
    """
    kw = ({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt"
          else {"start_new_session": True})
    if log_path:
        os.makedirs(lp(os.path.dirname(os.path.abspath(log_path))), exist_ok=True)
        out = open(lp(log_path), "w+b")
    else:
        out = tempfile.TemporaryFile()
    with out:
        proc = subprocess.Popen(cmd, env=env, stdin=subprocess.DEVNULL, stdout=out,
                                stderr=subprocess.STDOUT, **kw)
        try:
            start = _awake_seconds()
            deadline = None if timeout is None else start + timeout
            grown_at, last_size = start, 0
            while True:
                try:
                    proc.wait(timeout=_POLL_SECONDS)
                    break
                except subprocess.TimeoutExpired:
                    now = _awake_seconds()
                    if deadline is not None and now >= deadline:
                        raise subprocess.TimeoutExpired(cmd, timeout) from None
                    if heartbeat is not None:
                        try:
                            size = os.fstat(out.fileno()).st_size
                            if size != last_size:
                                grown_at, last_size = now, size
                            heartbeat(now - start, size, now - grown_at)
                        except Exception:
                            pass
        except BaseException as exc:
            _kill_tree(proc)
            if isinstance(exc, subprocess.TimeoutExpired):
                out.seek(0)
                exc.output = out.read()
                if log_path:
                    _trim_log(out, exc.output)
            raise
        out.seek(0)
        data = out.read()
        if log_path:
            _trim_log(out, data)
    return subprocess.CompletedProcess(cmd, proc.returncode, data, None)


def ghidra_home():
    """Ghidra install directory: GHIDRA_HOME env var, else the bundled Ghidra."""
    return os.environ.get("GHIDRA_HOME") or GHIDRA_DIR


def analyze_headless():
    """Path to Ghidra's analyzeHeadless(.bat), or None if Ghidra isn't configured."""
    gh = ghidra_home()
    for cand in ("analyzeHeadless.bat", "analyzeHeadless"):
        p = os.path.join(gh, "support", cand)
        if os.path.isfile(lp(p)):
            return p
    return None


def locate_binexport_script(ghidra_home_override=None):
    """A path that proves the BinExport Ghidra extension is installed, or None.

    Track 1 runs our own PdffBinExport.java (db2/ghidra/), which needs the extension's
    COMPILED classes (BinExport2Builder / BinExport2) from its lib JAR — not the sample
    `ghidra_scripts/BinExport.java` script. So the sample script's presence is returned when
    it is there (the usual full install), but a JAR-only install is equally usable, so the
    extension's BinExport lib JAR is accepted as proof too (bug.md DB2-T1-8). The return value
    is only ever used as an installed/not-installed gate; the exporter path is fixed elsewhere.

    BinExport installs under Ghidra/Extensions/BinExport/ — NOT Extensions/Ghidra/ (a common
    mistake). Accepts an explicit ghidra_home override for callers that already resolved a
    specific Ghidra install.
    """
    gh = ghidra_home_override or ghidra_home()
    ext = os.path.join(gh, "Ghidra", "Extensions", "BinExport")
    script = os.path.join(ext, "ghidra_scripts", "BinExport.java")
    if os.path.isfile(lp(script)):
        return script
    lib = os.path.join(ext, "lib")
    try:                                   # lp() so a deep bundled path stays within MAX_PATH
        for fn in sorted(os.listdir(lp(lib))):
            if fn.lower().endswith(".jar") and "binexport" in fn.lower():
                return os.path.join(lib, fn)
    except OSError:
        pass
    return None


# ---------------------------------------------------------------------------- tool identity
# bugs.md #26/#29/#39: cached tool OUTPUT (BinExport files, pseudo-C, decompiled Java) used to
# be keyed by the input alone (plus at most a directory basename or a jar's size), so after a
# tool update or replacement the previous tool's output kept being served. These digests
# identify the tool install by CONTENT — the files that define what it produces — plus its
# path and the Java runtime that drives it. Not memoized by file stats: an in-place
# replacement can keep size and timestamps (the CFR case in #39). The files are small
# (a few MB of jars / one native binary), so hashing them per use is cheap.
def content_identity(paths):
    """Digest of `paths`: each one's normalized path and (if present) its full content."""
    import hashlib
    h = hashlib.sha256()
    for p in paths:
        h.update(os.path.normcase(os.path.abspath(p)).encode("utf-8", "surrogatepass"))
        try:
            with open(lp(p), "rb") as fh:
                h.update(b"\0<content>\0")
                for blk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(blk)
        except OSError:
            h.update(b"\0<missing>\0")
    return h.hexdigest()


def java_identity_files():
    return [java_exe(), os.path.join(java_home(), "release")]


def decompiler_identity():
    """The Ghidra install's version/build record (application.properties: version, build
    date, git revisions), its path, the Java runtime, and the native decompiler binary that
    produces the pseudo-C (#29)."""
    gh = ghidra_home() or ""
    os_dir = os.path.join(gh, "Ghidra", "Features", "Decompiler", "os")
    natives = []
    if os.path.isdir(os_dir):
        for sub in sorted(os.listdir(os_dir)):
            for name in ("decompile.exe", "decompile"):
                p = os.path.join(os_dir, sub, name)
                if os.path.isfile(lp(p)):
                    natives.append(p)
    return content_identity([os.path.join(gh, "Ghidra", "application.properties")]
                             + java_identity_files() + natives)


def binexport_identity(ghidra_home_override=None):
    """The Ghidra install's version/build record, its path, the Java runtime, and every
    file of the BinExport extension that shapes an export — its jars, script and
    properties (#26)."""
    gh = ghidra_home_override or ghidra_home() or ""
    ext = os.path.join(gh, "Ghidra", "Extensions", "BinExport")
    files = []
    for dp, _dn, fns in os.walk(ext):
        for fn in fns:
            if fn.endswith((".jar", ".java", ".properties")) or fn == "Module.manifest":
                files.append(os.path.join(dp, fn))
    files.sort()
    return content_identity([os.path.join(gh, "Ghidra", "application.properties")]
                             + java_identity_files() + files)


def protobuf_conflict(ghidra_home_override=None):
    """protobuf-java jars of DIFFERENT versions across the Ghidra install's module lib/
    folders, as [(version, path)] — empty when there's one version (or none).

    bugs.md #55: all module jars share one Ghidra class loader. Ghidra 11.0.3 ships
    protobuf-java-3.21.8 (Debug/Framework-AsyncComm) while the BinExport v12 extension
    ships 3.25.1, so the older classes won and every export crashed with IllegalAccessError
    (LazyStringArrayList.emptyList). The bundled install has been aligned (see
    tools/_replaced_by_patch_differ/); this check names the problem for any other install."""
    import glob
    import re
    gh = ghidra_home_override or ghidra_home() or ""
    found = {}
    for p in glob.glob(os.path.join(gh, "Ghidra", "*", "*", "lib", "protobuf-java-*.jar")):
        m = re.match(r"protobuf-java-(\d[\w.\-]*?)\.jar$", os.path.basename(p))
        if m:
            found.setdefault(m.group(1), []).append(p)
    if len(found) < 2:
        return []
    return sorted((v, p) for v, ps in found.items() for p in ps)


def locate_differ():
    """Path to the BinDiff CLI binary, or None if not found.

    BinDiff <=7 shipped the binary as 'differ'; BinDiff 8+ renamed it to 'bindiff'. Both
    names are checked at every candidate location.

    Resolution order:
      1. BINDIFF_PATH env var (explicit override)
      2. patch_differ_cli/tools/bindiff8-installed/bin/bindiff[.exe] or differ[.exe] (bundled)
      3. bindiff / bindiff.exe / differ / differ.exe on PATH
    """
    from_env = os.environ.get("BINDIFF_PATH")
    if from_env and os.path.isfile(lp(from_env)):
        return from_env
    for name in ("bindiff.exe", "bindiff", "differ.exe", "differ"):
        cand = os.path.join(BINDIFF_BIN, name)
        if os.path.isfile(lp(cand)):
            return cand
    import shutil
    return (shutil.which("bindiff") or shutil.which("bindiff.exe")
            or shutil.which("differ") or shutil.which("differ.exe"))


def sevenzip():
    """Path to 7z.exe: SEVENZIP env var, else the bundled 7-Zip."""
    return os.environ.get("SEVENZIP") or SEVENZIP_EXE


def cfr_jar():
    """Path to the CFR decompiler jar, or None if not found.

    CVE_PATCHDIFF_CFR env var, else the bundled jar. Returns None (not an unverified
    path) when absent, because java_decompile.py needs a clean signal to fall back to
    javap -c -p instead.
    """
    if os.environ.get("CVE_PATCHDIFF_CFR"):
        p = os.environ["CVE_PATCHDIFF_CFR"]
        return p if os.path.isfile(lp(p)) else None
    return CFR_JAR if os.path.isfile(lp(CFR_JAR)) else None


# ---------------------------------------------------------------------------
# Stale Ghidra script-cache recovery (shared by Track 1's BinExport.java and
# Track 2's DecompileFunc.java — both are custom GhidraScripts Ghidra dynamically
# compiles into an OSGi bundle, cached per-user, implicitly keyed to whichever JDK
# Ghidra last ran under)
# ---------------------------------------------------------------------------

def _ghidra_user_settings_dir():
    """Ghidra's per-user settings directory for the resolved install
    (~/.ghidra/.ghidra_<version>_<release>), derived from that install's own
    Ghidra/application.properties rather than hardcoded, so this keeps working if the
    bundled Ghidra version is ever bumped. Returns None if it can't be determined."""
    props_path = os.path.join(ghidra_home(), "Ghidra", "application.properties")
    try:
        props = {}
        with open(lp(props_path), encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    props[k.strip()] = v.strip()
        version = props.get("application.version")
        release = props.get("application.release.name")
        if not version or not release:
            return None
    except OSError:
        return None
    return os.path.join(os.path.expanduser("~"), ".ghidra", f".ghidra_{version}_{release}")


_CACHE_CHECKED_ENV = "PATCHDIFF_GHIDRA_CACHE_CHECKED"


@contextlib.contextmanager
def ghidra_script_cache_checked(enabled=True):
    """Check (and after a JDK change clear) Ghidra's compiled-script cache once, here, then
    let every Ghidra launch inside the block skip that check (db2_bugs.md DB2-19).

    The check compares Ghidra's java_home.save with our JDK, and Ghidra rewrites that file
    only when it launches. So after a JDK change every parallel worker saw the mismatch and
    deleted the shared osgi/ cache, possibly while another worker's JVM was compiling or
    loading a script from it: an intermittent script-load failure. Workers inherit the
    marker through the environment (spawned processes copy os.environ). It holds the JDK
    path, so a launch with another JDK still checks; it is removed when the block ends."""
    if not enabled:
        yield
        return
    clear_stale_ghidra_script_cache()
    prev = os.environ.get(_CACHE_CHECKED_ENV)
    os.environ[_CACHE_CHECKED_ENV] = java_home()
    try:
        yield
    finally:
        if prev is None:
            os.environ.pop(_CACHE_CHECKED_ENV, None)
        else:
            os.environ[_CACHE_CHECKED_ENV] = prev


def clear_stale_ghidra_script_cache():
    """Best-effort recovery for IMP-T2-1: if Ghidra's own record of which JDK it last ran
    under (java_home.save) doesn't match the JDK we are about to launch it with, clear
    ONLY its compiled-script OSGi bundle cache (the `osgi/` subdirectory) — never
    anything else under Ghidra's settings directory (not `preferences`, not `tools/`, not
    logs). That cache is Ghidra's own regenerable build output (analogous to a
    __pycache__), not user data: Ghidra recompiles it from the .java sources on its next
    run, at the cost of a few extra seconds, nothing more.

    Why this matters: a JDK switch (upgrading, or — exactly what happened in this
    project's own history — standardizing on JDK 17 after an earlier JDK 21/26
    compatibility experiment) leaves a stale bundle that fails to load with an opaque
    `org.osgi.framework.BundleException: ... osgi.ee=UNKNOWN`, while Ghidra's own process
    still exits 0. Both BinExport.java (Track 1) and DecompileFunc.java (Track 2) are
    equally exposed since they're both loaded the same way — this is the single, shared
    fix for both rather than two separate ones.

    Never raises: this is a best-effort pre-flight step. If anything about the detection
    is uncertain (can't read application.properties, no java_home.save recorded yet, a
    permissions error clearing the cache), it does nothing and silently lets Ghidra run
    normally — whatever happens next is reported through the existing, already-diagnosable
    failure paths (CRIT-T1-1 / CRIT-T2-1's fixes), not masked by this function.
    """
    try:
        if os.environ.get(_CACHE_CHECKED_ENV) == java_home():
            return   # checked once by the parent before the workers started (DB2-19)
        settings_dir = _ghidra_user_settings_dir()
        if not settings_dir or not os.path.isdir(lp(settings_dir)):
            return
        save_file = os.path.join(settings_dir, "java_home.save")
        if not os.path.isfile(lp(save_file)):
            return
        with open(lp(save_file), encoding="utf-8", errors="replace") as f:
            recorded_jdk = f.read().strip()
        if not recorded_jdk:
            return
        current_jdk = java_home()
        if os.path.normcase(os.path.abspath(recorded_jdk)) == \
                os.path.normcase(os.path.abspath(current_jdk)):
            return   # same JDK Ghidra last ran under — the script cache should be valid
        osgi_dir = os.path.join(settings_dir, "osgi")
        # Defensive: only ever remove a directory literally named "osgi" directly under
        # Ghidra's own settings dir — never anything else, even if the path math above
        # somehow produced something unexpected.
        if os.path.basename(osgi_dir) != "osgi" or not os.path.isdir(lp(osgi_dir)):
            return
        import shutil
        import sys
        shutil.rmtree(lp(osgi_dir), ignore_errors=True)
        print(f"NOTE: cleared Ghidra's compiled-script cache ({osgi_dir}) — it was built "
             f"under a different JDK ({recorded_jdk}) than the one about to be used "
             f"({current_jdk}); Ghidra will recompile it automatically on this run.",
             file=sys.stderr)
    except Exception:
        pass
