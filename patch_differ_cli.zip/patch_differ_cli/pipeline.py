"""Standalone pipeline orchestrator.

Runs the three-stage diff pipeline sequentially (no HTTP gates):
  Stage 0 (triage) → Stage 1 (readable diff) → Stage 2 (binary/function diff)

Each stage writes its output to <out_dir>/stage0/, stage1/, stage2/, so the JSON
results are consistent and can be consumed by the same downstream tooling.

Auto-acquisition fallback
-------------------------
If --vuln / --fixed directories are absent or empty the pipeline automatically
downloads and extracts the patch binaries before running any stage:

  MSSQL  — scrapes Microsoft Update Catalog by KB number, downloads the .exe,
            carves CABs, and extracts SQL_ENGINE_CORE_INST.MSP via 7-Zip.
            Requires: fixed_kb + vuln_kb (both sides needed).

  DB2    — anonymous Docker registry v2 pull (container:<ref>) or Fix Central
            fixpack drop (manual:<label>).
            Requires: vuln_url + fixed_url.

  Oracle — login-gated; auto-acquisition is not possible. A clear error is raised.
"""
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

from . import _result_state as _rs

# Default location for manually placed patch binaries, relative to this package.
# Structure: patches/<db>/vuln/  and  patches/<db>/fixed/
_PATCHES_DIR = Path(__file__).parent / "patches"

_BACKENDS = {
    "mssql": {
        "triage":  "patch_differ_cli.mssql.triage",
        "stage1":  "patch_differ_cli.mssql.stage1",
        "stage2":  "patch_differ_cli.mssql.stage2",
    },
    "db2": {
        "triage":  "patch_differ_cli.db2.triage",
        "stage1":  "patch_differ_cli.db2.stage1",
        "stage2":  "patch_differ_cli.db2.stage2",
    },
    "oracle": {
        "triage":  "patch_differ_cli.oracle.triage",
        "stage1":  "patch_differ_cli.oracle.stage1",
        "stage2":  "patch_differ_cli.oracle.stage2",
    },
}

_ALL_STAGES = ("triage", "stage1", "stage2")


def default_out_dir(db):
    """Default output directory for a backend: patch_differ_cli/runs/<db>/.

    Single source of truth shared by run_pipeline() (its --out default) and the CLI
    (so it can report the real path instead of 'None' when --out is omitted)."""
    return _PATCHES_DIR.parent / "runs" / db


def _import(module_path):
    import importlib
    return importlib.import_module(module_path)


def _progress_printer(label):
    def cb(pct, phase=""):
        bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
        msg = f"\r  [{bar}] {pct:3d}%  {phase}"
        sys.stdout.write(msg.ljust(72))
        sys.stdout.flush()
        if pct >= 100:
            sys.stdout.write("\n")
    return cb


# ---------------------------------------------------------------------------
# Acquisition helpers
# ---------------------------------------------------------------------------

def _dir_has_content(path):
    """Return True if path exists and contains at least one file."""
    p = Path(path)
    if not p.exists():
        return False
    return any(f.is_file() for f in p.rglob("*"))


def _normalize_kb(kb):
    """Strip surrounding whitespace and an optional 'KB' prefix → bare digit string; None
    when no KB was given; ValueError for a malformed one (bugs.md #38 — see
    mssql.acquire.normalize_kb())."""
    from patch_differ_cli.mssql.acquire import normalize_kb
    return normalize_kb(kb)


def _has_engine_files(path):
    """True if `path` top-level already holds extracted engine files (ENG_*).

    Mirrors the 'already extracted' marker used by mssql/acquire.py (extract_engine and
    acquire both test `startswith("ENG_")`), so manual and auto-acquire paths agree on
    what counts as a ready-to-diff engine directory."""
    p = Path(path)
    if not p.exists():
        return False
    return any(f.is_file() and f.name.startswith("ENG_") for f in p.iterdir())


def _prune_paths(*paths):
    """Best-effort removal of intermediate extraction artifacts (dirs or files)."""
    for p in paths:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass


def _mssql_exes(side_dir):
    """The .exe files directly in side_dir, largest first. A self-extracting MSSQL patch
    installer is the large .exe, so exes[0] is the one _prepare_mssql_dir extracts. Shared
    by extraction and build-labelling so both act on the same file. [] on any error."""
    try:
        return sorted(
            (f for f in Path(side_dir).iterdir()
             if f.is_file() and f.suffix.lower() == ".exe"),
            key=lambda f: f.stat().st_size, reverse=True,
        )
    except OSError:
        return []


def _prepare_mssql_dir(side_dir, out_dir, side, verbose):
    """Normalize a manually-populated MSSQL input dir to an extracted engine dir.

    Two manual layouts are supported:
      * already-extracted engine files (ENG_*)  — used as-is (what Stage 0 triage expects,
        and also exactly what auto-acquire produces).
      * a raw self-extracting patch installer (.exe) — extracted here via the SAME
        extract_engine() path auto-acquire uses, into <out_dir>/acquire/<side>/engine.
    Any other content is returned unchanged (no supported layout → current behaviour).

    Detection order is deliberate: ENG_* is checked first so a genuine engine dir is never
    re-processed, and the .exe branch only fires when there are no engine files present.
    The user's original .exe is never moved or deleted — only the cabs/_msp intermediates
    created during extraction are pruned.
    """
    from patch_differ_cli.mssql import acquire as acq

    side_dir = Path(side_dir)
    if _has_engine_files(side_dir):
        return str(side_dir)

    exes = _mssql_exes(side_dir)
    if not exes:
        return str(side_dir)

    exe = exes[0]
    sd = Path(out_dir) / "acquire" / side
    eng = sd / "engine"
    cabs = sd / "cabs"
    if verbose:
        print(f"  [{side}] found installer {exe.name} — extracting engine files (7-Zip)")
    acq.extract_engine(str(exe), str(eng), str(cabs))
    # Drop the intermediate cabs + _msp staging; never touch the user's .exe input.
    _prune_paths(str(cabs), str(eng) + "_msp")
    return str(eng)


_KB_IN_NAME = None


def _mssql_version_label(supplied_dir, engine_dir):
    """Which MSSQL build a side is, for naming its per-version output folders, when no
    --vuln-kb / --fixed-kb was given: the KB in the file name of the installer that
    _prepare_mssql_dir extracts -- the single largest .exe (e.g.
    SQLServer2022-KB5122771-x64.exe -> KB5122771) -- else the engine's file version
    (sqlservr.exe, e.g. 2022.160.1200.5), else None.

    The label is read from the *same* .exe that gets extracted, so it always describes the
    build actually disassembled: a larger KB-less installer alongside a small KB-named
    helper is labelled by the engine version, not by the helper's KB. When two .exe files
    tie for largest, which one is extracted is not well-defined, so we fall back to the
    authoritative engine version rather than guess a KB."""
    import re
    global _KB_IN_NAME
    if _KB_IN_NAME is None:
        _KB_IN_NAME = re.compile(r"(?i)(?<![A-Za-z0-9])KB(\d{6,8})(?!\d)")
    exes = _mssql_exes(supplied_dir) if supplied_dir else []
    unambiguous = exes and not (
        len(exes) > 1 and exes[0].stat().st_size == exes[1].stat().st_size)
    if unambiguous:
        m = _KB_IN_NAME.search(exes[0].name)
        if m:
            return "KB" + m.group(1)
    return _mssql_engine_version(engine_dir)


def _mssql_engine_version(engine_dir):
    """sqlservr.exe's file version from its version resource, or None.

    Stage 0 renames the engine binary to ENG_RE_sqlservr_exe_64 (no real .exe extension),
    so the match is on the "sqlservr" token. A config/mui/pdb sibling that shares that
    token (e.g. ENG_RE_sqlservr_exe_config_64) is pushed to the back and, not being a PE,
    is skipped by the parse-and-continue loop -- so a stray non-PE never hides the real
    engine binary, and a candidate with no version resource falls through to the next."""
    try:
        import pefile

        def _config_like(name):
            low = name.lower()
            return any(k in low for k in ("config", "_mui", "_pdb", "manifest"))

        exes = [f for f in Path(engine_dir).iterdir()
                if f.is_file() and "sqlservr" in f.name.lower()]
        # Real binary first; obvious data siblings last. The PE parse below is the final
        # arbiter, so this only affects which candidate is tried first.
        exes.sort(key=lambda f: _config_like(f.name))
        for exe in exes:
            try:
                pe = pefile.PE(str(exe), fast_load=True)
                try:
                    pe.parse_data_directories(
                        directories=[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_RESOURCE"]])
                    fi = pe.VS_FIXEDFILEINFO[0]
                    return ".".join(str(x) for x in (fi.FileVersionMS >> 16,
                                                     fi.FileVersionMS & 0xFFFF,
                                                     fi.FileVersionLS >> 16,
                                                     fi.FileVersionLS & 0xFFFF))
                finally:
                    pe.close()
            except Exception:
                continue
    except Exception:
        return None
    return None


def _acquire_mssql(out_dir, fixed_kb, vuln_kb, verbose, sides=("vuln", "fixed")):
    """Download + extract the requested MSSQL engine dir(s) (default: both).
    Returns a dict with only the key(s) for `sides`, e.g. {'vuln': dir}."""
    from patch_differ_cli.mssql import acquire as acq

    fkb = _normalize_kb(fixed_kb)
    vkb = _normalize_kb(vuln_kb)
    if "fixed" in sides and not fkb:
        raise ValueError(
            "MSSQL auto-acquisition requires --fixed-kb "
            "(e.g. --fixed-kb 5084815)."
        )
    if "vuln" in sides and not vkb:
        raise ValueError(
            "MSSQL auto-acquisition requires --vuln-kb — the KB number of the "
            "vulnerable build to compare against (e.g. --vuln-kb 5029395). "
            "Check https://sqlserverupdates.com for the GDR release history."
        )

    patch = {
        "kb":         fkb,
        "fixed_build": f"KB{fkb}" if fkb else None,
        "vuln_kb":    vkb,
        "vuln_build": f"KB{vkb}" if vkb else None,
        "dl_url":     None,
        "vuln_dl_url": None,
    }
    progress = _progress_printer("acquire") if verbose else None
    return acq.acquire(patch, str(out_dir), progress=progress, online=True, sides=sides)


_DB2_ARCHIVE_EXT = (".tar.gz", ".tgz", ".tar")
# Placeholder files that Explorer, OneDrive or git leave in an input folder. They belong to
# neither a fixpack drop nor an extracted tree, so they must not decide which one a folder
# is (db2_bugs.md DB2-25: a desktop.ini next to the archive made it "a tree" again).
_DB2_SIDECARS = frozenset({"desktop.ini", "thumbs.db", "ehthumbs.db", ".ds_store",
                           ".gitkeep", ".keep", ".gitignore"})


def _is_db2_archive(f):
    return f.name.lower().endswith(_DB2_ARCHIVE_EXT)


def _is_db2_sidecar(f):
    return f.name.lower() in _DB2_SIDECARS


def _db2_only_sidecars(side_dir):
    """True when `side_dir` holds files, but only placeholder sidecars: an empty input folder
    as far as the user is concerned, to be acquired like one (DB2-25)."""
    p = Path(side_dir)
    if not p.is_dir():
        return False
    seen = False
    for f in p.rglob("*"):
        if f.is_file():
            if not _is_db2_sidecar(f):
                return False
            seen = True
    return seen


def _db2_archive_only(side_dir):
    """The single Fix Central archive in `side_dir` when the folder holds nothing else, else
    None. A folder holding only archive(s) is a fixpack drop, not an extracted tree. Several
    archives are ambiguous and raise. Placeholder sidecars are ignored (DB2-25). A flat
    folder (no subfolders) holding an archive plus other loose files also raises: it is a
    drop with stray files, and guessing would diff the archive as a plain file. A folder
    with subfolders is an extracted tree and is used as it is."""
    p = Path(side_dir)
    if not p.is_dir():
        return None
    archives, other = [], None
    for f in p.rglob("*"):
        if not f.is_file() or _is_db2_sidecar(f):
            continue
        if not _is_db2_archive(f):
            other = f
            break
        archives.append(f)
    if other is None:
        if len(archives) > 1:
            raise ValueError(
                f"{side_dir} holds {len(archives)} archives "
                f"({', '.join(f.name for f in archives)}); "
                "keep exactly one DB2 fixpack archive per side.")
        return archives[0] if archives else None
    entries = list(p.iterdir())
    loose = [f for f in entries if f.is_file() and not _is_db2_sidecar(f)]
    if not any(e.is_dir() for e in entries) and any(_is_db2_archive(f) for f in loose):
        extra = [f.name for f in loose if not _is_db2_archive(f)]
        raise ValueError(
            f"{side_dir} holds a DB2 fixpack archive and other files "
            f"({', '.join(extra[:5])}{', ...' if len(extra) > 5 else ''}); keep only the "
            "fixpack archive in this folder, or supply an extracted tree.")
    return None


def _db2_archive_label(archive):
    """Version tag for an IBM fixpack file name, e.g. update_90467_v11.5.9_... -> v11.5.9-90467."""
    import re
    m = re.match(r"(?i)update_(\d+)_(v[\d.]+)_", archive.name)
    return f"{m.group(2)}-{m.group(1)}" if m else archive.name.split(".")[0]


def _oracle_zip_label(side_dir):
    """ORA-T1-2: a version label for an Oracle side from the RU patch zip the user left in
    `side_dir`, or None when there isn't exactly one .zip there (e.g. only extracted contents
    were placed — then the caller falls back to "unversioned", or --*-label can be given).

    Oracle RU zips are named p<patch-id>_<version>_<platform>.zip (e.g.
    p35643107_190000_Linux-x86-64.zip); the patch id uniquely identifies the RU, so it is
    preferred as a short, meaningful label, with the file stem as the fallback."""
    import re
    try:
        zips = sorted(f for f in Path(side_dir).iterdir()
                      if f.is_file() and f.suffix.lower() == ".zip")
    except OSError:
        return None
    if len(zips) != 1:                       # none, or several (ambiguous) — don't guess
        return None
    m = re.match(r"(?i)(p\d{5,})(?![0-9])", zips[0].name)
    return m.group(1) if m else zips[0].stem


def _stage_db2_archive(archive, out_dir, side):
    """Make `archive` visible to the manual Fix Central acquisition as
    <out_dir>/acquire/<side>/drop/<name>. Hard-linked when possible (the archives are
    ~GB-sized), copied otherwise; the user's file is never moved or modified.

    An already-staged file is kept only when it IS the user's archive (the same hard-linked
    file) or has the same content. Equal size is not enough: the acquire cache fingerprints
    the staged file, so a stale same-size copy would make it reuse the previous build's
    tree. A copy goes through a .partial file, so an interrupted copy never leaves a
    truncated archive under the real name. It copies the bytes only (copyfile, not copy2):
    a read-only attribute carried over from the user's file would make the next
    replacement fail to delete it."""
    drop = Path(out_dir) / "acquire" / side / "drop"
    drop.mkdir(parents=True, exist_ok=True)
    others = [f for f in drop.iterdir()
              if f.is_file() and f.name.lower().endswith(_DB2_ARCHIVE_EXT)
              and f.name != archive.name]
    if others:
        raise ValueError(
            f"{drop} already holds a different archive ({others[0].name}); remove it so the "
            f"{side} build is unambiguous.")
    dest = drop / archive.name
    if dest.exists():
        if _same_file_content(archive, dest):
            return
        dest.unlink()
    try:
        os.link(archive, dest)
    except OSError as exc:
        # db2_bugs.md DB2-26: a full copy of a multi-GB fixpack must not happen unannounced
        print(f"NOTE: copying {archive.name} ({archive.stat().st_size / (1 << 30):.1f} GiB) "
              f"to {drop} because it can't be hard-linked there ({exc.strerror or exc}); "
              f"an --out on the same drive as the archive avoids the copy.", file=sys.stderr)
        part = dest.with_name(dest.name + ".partial")
        try:
            shutil.copyfile(archive, part)
            os.replace(part, dest)
        except BaseException:
            part.unlink(missing_ok=True)
            raise


def _same_file_content(a, b):
    """True if `b` is the file `a` (a hard link to it) or a byte-identical copy of it."""
    from patch_differ_cli import _acquire_state as _acq_state
    try:
        if os.path.samefile(a, b):
            return True
        if os.path.getsize(a) != os.path.getsize(b):
            return False
        return (_acq_state.file_fingerprint(str(a))["sha256"]
                == _acq_state.file_fingerprint(str(b))["sha256"])
    except OSError:
        return False


def _acquire_db2(out_dir, vuln_url, fixed_url, verbose, sides=("vuln", "fixed")):
    """Pull / extract the requested DB2 version tree(s) (default: both).
    Returns a dict with only the key(s) for `sides`, e.g. {'vuln': dir}."""
    import patch_differ_cli.db2.acquire as _db2_acq

    # Redirect the layer cache into the workdir — avoids the service.root import.
    _db2_acq._LAYER_CACHE = str(out_dir / "acquire" / ".layers")

    if "vuln" in sides and not vuln_url:
        raise ValueError(
            "DB2 auto-acquisition requires --vuln-url.\n"
            "  container pull  : container:icr.io/db2_community/db2:12.1.5.0\n"
            "  Fix Central drop: manual:v12.1.5.0  "
            "(place the .tar.gz into <out>/acquire/vuln/drop/ first)"
        )
    if "fixed" in sides and not fixed_url:
        raise ValueError(
            "DB2 auto-acquisition requires --fixed-url.\n"
            "  container pull  : container:icr.io/db2_community/db2:12.1.5.0\n"
            "  Fix Central drop: manual:v12.1.5.0  "
            "(place the .tar.gz into <out>/acquire/fixed/drop/ first)"
        )

    patch = {
        "vuln_dl_url": vuln_url,
        "dl_url":      fixed_url,
    }
    progress = _progress_printer("acquire") if verbose else None
    acquired = _db2_acq.acquire(patch, str(out_dir), progress=progress, online=True,
                                sides=sides)
    for side in sides:
        _warn_db2_skipped_members(Path(out_dir) / "acquire" / side, side)
        _note_db2_skipped_components(Path(out_dir) / "acquire" / side, side)
    return acquired


def _note_db2_skipped_components(side_dir, side):
    """db2_bugs.md DB2-9: install components whose names mark them as documentation,
    samples or messages are not extracted. Say how many and how big, and WARN when one of
    them holds code-like files (libraries, jars, bin/): those would never be diffed."""
    from .db2.acquire import SKIPPED_COMPONENTS
    path = Path(side_dir) / SKIPPED_COMPONENTS
    try:
        comps = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    if not comps:
        return
    total = sum(c.get("size") or 0 for c in comps)
    print(f"NOTE: DB2 {side} build: {len(comps)} install component(s) skipped as docs, "
          f"samples or messages ({total / (1 << 20):.0f} MiB); list: {path}", file=sys.stderr)
    code = [c for c in comps if c.get("code_members")]
    if code:
        print(f"WARNING: DB2 {side} build: {len(code)} skipped component(s) contain code-like "
              f"files that are not diffed: "
              + "; ".join(f"{c['name']} ({c['code_members']} file(s), e.g. "
                          f"{', '.join(c.get('examples') or [])})" for c in code[:5]),
              file=sys.stderr)
    unread = [c["name"] for c in comps if c.get("code_members") is None]
    if unread:
        print(f"WARNING: DB2 {side} build: {len(unread)} skipped component(s) could not be "
              f"inspected for code: {', '.join(unread[:5])}", file=sys.stderr)


def _check_db2_roots(vuln_dir, fixed_dir, log):
    """db2_bugs.md DB2-8: name the two DB2 roots being compared, and warn when they share
    little at the top level. A root found through the libdb2e.so.1 fallback in an
    unexpected place would otherwise be diffed against the other side's real root, making
    nearly every file look added or removed."""
    log(f"\n[DB2 roots compared: vuln {vuln_dir} | fixed {fixed_dir}]")
    try:
        a, b = set(os.listdir(vuln_dir)), set(os.listdir(fixed_dir))
    except OSError:
        return
    if a and b and len(a & b) / len(a | b) < 0.5:
        print(f"WARNING: the vuln and fixed DB2 roots have little in common at the top level "
              f"({len(a & b)} of {len(a | b)} entries shared): {vuln_dir} vs {fixed_dir}. One "
              f"side may be a different part of the install; check the trees before trusting "
              f"the diff.", file=sys.stderr)


def _warn_unsymbolized(triage_result):
    """db2_bugs.md DB2-2: say BEFORE Stage 2 which code-changed binaries it can diff only
    partly (exported functions only) or not at all (no function symbols, or not x86-64),
    instead of the run discovering it per binary. Printed whether or not --quiet."""
    entries = (triage_result or {}).get("code_changed") or []
    for kind, what in (("dynsym", "have exported function symbols only (no .symtab): "
                                  "their static functions will not be compared"),
                       ("none", "have no function symbols: Stage 2 cannot diff them"),
                       ("unsupported", "are not 64-bit little-endian ELF: Stage 2 cannot "
                                       "diff them")):
        names = [e["name"] for e in entries if e.get("symbols") == kind]
        if names:
            print(f"WARNING: {len(names)} code-changed binary(ies) {what} — "
                  + ", ".join(names[:5]) + (", ..." if len(names) > 5 else ""),
                  file=sys.stderr)


def _check_budget_options(use_bindiff, decompile, bindiff_only, decompile_max):
    """db2_bugs.md DB2-12: validate --bindiff-only / --decompile-max. Returns them
    normalised: a list of non-empty glob patterns (comma-separated values split) or None,
    and a positive int or None. Raises ValueError for an unusable combination, so a typo
    can't silently run every binary through Ghidra or skip all pseudo-C."""
    if bindiff_only:
        if isinstance(bindiff_only, str):
            bindiff_only = [bindiff_only]
        pats = [p.strip() for v in bindiff_only for p in str(v).split(",") if p.strip()]
        if not pats:
            raise ValueError("--bindiff-only: no pattern given")
        if not use_bindiff:
            raise ValueError("--bindiff-only only applies with --use-bindiff")
        bindiff_only = pats
    else:
        bindiff_only = None
    if decompile_max is not None:
        try:
            n = int(decompile_max)
        except (TypeError, ValueError):
            n = 0
        if n < 1 or str(n) != str(decompile_max).strip():
            raise ValueError(f"--decompile-max {decompile_max!r}: expected a positive whole "
                             "number")
        if not decompile:
            raise ValueError("--decompile-max only applies with --decompile")
        decompile_max = n
    return bindiff_only, decompile_max


def _synced_folder(path):
    """The OneDrive folder `path` lies in, or None."""
    p = os.path.normcase(os.path.abspath(str(path)))
    for var in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        root = os.environ.get(var)
        if not root:
            continue
        r = os.path.normcase(os.path.abspath(root)).rstrip("\\/")
        if p == r or p.startswith(r + os.sep):
            return root
    return None


def _warn_if_synced(out_dir):
    """db2_bugs.md DB2-10: the default output folder sits inside the workspace, which is
    often OneDrive. Extracted builds and Ghidra projects are several GB: syncing them
    slows the run, sync locks can break extraction, and the long paths can pass the
    259-character limit Ghidra/BinDiff need."""
    root = _synced_folder(out_dir)
    if root:
        print(f"WARNING: output folder {out_dir} is inside OneDrive ({root}). Several GB of "
              f"extracted builds and Ghidra projects will be synced, file locks can break "
              f"extraction, and long paths can exceed Ghidra/BinDiff's limit. Use a short "
              f"folder outside OneDrive, e.g. --out C:\\pdiff\\run.", file=sys.stderr)


def _warn_db2_skipped_members(side_dir, side):
    """db2_bugs.md DB2-7: a fixpack member that could not be extracted (an unresolvable hard
    link, or a name this filesystem cannot create) is skipped instead of aborting the side,
    but then it is simply absent, and Stage 0 reports it as removed/added. Say so on every
    run that uses this tree, naming the list the extraction wrote."""
    path = Path(side_dir) / "skipped_members.txt"
    try:
        names = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    except OSError:
        return
    if names:
        print(f"WARNING: DB2 {side} build: {len(names)} fixpack member(s) could not be "
              f"extracted and are missing from this side (first: {names[0]}). A missing "
              f"file shows up in the diff as removed or added. Full list: {path}",
              file=sys.stderr)


# ---------------------------------------------------------------------------
# Incremental re-attribution (no binary re-analysis)
# ---------------------------------------------------------------------------

def _validate_cves_file(cves_path):
    """Refuse an unusable --cves file up front (bugs.md #17) instead of discovering it as
    silently-empty attribution after the whole binary analysis has run."""
    from patch_differ_cli import _attribution as _AT
    rows, problems = _AT.parse_cves_file(cves_path)
    if not rows:
        raise ValueError(f"--cves {cves_path}: no usable CVE records ("
                         + "; ".join(problems[:3] or ["file is empty"]) + ")")
    if problems:
        print(f"WARNING: --cves {cves_path}: skipping " + "; ".join(problems[:5]),
              file=sys.stderr)


def _reattribute_stage2(db, out_dir, cves_path, verbose):
    """Re-run CVE attribution on an existing stage2 result without repeating binary analysis.

    Reads <out_dir>/stage2/functions_diff.json, applies updated CVE data (from cves_path
    or the existing cves.json), then rewrites the file with fresh cve / cve_candidate /
    confidence / why fields.  All binary-analysis fields (fix_score, similarity, etc.)
    are unchanged.
    """
    from patch_differ_cli import _attribution as _AT

    result_path = out_dir / "stage2" / "functions_diff.json"
    if not result_path.exists():
        raise FileNotFoundError(
            f"No stage2 result at {result_path}.\n"
            "Run the full pipeline first, then use --reattribute to update CVE links."
        )

    if cves_path:
        _validate_cves_file(cves_path)
        shutil.copy2(cves_path, out_dir / "cves.json")

    def log(msg):
        if verbose:
            print(msg)

    log("\n[Re-attribution — updating CVE links on existing stage2 result]")
    result = json.loads(result_path.read_text(encoding="utf-8"))
    attrib = _AT.load_attrib(str(out_dir))
    readable = result.get("readable_files", [])
    # The cross-binary corroboration signal is derived purely from object names (no binary
    # analysis), so recompute it rather than trust a value saved by an older version with
    # the CRIT-NT-8 grouping bug. Oracle's fresh runs never mark cross-binary — leave it be.
    if db in ("mssql", "db2"):
        from patch_differ_cli import _results
        _results.refresh_cross_binary(readable)

    for r in readable:
        obj = r.get("object", "")
        name = obj.split(" :: ", 1)[-1].strip() if " :: " in obj else obj
        cve, why, name_conf = _AT.attribute(name, attrib)
        # corroboration signals from immutable binary-analysis fields
        corrob = (
            bool(r.get("intrinsic"))
            or (r.get("fix_score") or 0) > 0
            or bool(r.get("cross_binary"))
        )
        conf, asserted = _AT.resolve(name_conf, corrob)
        # Oracle's fresh stage1/stage2 path never asserts a family-only ("low") name
        # (oracle/stage1.py, oracle/stage2.py force asserted=False for low). Mirror that
        # here so --reattribute stays consistent with a fresh Oracle run. Other backends
        # keep resolve()'s outcome (their fresh paths do assert corroborated-low).
        if db == "oracle" and name_conf == "low":
            asserted = False
        r["cve"]           = cve if asserted else None
        r["cve_candidate"] = cve if (cve and not asserted) else None
        r["confidence"]    = conf
        r["why"]           = why

    def _rank(r):
        # Final element (object name) is a deterministic tie-breaker — without it, two
        # equally-ranked functions would keep whatever order they happened to be in when
        # this JSON was loaded, which depends on the original run's worker-pool completion
        # order (the same non-determinism fixed in mssql/db2 stage2.py's own _rank()).
        return (r.get("cve") is None, r.get("cve_candidate") is None,
                -(r.get("fix_score") or 0),
                r.get("change") in ("added", "removed"),
                r.get("similarity", 1.0),
                r.get("object", ""))

    readable.sort(key=_rank)
    result["readable_files"] = readable
    result.setdefault("counts", {})
    result["counts"]["attributed"] = sum(1 for r in readable if r.get("cve"))
    result["counts"]["candidates"] = sum(1 for r in readable if r.get("cve_candidate"))

    result_path.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                           encoding="utf-8")
    n_attr = result["counts"]["attributed"]
    n_cand = result["counts"]["candidates"]
    log(f"  Done — {len(readable)} functions re-attributed, "
        f"{n_attr} CVEs asserted, {n_cand} candidates")
    return {"stage2": result}


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_pipeline(db, vuln_dir=None, fixed_dir=None, out_dir=None,
                 stages=_ALL_STAGES, cves_path=None, verbose=True,
                 fixed_kb=None, vuln_kb=None, vuln_url=None, fixed_url=None,
                 vuln_label=None, fixed_label=None,
                 reattribute=False, use_bindiff=False, decompile=False,
                 bindiff_only=None, decompile_max=None):
    """Run the selected stages for one (vuln, fixed) pair.

    Args:
        db:          One of "mssql", "db2", "oracle".
        vuln_dir:    Path to the vulnerable (unpatched) build directory, or None to
                     use patches/<db>/vuln/ (auto-acquired if also empty).
        fixed_dir:   Path to the fixed (patched) build directory, or None to
                     use patches/<db>/fixed/ (auto-acquired if also empty).
        out_dir:     Output directory; created if absent. Stage JSON written here.
                     Acquired binaries land in <out_dir>/acquire/.
        stages:      Iterable of stage names to run (subset of triage/stage1/stage2).
        cves_path:   Optional path to a JSON file with CVE records for attribution.
                     Format: [{"cve_id": "CVE-...", "cve_desc": "...",
                               "component": "...", "cwe_id": "CWE-..."}]
        verbose:     Print progress to stdout.
        fixed_kb:    MSSQL: KB number of the fixed build (e.g. "5084815").
        vuln_kb:     MSSQL: KB number of the vulnerable build (e.g. "5029395").
        vuln_url:    DB2: acquisition URL for the vulnerable build
                     (e.g. "container:icr.io/db2_community/db2:12.1.5.0").
        fixed_url:   DB2: acquisition URL for the fixed build.
        use_bindiff: When True, Stage 2 uses BinDiff (CFG-based) function matching
                     instead of name-based LCS. Requires Ghidra BinExport extension
                     and the differ binary on PATH (or BINDIFF_PATH env var).
        decompile:   When True, decompile fix-scored / CVE-attributed functions to
                     pseudo-C via Ghidra headless (all three backends — MSSQL PE
                     functions, DB2's libdb2e.so, Oracle's native OJVM .o functions;
                     Oracle's file-level DBRU PE path has no function names to
                     decompile). Uses the bundled Ghidra/JDK (override: GHIDRA_HOME,
                     PATCHDIFF_JAVA_HOME). Results stored in
                     fn__*.detail.json as prior_c/fixed_c, and permanently as
                     standalone, never-deleted .c files. All three backends use one folder
                     per build:
                     stage2/decompiled_c_{vuln,fixed}_<version>/<binary>_<sha8>/<func>.c
                     (and the disassembly under disassembled_instructions_{vuln,fixed}_
                     <version>/, with the diffs in disassembled_instructions_<vuln>_vs_
                     <fixed>/). <version> is --*-label when given, else per backend: MSSQL
                     the KB / installer name / engine version; DB2 the acquisition URL tag;
                     Oracle the RU-zip file name; else "unversioned". Silently skipped if
                     Ghidra is absent.

    Returns:
        dict with keys "triage", "stage1", "stage2" (whichever were run),
        each containing the stage's result dict.
    """
    if db not in _BACKENDS:
        raise ValueError(f"Unknown db '{db}'. Choose from: {', '.join(_BACKENDS)}")
    bindiff_only, decompile_max = _check_budget_options(use_bindiff, decompile,
                                                        bindiff_only, decompile_max)
    from . import _results
    _results.max_func_bytes(1)            # refuse an unusable PATCHDIFF_MAX_FUNC_BYTES now
    if use_bindiff or decompile:
        # Refuse an unusable PATCHDIFF_GHIDRA_MAXMEM / PATCHDIFF_*_TIMEOUT now, rather than
        # have every binary fall back with the same error after a long extraction.
        from . import tool_paths as _tp, _bindiff as _bd
        _tp.ghidra_heap()
        for _step in ("import", "export", "differ"):
            _bd.step_timeout(_step)
        if decompile and not _tp.analyze_headless():
            # db2_bugs.md DB2-5: --decompile used to skip silently without Ghidra
            print("WARNING: --decompile was given but Ghidra was not found (set GHIDRA_HOME "
                  "or install the bundled copy, see docs/PREREQUISITES.md): no pseudo-C "
                  "will be produced.", file=sys.stderr)
        if use_bindiff and not _tp.analyze_headless():
            # bug.md DB2-T1-2: --use-bindiff without Ghidra used to give no early signal —
            # every binary would just fall back to name matching after extraction.
            print("WARNING: --use-bindiff was given but Ghidra was not found (set GHIDRA_HOME "
                  "or install the bundled copy, see docs/PREREQUISITES.md): BinDiff cannot "
                  "run, so every binary will fall back to name-based matching.",
                  file=sys.stderr)
    if out_dir is None:
        out_dir = default_out_dir(db)

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    _warn_if_synced(out_dir)

    # bugs.md #34: `stage not in stages` consumed a one-shot iterator while searching, so a
    # generator like iter(["stage1"]) ran nothing and returned an empty result. A plain
    # string (stages="triage") was also searched by SUBSTRING. Materialize once; reject
    # unknown names instead of silently skipping them.
    stages = frozenset((stages,) if isinstance(stages, str) else stages)
    unknown = sorted(stages - set(_ALL_STAGES))
    if unknown:
        raise ValueError(f"unknown stage(s) {unknown}; expected any of {list(_ALL_STAGES)}")

    if reattribute:
        return _reattribute_stage2(db, out_dir, cves_path, verbose)

    def log(msg):
        if verbose:
            print(msg)

    # Default vuln/fixed to patches/<db>/vuln and patches/<db>/fixed
    if vuln_dir is None:
        vuln_dir = _PATCHES_DIR / db / "vuln"
    if fixed_dir is None:
        fixed_dir = _PATCHES_DIR / db / "fixed"

    vuln_dir  = Path(vuln_dir)
    fixed_dir = Path(fixed_dir)

    # Auto-acquire ONLY the side(s) that are actually missing/empty. A side that already
    # has content (e.g. manually placed by the user) is never overwritten by a freshly
    # acquired directory — previously, if EITHER side was empty, BOTH sides were replaced
    # wholesale, silently discarding a populated directory the user had placed on the
    # other side and comparing unintended builds with no warning.
    need_vuln  = not _dir_has_content(vuln_dir)
    need_fixed = not _dir_has_content(fixed_dir)

    if db == "db2":
        # A side holding only a Fix Central fixpack archive is a manual drop: stage it and
        # acquire it through the same manual: path instead of diffing the archive file itself.
        for side, sdir in (("vuln", vuln_dir), ("fixed", fixed_dir)):
            if _db2_only_sidecars(sdir):
                # Only desktop.ini-style placeholders: an empty folder (DB2-25).
                if side == "vuln":
                    need_vuln = True
                else:
                    need_fixed = True
                continue
            archive = _db2_archive_only(sdir)
            if archive is None:
                continue
            url = vuln_url if side == "vuln" else fixed_url
            if not url:
                url = f"manual:{_db2_archive_label(archive)}"
            if url.startswith("manual:"):
                _stage_db2_archive(archive, out_dir, side)
                log(f"\n[DB2 {side}: found fixpack archive {archive.name} — extracting it]")
            else:
                log(f"\n[DB2 {side}: --{side}-url {url} given — ignoring archive "
                    f"{archive.name} in {sdir}]")
            if side == "vuln":
                need_vuln, vuln_url = True, url
            else:
                need_fixed, fixed_url = True, url

    if need_vuln or need_fixed:
        needed = tuple(s for s, need in (("vuln", need_vuln), ("fixed", need_fixed)) if need)
        if len(needed) == 2:
            log("\n[Auto-acquire — input directories are empty, downloading patch binaries]")
        else:
            log(f"\n[Auto-acquire — {needed[0]} input directory is empty, downloading its "
                "patch binary; the other side is kept exactly as supplied]")
        if db == "mssql":
            acquired = _acquire_mssql(out_dir, fixed_kb, vuln_kb, verbose, sides=needed)
        elif db == "db2":
            acquired = _acquire_db2(out_dir, vuln_url, fixed_url, verbose, sides=needed)
        elif db == "oracle":
            raise ValueError(
                "Oracle patches require manual download (login-gated, cannot be automated).\n"
                f"  Place the vulnerable RU zip contents in : {vuln_dir}\n"
                f"  Place the fixed RU zip contents in      : {fixed_dir}\n"
                "Then re-run."
            )
        if need_vuln:
            vuln_dir = Path(acquired["vuln"])
        if need_fixed:
            fixed_dir = Path(acquired["fixed"])

    if db == "mssql":
        # Manual placement: if the user dropped raw self-extracting patch installers
        # (.exe) instead of extracted engine files, extract them now via the same path
        # auto-acquire uses. Already-extracted engine dirs pass through unchanged. Only
        # applies to a side that was NOT just auto-acquired above (that side is already a
        # ready, extracted engine dir).
        supplied = {"vuln": None if need_vuln else vuln_dir,
                    "fixed": None if need_fixed else fixed_dir}
        if not need_vuln:
            vuln_dir = Path(_prepare_mssql_dir(vuln_dir, out_dir, "vuln", verbose))
        if not need_fixed:
            fixed_dir = Path(_prepare_mssql_dir(fixed_dir, out_dir, "fixed", verbose))

    vuln_dir  = str(vuln_dir)
    fixed_dir = str(fixed_dir)
    if db == "db2":
        _check_db2_roots(vuln_dir, fixed_dir, log)

    # Human labels identifying each side, used to name each build's per-version output
    # folders. An explicit --vuln-label / --fixed-label overrides the auto-derived label;
    # otherwise each backend derives one. Each backend's own run() falls back to plain
    # "vuln"/"fixed" (token "unversioned") when the label is still None.
    _cli_vuln_label, _cli_fixed_label = vuln_label, fixed_label
    vuln_label = fixed_label = None
    if db == "mssql":
        _vkb, _fkb = _normalize_kb(vuln_kb), _normalize_kb(fixed_kb)
        # Without a KB argument the build is named from its installer or engine version, so
        # each build's per-version output folders say which build they are.
        vuln_label  = (f"KB{_vkb}" if _vkb
                       else _mssql_version_label(supplied["vuln"], vuln_dir))
        fixed_label = (f"KB{_fkb}" if _fkb
                       else _mssql_version_label(supplied["fixed"], fixed_dir))
    elif db == "db2":
        # vuln_url/fixed_url look like "container:icr.io/db2_community/db2:12.1.5.0" or
        # "manual:v12.1.5.0" — use whatever follows the last ':' as the version tag.
        vuln_label  = vuln_url.rsplit(":", 1)[-1] if vuln_url else None
        fixed_label = fixed_url.rsplit(":", 1)[-1] if fixed_url else None
    elif db == "oracle":
        # ORA-T1-2: Oracle has no acquisition parameter, so derive a version from the RU
        # patch zip the user placed in the input dir (its file name), else None.
        vuln_label  = _oracle_zip_label(vuln_dir)
        fixed_label = _oracle_zip_label(fixed_dir)
    # An explicit CLI label always wins.
    vuln_label = _cli_vuln_label or vuln_label
    fixed_label = _cli_fixed_label or fixed_label

    # Copy CVE JSON into workdir so _attribution.load_attrib() finds it
    if cves_path:
        _validate_cves_file(cves_path)
        shutil.copy2(cves_path, out_dir / "cves.json")

    backend = _BACKENDS[db]
    results = {}
    stage0_result = None

    # bugs.md #43: a later stage run without triage used to analyze whatever
    # stage0/changed_files.json was in out_dir — possibly written for a different input
    # pair (an empty one silently meant "nothing changed"). Unless that result was produced
    # by triage of exactly these inputs, run triage first.
    if "triage" not in stages and stages & {"stage1", "stage2"}:
        if not _rs.stage0_is_current(out_dir, vuln_dir, fixed_dir):
            log("\n[Stage 0] no triage result for these inputs in the output dir "
                "— running triage first")
            stages = stages | {"triage"}

    for stage in _ALL_STAGES:
        if stage not in stages:
            continue

        if stage == "triage":
            log(f"\n[Stage 0 — triage]")
            mod = _import(backend["triage"])
            t0 = time.time()
            progress = _progress_printer("triage") if verbose else None
            result = mod.run(vuln_dir, fixed_dir, str(out_dir), progress=progress)
            stage0_result = result
            results["triage"] = result
            _rs.set_stage_state(out_dir, "triage",
                             _rs.comparison_identity(out_dir, vuln_dir, fixed_dir))   # #37
            elapsed = time.time() - t0
            counts = result.get("counts", {})
            log(f"  Done in {elapsed:.1f}s — "
                f"{counts.get('code_changed', 0)} code-changed, "
                f"{counts.get('content_changed', 0)} content-changed, "
                f"{counts.get('identical', 0)} identical"
                + (f" — WARNING: {counts['errors']} file(s) could not be analyzed"
                   if counts.get("errors") else ""))
            _warn_unsymbolized(result)

        elif stage == "stage1":
            log(f"\n[Stage 1 — readable diff]")
            mod = _import(backend["stage1"])
            t0 = time.time()
            progress = _progress_printer("stage1") if verbose else None
            identity = _stage_identity(out_dir, vuln_dir, fixed_dir, "triage" in results)
            _rs.set_stage_state(out_dir, "stage1", forget=True)       # #37
            result = mod.run(vuln_dir, fixed_dir, str(out_dir),
                             stage0=stage0_result, progress=progress)
            results["stage1"] = result
            _rs.set_stage_state(out_dir, "stage1", identity)
            elapsed = time.time() - t0
            n = len(result.get("readable_files", []))
            n_errs = result.get("counts", {}).get("errors", 0)
            if result.get("available") is False:
                # The whole stage reported itself unavailable — zero readable items here
                # is NOT a verified "nothing to report", so say so explicitly rather than
                # printing the same "0 readable items" a genuine empty result would show.
                # (A stage that ran but skipped one part — e.g. mssql Stage 1 without the
                # resource DB — reports "unavailable_parts" instead; logged below.)
                log(f"  Done in {elapsed:.1f}s — UNAVAILABLE: "
                    f"{result.get('reason') or 'no reason given'}")
            else:
                log(f"  Done in {elapsed:.1f}s — {n} readable items"
                    + (f" — WARNING: {n_errs} file(s) could not be analyzed" if n_errs else ""))
                for part in result.get("unavailable_parts") or []:
                    log(f"  PARTIAL: {part.get('part', 'part of stage')} not diffed — "
                        f"{part.get('reason') or 'no reason given'}")

        elif stage == "stage2":
            log(f"\n[Stage 2 — binary/function diff]")
            mod = _import(backend["stage2"])
            t0 = time.time()
            progress = _progress_printer("stage2") if verbose else None
            # vuln_label/fixed_label (the permanent-copy naming) and decompile (pseudo-C)
            # are now accepted by all three backends' stage2.run().
            stage2_kwargs = {"stage0": stage0_result, "progress": progress,
                             "use_bindiff": use_bindiff, "decompile": decompile,
                             "vuln_label": vuln_label, "fixed_label": fixed_label,
                             "bindiff_only": bindiff_only, "decompile_max": decompile_max}
            identity = _stage_identity(out_dir, vuln_dir, fixed_dir, "triage" in results)
            _rs.set_stage_state(out_dir, "stage2", forget=True)       # #37
            from . import tool_paths as _tp
            # db2_bugs.md DB2-19: Ghidra's compiled-script cache is checked (and cleared after
            # a JDK change) once here, before any worker starts, not by every worker.
            with _tp.ghidra_script_cache_checked(use_bindiff or decompile):
                result = mod.run(vuln_dir, fixed_dir, str(out_dir), **stage2_kwargs)
            results["stage2"] = result
            _rs.set_stage_state(out_dir, "stage2", identity)
            elapsed = time.time() - t0
            n = len(result.get("readable_files", []))
            attributed = sum(1 for r in result.get("readable_files", [])
                             if r.get("cve") or r.get("cve_candidate"))
            n_failed = result.get("counts", {}).get("failed", 0)
            n_skipped = result.get("counts", {}).get("functions_skipped", 0)
            n_bd = result.get("counts", {}).get("bindiff_fallbacks", 0)
            n_cap = result.get("counts", {}).get("functions_capped", 0)
            log(f"  Done in {elapsed:.1f}s — {n} functions, {attributed} attributed"
                + (f" — {n_cap} ordinary changed function(s) over the card limit not written"
                   if n_cap else "")
                + (f" — WARNING: {n_failed} binary(ies) could not be analyzed"
                   if n_failed else "")
                + (f" — WARNING: {n_skipped} changed function(s) too large to diff"
                   if n_skipped else "")
                + (f" — WARNING: {n_bd} binary(ies) fell back from BinDiff to name matching"
                   if n_bd else ""))

    return results


# bugs.md #37/#43: which comparison each persisted stage result belongs to — see
# _result_state.py. This module calls _rs.* directly; the aliases are for outside callers.
_STATE_FILE = _rs.STATE_FILE
_stage0_digest = _rs.stage0_digest
_comparison_identity = _rs.comparison_identity
_read_state = _rs.read_state
_set_stage_state = _rs.set_stage_state


def _stage_identity(out_dir, vuln_dir, fixed_dir, triage_ran):
    """The comparison identity a stage1/stage2 run is computed against: this invocation's
    triage (just recorded) or, when triage didn't run, the inputs + stage0 on disk now."""
    if triage_ran:
        rec = (_rs.read_state(out_dir) or {}).get("triage")
        if isinstance(rec, dict) and rec.get("identity"):
            return rec["identity"]
    return _rs.comparison_identity(out_dir, vuln_dir, fixed_dir)


def load_result(out_dir, stale=None):
    """Read persisted stage JSON files from a completed run.

    A stage1/stage2 result that wasn't computed from the CURRENT triage result (#37) is
    left out; when `stale` is a list, (stage, reason) is appended to it for each one.
    An output dir with no result-state record (written by an older version) is read as-is."""
    out = Path(out_dir)
    state = _rs.read_state(out)
    triage = (state or {}).get("triage")
    current = triage.get("identity") if isinstance(triage, dict) else None
    result = {}
    for stage, fname in [("triage", "stage0/changed_files.json"),
                         ("stage1", "stage1/modules_diff.json"),
                         ("stage2", "stage2/functions_diff.json")]:
        p = out / fname
        if not p.exists():
            continue
        if stage != "triage" and state is not None:
            rec = state.get(stage)
            if not (current and isinstance(rec, dict) and rec.get("identity") == current):
                if stale is not None:
                    stale.append((stage, "it belongs to an earlier comparison (triage was "
                                         "re-run, or the inputs changed, without this stage)"))
                continue
        result[stage] = json.loads(p.read_text(encoding="utf-8"))
    return result