r"""Safe zip extraction for uploaded Oracle patch archives.

Vendored/trimmed from ora-cve-rca `ocrca/vendor/extract.py`. Extracts ONE uploaded
zip into a destination dir with the guards that matter for user-supplied archives:
zip-slip (absolute / `..` members), zip-bomb (absurd compression ratio), a disk-space
+ total-byte budget, and Windows `\\?\` long-path handling (Oracle patch trees nest
deep past MAX_PATH). No recursive nested-archive expansion (we only need the top zip).
"""
import os
import shutil
import zipfile

from ..db2._paths import lp   # shared \\?\ long-path helper

_BOMB_RATIO = 200
_BOMB_MIN_COMPRESSED = 4096
_MARGIN = 0.20                 # keep this much headroom over the uncompressed size


class ExtractError(Exception):
    pass


def _human(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}"
        n /= 1024.0


def _uncompressed_size(zf):
    total = 0
    for zi in zf.infolist():
        if zi.is_dir():
            continue
        total += zi.file_size
        ratio = zi.file_size / max(zi.compress_size, 1)
        if zi.compress_size >= _BOMB_MIN_COMPRESSED and zi.file_size and ratio > _BOMB_RATIO:
            raise ExtractError(f"Refusing suspicious archive member {zi.filename!r}: "
                               f"compression ratio {ratio:.0f}x looks like a zip bomb.")
    return total


def _safe_target(dest_dir, member_name):
    name = member_name.replace("\\", "/")
    if name.startswith("/") or (len(name) > 1 and name[1] == ":"):
        return None
    target = os.path.normpath(os.path.join(dest_dir, name))
    base = os.path.normpath(dest_dir)
    try:
        if os.path.commonpath([base, target]) != base:
            return None
    except ValueError:
        return None
    return target


def zip_index(zip_path):
    """{member_name: (crc32, uncompressed_size)} read from the central directory only — NO
    decompression. Lets us compare two patch zips member-for-member and extract just the
    differing ones. CRC-32 is over the *uncompressed* content, so it's robust to re-compression."""
    out = {}
    with zipfile.ZipFile(lp(zip_path)) as zf:
        for zi in zf.infolist():
            if zi.is_dir():
                continue
            out[zi.filename.replace("\\", "/")] = (zi.CRC, zi.file_size)
    return out


def extract_members(zip_path, names, dest_dir, progress=None):
    """Extract only `names` (a set of member names) from the zip into dest_dir. Returns the
    count written. Same zip-slip guard as extract_zip."""
    names = set(names)
    written = 0
    with zipfile.ZipFile(lp(zip_path)) as zf:
        os.makedirs(lp(dest_dir), exist_ok=True)
        members = [zi for zi in zf.infolist()
                   if not zi.is_dir() and zi.filename.replace("\\", "/") in names]
        total = len(members) or 1
        for zi in members:
            target = _safe_target(dest_dir, zi.filename)
            if target is None:
                raise ExtractError(f"Refusing unsafe path (zip-slip): {zi.filename!r}")
            os.makedirs(lp(os.path.dirname(target)), exist_ok=True)
            with zf.open(zi) as src, open(lp(target), "wb") as dst:
                shutil.copyfileobj(src, dst, length=1 << 20)
            written += 1
            if progress and (written % 200 == 0 or written == total):
                progress(int(100 * written / total), f"Extracting changed members {written}/{total}")
    return written


def extract_zip(zip_path, dest_dir, progress=None):
    """Extract `zip_path` into `dest_dir`. Idempotent-friendly (caller decides whether to
    skip); returns the number of files written. Raises ExtractError on unsafe/oversized."""
    with zipfile.ZipFile(lp(zip_path)) as zf:
        need = _uncompressed_size(zf)
        os.makedirs(lp(dest_dir), exist_ok=True)
        free = shutil.disk_usage(lp(dest_dir)).free
        if free < need * (1 + _MARGIN):
            raise ExtractError(f"Not enough disk space: need ~{_human(need * (1 + _MARGIN))}, "
                               f"only {_human(free)} free.")
        members = [zi for zi in zf.infolist() if not zi.is_dir()]
        total, done = len(members) or 1, 0
        for zi in members:
            target = _safe_target(dest_dir, zi.filename)
            if target is None:
                raise ExtractError(f"Refusing unsafe path (zip-slip): {zi.filename!r}")
            os.makedirs(lp(os.path.dirname(target)), exist_ok=True)
            with zf.open(zi) as src, open(lp(target), "wb") as dst:
                shutil.copyfileobj(src, dst, length=1 << 20)
            done += 1
            if progress and (done % 500 == 0 or done == total):
                progress(int(100 * done / total), f"Extracting {done}/{total} files")
        return done