"""Decompile Java classes to readable source for OJVM Stage 1.

A RAW Oracle OJVM patch ships compiled classes inside jars (aurora.zip, jce.jar, …). To
diff the actual fix we decompile a whole jar to `.java` with CFR (bundled JDK-17 runs it),
falling back to the JDK's `javap -c -p` bytecode listing if the CFR jar is absent. Output
mirrors the package tree, so two RUs' decompiled trees compare file-for-file.

CFR jar and java: resolved centrally in tool_paths.py (see that module's docstring).
"""
import os
import subprocess
import zipfile

from ..db2._paths import lp
from .. import tool_paths as tp

_TIMEOUT = 900


def _java():
    return tp.java_exe()


def _cfr_jar():
    return tp.cfr_jar()


def available():
    # True when the Java runtime that drives CFR/javap is present. (Currently unused by the
    # pipeline — Java decompile is attempted unconditionally with a graceful fallback — but
    # kept as an honest capability probe rather than an always-True stub.)
    return os.path.isfile(_java() if os.name != "nt" else lp(_java()))


def identity():
    """Which decompiler (and which build of it) produces output — part of the Stage 1 cache
    key, so swapping CFR versions or falling back to javap doesn't reuse other output."""
    # bugs.md #39: CFR used to be identified by name + byte size only, so a same-size CFR
    # replacement (or a JDK change, which also drives javap) kept serving the old output.
    # Both are now identified by content.
    java = tp.content_identity(tp.java_identity_files())
    cfr = _cfr_jar()
    if cfr:
        return {"tool": "cfr", "name": os.path.basename(cfr),
                "content": tp.content_identity([cfr]), "java": java}
    return {"tool": "javap", "java": java}


class DecompileFailed(RuntimeError):
    """The decompiler failed for a jar (bad exit, timeout, launch failure, or no output)."""


def decompile_jar(jar_path, out_dir, progress=None):
    """Decompile every class in `jar_path` to `.java` under `out_dir` (created). Returns the
    number of .java files produced. Uses CFR if available, else javap.

    Raises DecompileFailed when the tool fails (bugs.md #10): CFR's exit status used to be
    ignored and its output discarded, so a failed run returned 0, Stage 1 indexed an empty
    directory, and the changed jar silently produced no results and no error. Partial
    output from a failed run is NOT trusted either — comparing an incomplete class set
    against a complete one would invent added/removed classes."""
    os.makedirs(lp(out_dir), exist_ok=True)
    cfr = _cfr_jar()
    env = dict(os.environ)
    try:
        if cfr:
            # CFR decompiles the whole archive in one JVM run.
            proc = subprocess.run([_java(), "-jar", cfr, jar_path, "--outputdir", out_dir,
                                   "--silent", "true", "--comments", "false"],
                                  env=env, timeout=_TIMEOUT, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.PIPE)
            if proc.returncode != 0:
                tail = (proc.stderr or b"").decode("utf-8", "replace").strip()[-300:]
                raise DecompileFailed(f"CFR exited {proc.returncode} for "
                                      f"{os.path.basename(jar_path)}" + (f": {tail}" if tail else ""))
        else:
            _javap_jar(jar_path, out_dir, env)
    except subprocess.TimeoutExpired:
        raise DecompileFailed(f"decompiler timed out after {_TIMEOUT}s on "
                              f"{os.path.basename(jar_path)}") from None
    except (FileNotFoundError, OSError, zipfile.BadZipFile) as exc:
        if isinstance(exc, DecompileFailed):
            raise
        raise DecompileFailed(f"decompiler could not run on {os.path.basename(jar_path)}: "
                              f"{exc}") from exc
    n = 0
    for _dp, _dn, files in os.walk(lp(out_dir)):
        n += sum(1 for f in files if f.endswith(".java"))
    if n == 0:
        raise DecompileFailed(f"decompiler produced no source for {os.path.basename(jar_path)}")
    return n


def _javap_jar(jar_path, out_dir, env):
    """Fallback: expand the jar and `javap -c -p` each class into a .javap listing.
    Raises DecompileFailed if any class fails — a partial listing would make the classes
    javap choked on look removed/added in the comparison."""
    import zipfile
    jp = os.path.join(os.path.dirname(_java()), "javap.exe" if os.name == "nt" else "javap")
    with zipfile.ZipFile(lp(jar_path)) as zf:
        classes = [zi.filename for zi in zf.infolist() if zi.filename.endswith(".class")]
        cdir = os.path.join(out_dir, "_classes")
        for zi in classes:
            zf.extract(zi, lp(cdir))
    _cdir_lp = lp(os.path.join(out_dir, "_classes"))
    failed = []
    for root, _dn, files in os.walk(_cdir_lp):
        for f in files:
            if not f.endswith(".class"):
                continue
            cf = os.path.join(root, f)
            # JD-1: javap subprocess cannot handle the \\?\ long-path prefix.
            # JD-2: relpath(lp_path, plain_path) produces a wrong result on Windows
            #        because the drive labels differ (\\?\C: vs C:). Use the lp base
            #        for relpath so both sides share the same prefix.
            rel = os.path.relpath(cf, _cdir_lp)
            dst = os.path.join(out_dir, rel[:-len(".class")] + ".java")
            cf_plain = cf[4:] if cf.startswith("\\\\?\\") else cf
            try:
                proc = subprocess.run([jp, "-c", "-p", cf_plain], env=env, timeout=120,
                                      stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            except Exception as exc:
                failed.append(f"{rel}: {exc}")
                continue
            if proc.returncode != 0 or not proc.stdout:
                failed.append(f"{rel}: javap exited {proc.returncode}")
                continue
            os.makedirs(lp(os.path.dirname(dst)), exist_ok=True)
            with open(lp(dst), "wb") as fh:
                fh.write(proc.stdout)
    if failed:
        raise DecompileFailed(f"javap failed on {len(failed)} class(es) in "
                              f"{os.path.basename(jar_path)}: " + "; ".join(failed[:3]))
