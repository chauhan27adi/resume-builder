"""Oracle version / patch-type helpers.

Version-tuple parsing is adapted from ora-cve-rca `ocrca/vendor/rollback.py`. The
quarter->RU mapping lets the listing show the 19c Release Update for each Critical
Patch Update quarter (Jan/Apr/Jul/Oct). Oracle CPUs fix multiple streams (19c/21c/23ai);
we headline the 19c RU (the common stream, and the user's data) — the actual analysis
uses the versions of whatever patch zips get uploaded, so this is only a listing guide.
"""
import re

_VER_RE = re.compile(r"(\d+)")
# Per-stream RU model: each Release Update increments +1 per CPU quarter from a base.
#   stream -> (anchor_year, anchor_month, base_ru)
# 19c: 19.3 @ 2019-04 (accurate). 21c: 21.3 @ 2021-08 (accurate). 23ai: 23.4 @ 2024-07
# (best-effort — 23ai RU numbering is less regular; the uploaded patch's real version is
# authoritative, this only labels the listing).
_ANCHORS = {19: (2019, 4, 3), 21: (2021, 8, 3), 23: (2024, 7, 4)}


def parse_version_tuple(v):
    return tuple(int(x) for x in _VER_RE.findall(v or ""))


def _total_q(year, month):
    return year * 4 + (month - 1) // 3


def ru_for_quarter(yyyy_mm, stream):
    """(fixed_ru, prior_ru) e.g. ('19.25','19.24') / ('21.23','21.22') for a CPU quarter
    'YYYY-MM' and a stream (19/21/23), or (None, None)."""
    m = re.match(r"(\d{4})-(\d{2})", yyyy_mm or "")
    if not m or stream not in _ANCHORS:
        return None, None
    ay, am, base = _ANCHORS[stream]
    ru = base + _total_q(int(m.group(1)), int(m.group(2))) - _total_q(ay, am)
    if ru < base:
        return None, None
    prior = ru - 1 if ru - 1 >= base else None
    return f"{stream}.{ru}", (f"{stream}.{prior}" if prior else None)


_CPU_MONTHS_SORTED = (1, 4, 7, 10)


def cpu_quarter(yyyy_mm):
    """Map a CVE's publish 'YYYY-MM' to the Critical Patch Update quarter that ships its fix.
    On-cycle months (Jan/Apr/Jul/Oct) map to themselves; an OUT-OF-CYCLE month rounds UP to
    the next CPU — an out-of-band Oracle security alert (e.g. published in August) is fixed in
    the upcoming Release Update, not the previous quarter's. Without this, Aug/2026 fell into
    the Jul quarter and mislabelled the fix as the prior RU (19.32 instead of 19.33), merging
    the new CVEs into the old row instead of creating 19.33 / 21.24 / 23.13."""
    m = re.match(r"(\d{4})-(\d{2})", yyyy_mm or "")
    if not m:
        return yyyy_mm
    y, mo = int(m.group(1)), int(m.group(2))
    for c in _CPU_MONTHS_SORTED:
        if mo <= c:
            return f"{y}-{c:02d}"
    return f"{y + 1}-01"   # Nov/Dec -> next January CPU


_STREAM_RE = re.compile(r"\b(19|21|23)\.\d")


def streams_in(affected_versions):
    """The Oracle DB streams a CVE's affected-version string touches (19/21/23). Defaults to
    {19} when nothing parseable (keeps a row for the common stream)."""
    s = {int(m.group(1)) for m in _STREAM_RE.finditer(affected_versions or "")}
    return s or {19}


_CPU_MONTHS = {1: "Jan", 4: "Apr", 7: "Jul", 10: "Oct"}


def quarter_label(yyyy_mm):
    """'2024-10' -> 'Oct 2024 CPU' (nearest CPU month)."""
    m = re.match(r"(\d{4})-(\d{2})", yyyy_mm or "")
    if not m:
        return yyyy_mm or ""
    y, mo = int(m.group(1)), int(m.group(2))
    cpu_mo = min(_CPU_MONTHS, key=lambda c: abs(c - mo))
    return f"{_CPU_MONTHS[cpu_mo]} {y} CPU"


_OJVM_RE = re.compile(r"java\s*vm|ojvm|jdk in|javavm", re.I)


def is_ojvm_component(component):
    """True if a CVE's component indicates the in-database Java VM (OJVM patch) rather
    than the RDBMS engine (DBRU patch)."""
    return bool(_OJVM_RE.search(component or ""))


def patch_type_of(component):
    return "ojvm" if is_ojvm_component(component) else "dbru"