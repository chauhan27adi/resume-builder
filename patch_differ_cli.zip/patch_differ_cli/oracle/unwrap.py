"""Oracle 10g+ PL/SQL unwrapper — vendored from ora-cve-rca `ocrca/vendor/unwrap.py`.

Oracle ships most PL/SQL packages WRAPPED (`.plb`): the source is obfuscated as a
base64 lump. Unwrap per unit: locate the base64 lump -> base64 decode -> drop the
first 20 bytes (SHA1) -> fixed-table byte substitution -> zlib inflate -> latin-1 text.
The base64 start line is auto-located by trying candidates until zlib succeeds.

Used by Stage 1 to turn `.plb` into readable PL/SQL so the vuln->fixed diff shows the
actual code change (where most Oracle DB CVE fixes live).
"""
import base64
import hashlib
import re
import zlib

_CHARMAP = [
    0x3d, 0x65, 0x85, 0xb3, 0x18, 0xdb, 0xe2, 0x87, 0xf1, 0x52, 0xab, 0x63, 0x4b, 0xb5, 0xa0, 0x5f,
    0x7d, 0x68, 0x7b, 0x9b, 0x24, 0xc2, 0x28, 0x67, 0x8a, 0xde, 0xa4, 0x26, 0x1e, 0x03, 0xeb, 0x17,
    0x6f, 0x34, 0x3e, 0x7a, 0x3f, 0xd2, 0xa9, 0x6a, 0x0f, 0xe9, 0x35, 0x56, 0x1f, 0xb1, 0x4d, 0x10,
    0x78, 0xd9, 0x75, 0xf6, 0xbc, 0x41, 0x04, 0x81, 0x61, 0x06, 0xf9, 0xad, 0xd6, 0xd5, 0x29, 0x7e,
    0x86, 0x9e, 0x79, 0xe5, 0x05, 0xba, 0x84, 0xcc, 0x6e, 0x27, 0x8e, 0xb0, 0x5d, 0xa8, 0xf3, 0x9f,
    0xd0, 0xa2, 0x71, 0xb8, 0x58, 0xdd, 0x2c, 0x38, 0x99, 0x4c, 0x48, 0x07, 0x55, 0xe4, 0x53, 0x8c,
    0x46, 0xb6, 0x2d, 0xa5, 0xaf, 0x32, 0x22, 0x40, 0xdc, 0x50, 0xc3, 0xa1, 0x25, 0x8b, 0x9c, 0x16,
    0x60, 0x5c, 0xcf, 0xfd, 0x0c, 0x98, 0x1c, 0xd4, 0x37, 0x6d, 0x3c, 0x3a, 0x30, 0xe8, 0x6c, 0x31,
    0x47, 0xf5, 0x33, 0xda, 0x43, 0xc8, 0xe3, 0x5e, 0x19, 0x94, 0xec, 0xe6, 0xa3, 0x95, 0x14, 0xe0,
    0x9d, 0x64, 0xfa, 0x59, 0x15, 0xc5, 0x2f, 0xca, 0xbb, 0x0b, 0xdf, 0xf2, 0x97, 0xbf, 0x0a, 0x76,
    0xb4, 0x49, 0x44, 0x5a, 0x1d, 0xf0, 0x00, 0x96, 0x21, 0x80, 0x7f, 0x1a, 0x82, 0x39, 0x4f, 0xc1,
    0xa7, 0xd7, 0x0d, 0xd1, 0xd8, 0xff, 0x13, 0x93, 0x70, 0xee, 0x5b, 0xef, 0xbe, 0x09, 0xb9, 0x77,
    0x72, 0xe7, 0xb2, 0x54, 0xb7, 0x2a, 0xc7, 0x73, 0x90, 0x66, 0x20, 0x0e, 0x51, 0xed, 0xf8, 0x7c,
    0x8f, 0x2e, 0xf4, 0x12, 0xc6, 0x2b, 0x83, 0xcd, 0xac, 0xcb, 0x3b, 0xc4, 0x4e, 0xc0, 0x69, 0x36,
    0x62, 0x02, 0xae, 0x88, 0xfc, 0xaa, 0x42, 0x08, 0xa6, 0x45, 0x57, 0xd3, 0x9a, 0xbd, 0xe1, 0x23,
    0x8d, 0x92, 0x4a, 0x11, 0x89, 0x74, 0x6b, 0x91, 0xfb, 0xfe, 0xc9, 0x01, 0xea, 0x1b, 0xf7, 0xce]
_TRANS = bytes(_CHARMAP)

# MULTILINE is essential: the `wrapped` keyword sits at the END of a CREATE line mid-file,
# so `$` must match per-line, not only at end-of-text (else nothing is ever unwrapped).
_WRAPPED_RE = re.compile(r"\bwrapped\s*$", re.IGNORECASE | re.MULTILINE)
_CREATE_RE = re.compile(r"^\s*CREATE\s+OR\s+REPLACE", re.IGNORECASE)


def is_wrapped(text):
    return bool(_WRAPPED_RE.search(text or ""))


def unwrap_lump(lines):
    """lines: the text lines of one wrapped unit (after the `wrapped` keyword).
    Returns decoded source text, or None if it can't be unwrapped."""
    lines = [l for l in lines if l.strip() not in ("/", "")]
    n = len(lines)
    for start in range(min(n, 64)):
        blob = re.sub(r"[^A-Za-z0-9+/=]", "", "".join(lines[start:]))
        if len(blob) % 4 == 1:
            blob = blob[:len(blob) - 1]
        if len(blob) < 40:
            continue
        pad = len(blob) % 4
        b = blob + ("=" * (4 - pad) if pad else "")
        try:
            raw = base64.b64decode(b)
        except Exception:
            continue
        if len(raw) < 40:
            continue
        for candidate in (raw[20:].translate(_TRANS), raw.translate(_TRANS)):
            try:
                d = zlib.decompressobj()
                out = d.decompress(candidate) + d.flush()
                if len(out) > 20:
                    return out.decode("latin-1")
            except Exception:
                continue
    return None


def unwrap_text(text, failures=None):
    """Return `text` with every wrapped unit replaced by its unwrapped source. Units that
    can't be unwrapped are left as a one-line marker so the diff still lines up. If nothing
    is wrapped, returns the text unchanged.

    bugs.md #50: the marker used to be the same constant for every failed unit, so a unit
    whose wrapped payload changed but couldn't be decoded on either side compared equal and
    the change vanished. The marker now carries a digest of the wrapped payload (two
    different payloads -> two different lines), and when `failures` is a list each failed
    unit's (header, digest) is appended to it so the caller can report it."""
    if not is_wrapped(text):
        return text
    lines = text.split("\n")
    out, i = [], 0
    while i < len(lines):
        if _WRAPPED_RE.search(lines[i]):
            hdr = lines[i]
            j = i + 1
            body = []
            while j < len(lines) and not _CREATE_RE.search(lines[j]):
                body.append(lines[j])
                j += 1
            # The unit's payload ends at its "/" terminator line. What follows it before the
            # next CREATE (GRANTs, comments, other statements) is NOT part of the unit and
            # is kept verbatim — it used to be swallowed with the unit, so a changed
            # GRANT/REVOKE after a wrapped package vanished from the diff.
            end = next((k + 1 for k, l in enumerate(body) if l.strip() == "/"), len(body))
            payload, tail = body[:end], body[end:]
            src = unwrap_lump(body)
            out.append(hdr.rstrip())
            if src:
                out.append(src)
            else:
                digest = hashlib.sha256("\n".join(l.rstrip() for l in payload)
                                        .encode("utf-8", "replace")).hexdigest()[:16]
                out.append(f"-- [unwrap failed: wrapped payload sha256:{digest}]")
                if failures is not None:
                    failures.append((hdr.strip(), digest))
            out.extend(tail)
            i = j
        else:
            out.append(lines[i])
            i += 1
    return "\n".join(out)