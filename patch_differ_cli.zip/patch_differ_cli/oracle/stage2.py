"""Stage 2 — binary change analysis for Oracle.

Three shapes, by what the patch actually contains:
  * DBRU Windows PE (`.dll/.exe`)  -> file-level `.text`-section verdict (no PDBs -> no fn names).
  * OJVM native, RAW               -> `.o` (or `.a` of `.o`, ELF w/ .symtab): symbol-based
                                      capstone FUNCTION diff (reuse the DB2 ELF machinery +
                                      shared x86 normalization) — "compared like a binary".
  * OJVM native, pre-processed     -> objdump `.o.asm` text: normalize away address churn, compare.

Native function diffs are emitted as `readable_files` cards (with .asm.diff for the
normalized-instruction diff and .detail.json for /split, plus prior_c/fixed_c pseudo-C
when --decompile is used on a matched, non-added/removed OJVM .o function pair);
file-level results as a `binaries` table. Output: `<workdir>/stage2/functions_diff.json`.
Permanent per-version copies also land under a per-build layout (shared with MSSQL/DB2, see
_layout.py): each build's plain disassembly in
`disassembled_instructions_<build>_<version>/<object>_<sha8>/<func>.asm` and, with
--decompile, its pseudo-C in `decompiled_c_<build>_<version>/<object>_<sha8>/<func>.c`, while
the assembly diffs (which compare the two builds) go to
`disassembled_instructions_<vuln>_vs_<fixed>/` — never cleaned up, see `run()`.
"""
import bisect
import difflib
import json
import os
import re
import tempfile
import time
from collections import Counter

from ..db2._paths import lp, safe_name
from ..mssql.triage import _code_sig    # PE executable-section hashes; None if not a PE
from ..db2.stage2 import _func_map as _elf_func_map_text   # single-.text parser (linked images)
from ..db2.stage2 import _make_name_at, _dedupe_func_names, reconcile_dup_names, _oversized_entry
from .. import _results
from .. import _layout
from .. import _x86diff as X
from .. import _attribution as _AT
from .. import _result_state as _rs
from .._decompile import decompile_cached, decompile_allowed
from .._decompile import failure_record as _dc_failure_record
from . import _ar


# A direct PLT call relocation (R_X86_64_PLT32) is always a call, whatever the symbol's type;
# other relocations are treated as function references only when their target symbol is itself
# a function. bug.md ORA-T2-1 / ORA-T2-2.
_R_X86_64_PLT32 = 4


def _reloc_func_refs_by_shndx(elf, sections):
    """{section_index: ([sorted r_offsets], [(r_offset, callee_name) sorted by offset])} for
    every .rela.<code-section>: the FUNCTION callees that each code section references through
    relocations. ET_REL `.o` files leave inter-unit call/ref operands as placeholder bytes with
    the real target in .rela.text* (see _func_map's note), so this is the only place the real
    callee name is visible. Best-effort: any parse problem yields {} and the caller degrades to
    the previous no-relocation behaviour. A reference counts as a function ref when its target
    symbol is a function (STT_FUNC / STT_GNU_IFUNC — covers defined and undefined callees) or
    the relocation is a direct PLT call."""
    out = {}
    try:
        from elftools.elf.relocation import RelocationSection
    except Exception:
        return out
    try:
        for sec in sections:
            if not isinstance(sec, RelocationSection) or not sec.is_RELA():
                continue
            tgt = sec["sh_info"]                       # the code section these relocs patch
            if not isinstance(tgt, int) or tgt >= len(sections):
                continue
            if not (sections[tgt].name or "").startswith(".text"):
                continue
            lsym = elf.get_section(sec["sh_link"])
            if lsym is None:
                continue
            refs = []
            for r in sec.iter_relocations():
                s = lsym.get_symbol(r["r_info_sym"])
                nm = s.name
                if not nm:
                    continue
                if (s["st_info"]["type"] in ("STT_FUNC", "STT_GNU_IFUNC")
                        or r["r_info_type"] == _R_X86_64_PLT32):
                    refs.append((r["r_offset"], nm))
            refs.sort(key=lambda t: t[0])
            out[tgt] = ([o for o, _ in refs], refs)
    except Exception:
        return {}
    return out


def _reloc_refs_note(refs, c):
    """Prefix ET_REL pseudo-C with the function's relocated function references — the callees an
    unlinked `.o` hides behind relocations (bug.md ORA-T2-1) — so a reviewer sees the callee SET,
    and its prior-vs-fixed delta, even though the inline calls themselves stay placeholders. A
    no-op when there are no refs or the side produced no C (so an empty/failed side stays empty,
    exactly like mssql's _partial_c_note). Names are stable symbols, so this never manufactures a
    difference that is not a real callee change."""
    if not (refs and c):
        return c
    shown = ", ".join(refs[:24]) + (", …" if len(refs) > 24 else "")
    return (f"// relocated function refs ({len(refs)}): {shown}\n"
            f"// (ET_REL callees live in .rela.text*; the inline calls below stay placeholders)\n"
            + c)


def _added_security_intrinsics(md, pv, pc, fv, fc, name_at_P, name_at_F, prior_refs, fixed_refs):
    """Security-intrinsic callees the fix ADDED to one function. Unions two sources: directly
    resolvable rel32 targets baked into the bytes (X.call_targets — the only ones visible in a
    linked image) and ET_REL relocation targets (prior_refs/fixed_refs from fm.calls), which
    carry the real callee names the unlinked `.o` bytes hide (bug.md ORA-T2-2). Stable symbol
    names only, so an added hardening call behind a relocation (every inter-unit call in a `.o`)
    is now counted toward the fix signal instead of being silently skipped — it never
    mis-detects: the predicate is X.is_security_intrinsic, the same narrow set the other
    backends use."""
    pcalls = Counter(X.call_targets(md, pv, pc, name_at_P))
    fcalls = Counter(X.call_targets(md, fv, fc, name_at_F))
    added = [c for c in (fcalls - pcalls).elements() if X.is_security_intrinsic(c)]
    for c in sorted(set(fixed_refs or ()) - set(prior_refs or ())):
        if X.is_security_intrinsic(c) and c not in added:
            added.append(c)
    return added


def _func_map(path):
    """{name: (addr, code_bytes)} for every STT_FUNC across ALL code sections.

    Oracle ships relocatable objects (ET_REL `.o`) whose code is split across `.text`,
    `.text.hot` and `.text.unlikely`; a symbol's st_value is an offset into ITS OWN section
    (st_shndx), not a single flat `.text`. The db2 single-`.text` parser (built for the linked
    `libdb2e.so`) therefore sees almost nothing here — e.g. kkz.o exposes only 2 of its 88
    functions, silently dropping the very function a fix lives in (kkzdrphidcol sits in
    `.text.unlikely`). This section-aware parse (pyelftools) carves each function from the
    section st_shndx names. Falls back to the single-`.text` parser if pyelftools is missing
    or the file is a linked image with a flat `.text`.
    """
    try:
        from elftools.elf.elffile import ELFFile
    except Exception:
        return _flat_fallback(path)
    from .. import _results
    limit = _results.max_func_bytes(_MAX_FUNC_BYTES)       # db2_bugs.md DB2-2: configurable
    entries, big = [], {}
    try:
        with open(lp(path), "rb") as fh:
            elf = ELFFile(fh)
            symtab = elf.get_section_by_name(".symtab")
            if symtab is None:
                return _flat_fallback(path)
            sections = list(elf.iter_sections())
            data_cache = {}                       # section index -> bytes (read once)
            src = None                            # current STT_FILE (bugs.md #27)
            for sym in symtab.iter_symbols():
                if sym["st_info"]["type"] == "STT_FILE":
                    src = sym.name or None
                    continue
                if sym["st_info"]["type"] != "STT_FUNC":
                    continue
                sz, val, shndx = sym["st_size"], sym["st_value"], sym["st_shndx"]
                if not sz or not isinstance(shndx, int) or shndx >= len(sections):
                    continue
                sec = sections[shndx]
                sname = sec.name or ""
                if not (sname == ".text" or sname.startswith(".text")):
                    continue                       # code sections only (skip .data/.rodata funcs)
                if shndx not in data_cache:
                    data_cache[shndx] = sec.data()
                code = data_cache[shndx][val:val + sz]
                if code:
                    # CRIT-NT-2: a symbol with no name used to be dropped entirely here,
                    # so it could never be detected as changed, added, or removed, with
                    # zero diagnostic. Give it a synthetic placeholder key instead
                    # (mirrors mssql/stage2.py's sub_<rva> scheme) — only trusted for
                    # same-address changed-function detection below, never new/removed.
                    name = sym.name or ("sub_%x" % val)
                    if sz > limit:                     # recorded, not dropped (#28)
                        _oversized_entry(big, name, code)
                        continue
                    # bugs.md #27: same-named functions no longer overwrite each other —
                    # see db2.stage2._dedupe_func_names(). An ET_REL st_value is relative
                    # to its own section, so a function's identity is (section, offset).
                    local = sym["st_info"]["bind"] == "STB_LOCAL"
                    entries.append((name, (shndx, val), val, code, src if local else None))
    except Exception:
        return _flat_fallback(path)
    fm = _dedupe_func_names(entries)
    fm.oversized = big
    # Relocated-callee map (bug.md ORA-T2-1/T2-2). Computed as a fully-guarded post-step that
    # re-derives everything from `entries` + a fresh relocation parse, so a problem in it can
    # NEVER perturb the core function map built above — the worst case is an empty fm.calls and
    # the previous relocation-blind behaviour.
    fm.calls = _reloc_calls_for(path, entries)
    return fm if (fm or big) else _flat_fallback(path)


def _reloc_calls_for(path, entries):
    """{final-fm-key: [callee symbol names]} for the ET_REL functions in `entries`, resolved
    through .rela.text* (bug.md ORA-T2-1/T2-2). Keyed IDENTICALLY to _dedupe_func_names(entries)
    — hence to fm — by reusing that very function on a parallel list that carries each function's
    callee list in place of its code (the dedup key depends only on name/ident/src, not the
    payload). Isolated and fully guarded: any failure yields {} and callers degrade to the
    previous behaviour. A name later re-keyed by reconcile_dup_names simply misses this map and
    degrades the same way (the rare duplicate-static case)."""
    try:
        from elftools.elf.elffile import ELFFile
        with open(lp(path), "rb") as fh:
            elf = ELFFile(fh)
            rel_index = _reloc_func_refs_by_shndx(elf, list(elf.iter_sections()))
            calls_entries = []
            for name, ident, val, code, src in entries:
                shndx = ident[0]
                offs, refs = rel_index.get(shndx, ((), ()))
                lo = bisect.bisect_left(offs, val)
                hi = bisect.bisect_left(offs, val + len(code))
                fn_refs = sorted({nm for _o, nm in refs[lo:hi]}) if hi > lo else []
                calls_entries.append((name, ident, val, fn_refs, src))
        return {k: v[1] for k, v in _dedupe_func_names(calls_entries).items()}
    except Exception:
        return {}


def _elf_type(path):
    """ELF e_type (1 = ET_REL relocatable object), or None if unreadable/not ELF."""
    try:
        with open(lp(path), "rb") as fh:
            h = fh.read(18)
    except OSError:
        return None
    if len(h) < 18 or h[:4] != b"\x7fELF":
        return None
    return int.from_bytes(h[16:18], "little" if h[5] == 1 else "big")


def _flat_fallback(path):
    """The single-`.text` parser — correct for a LINKED image (absolute st_value, one flat
    .text) but not for an ET_REL object: there st_value is relative to the symbol's own
    section and that parser ignores st_shndx, so a .text.unlikely function would silently
    get .text's bytes at the same offset. For ET_REL, report nothing rather than wrong code
    (an empty map is surfaced as a failed object when its code actually changed).
    A single-.text ET_REL is fine: its section-relative offsets ARE .text offsets."""
    if _elf_type(path) == 1 and _raw_text_section_count(path) != 1:
        return {}
    return _elf_func_map_text(path)


def _raw_text_section_count(path):
    """Number of non-empty .text* sections, by a plain struct parse of the section headers
    (used exactly when pyelftools couldn't parse the file). -1 if unreadable."""
    import struct
    try:
        with open(lp(path), "rb") as fh:
            data = fh.read()
        if data[:4] != b"\x7fELF" or data[4] != 2 or data[5] != 1:
            return -1
        shoff = struct.unpack_from("<Q", data, 0x28)[0]
        shentsize, shnum, shstrndx = struct.unpack_from("<HHH", data, 0x3A)
        hdr = lambda i: struct.unpack_from("<IIQQQQ", data, shoff + i * shentsize)
        _n, _t, _f, _a, stroff, strsize = hdr(shstrndx)
        names = data[stroff:stroff + strsize]
        count = 0
        for i in range(shnum):
            name_off, sh_type, _fl, _ad, _off, size = hdr(i)
            name = names[name_off:names.find(b"\0", name_off)]
            if name.startswith(b".text") and sh_type == 1 and size:
                count += 1
        return count
    except Exception:
        return -1


def _func_sections(path):
    """Distinct section indices holding the code functions of an ET_REL object (empty set
    for a linked image / unparseable file)."""
    if _elf_type(path) != 1:
        return set()
    try:
        from elftools.elf.elffile import ELFFile
        with open(lp(path), "rb") as fh:
            elf = ELFFile(fh)
            symtab = elf.get_section_by_name(".symtab")
            if symtab is None:
                return set()
            sections = list(elf.iter_sections())
            out = set()
            for sym in symtab.iter_symbols():
                shndx = sym["st_shndx"]
                if (sym["st_info"]["type"] == "STT_FUNC" and sym["st_size"]
                        and isinstance(shndx, int) and shndx < len(sections)
                        and (sections[shndx].name or "").startswith(".text")):
                    out.add(shndx)
            return out
    except Exception:
        return set()


class _UnsafeBinDiffMapping(Exception):
    """This object's functions can't be mapped to BinDiff addresses reliably."""


def _pretty(rel):
    return os.path.basename(rel.replace("\\", "/"))


def _safe(s):
    return safe_name(s, 120)


def _rebuild_only_entry(rel, size, what):
    """A `binaries` verdict for a changed native object/archive whose executable code did not
    change (bug.md ORA-NT-1/NT-2): recorded, not left traceless. "rebuild-only" matches the
    objdump .o.asm path's term; the note flags that Oracle does not diff byte/data changes
    (no data-section diff — the ET_REL relocation model makes it unsound, see ORA-NT-2)."""
    return {"object": _pretty(rel), "src": rel, "size": size, "verdict": "rebuild-only",
            "note": f"{what} changed but its executable code did not "
                    f"(byte/data changes are not diffed)"}


# Per-version output layout, shared with MSSQL/DB2 (see _layout.py). Oracle objects are ET_REL,
# so a function is one contiguous blob and its address is section-relative (shown as "offset").
_version_token = _layout.version_token
_version_dirs = _layout.version_dirs


def _binary_folder(base, obj_name, path, side_info, digest=None):
    """This object's folder in one build's output (_layout.binary_folder); display name is
    the object's base name. digest reuses an already-computed sha256 of path."""
    return _layout.binary_folder(base, obj_name, path, side_info, _pretty(obj_name), digest)


def _o_listing(md, binary_name, name, entry):
    """Plain disassembly of one ELF .o function (a single contiguous blob); addresses are
    section-relative offsets (ET_REL)."""
    vaddr, code = entry
    return _layout.listing(md, name, binary_name, vaddr, [(vaddr, code)], "offset")


# --- objdump .o.asm normalization (pre-processed OJVM) ---------------------------------
_ASM_INSTR = re.compile(r"^\s*[0-9a-fA-F]+:\t[0-9a-fA-F ]+\t(.*)$")
_ASM_LABEL = re.compile(r"^[0-9a-fA-F]+ (<.*>):$")
_HEX = re.compile(r"0x[0-9a-fA-F]+")


def _norm_asm(text):
    out = []
    for line in (text or "").split("\n"):
        m = _ASM_INSTR.match(line)
        if m:
            out.append(_HEX.sub("0xH", m.group(1).split("#", 1)[0].rstrip()))
            continue
        lm = _ASM_LABEL.match(line)
        if lm:
            out.append(lm.group(1))
    return out


# --- native ELF .o function diff (raw OJVM) -------------------------------------------
# Per-_diff_o()-call budget (one lone .o, or one .a archive member) — CRIT-NT-5: this used
# to be checked against run()'s single run-wide `readable` accumulator, so one noisy
# object file could exhaust the whole run's budget and silently suppress every later
# file's own, otherwise-unrelated, well-under-cap diffs. _diff_o() now gives each call its
# own fresh _EMIT_CAP, mirroring mssql/db2's per-binary cap (see their _process_dll/
# _process_file) — so a given object file's cards never compete with another's.
_EMIT_CAP = 600
_MAX_FUNC_BYTES = 300_000         # skip pathologically large "functions" (jump tables etc.) —
                                  # same guard mssql/db2 already apply in their _func_map()

# Ghidra default load base for relocatable ELF (ET_REL .o files).
# Ghidra places the first section of an ET_REL object at this address during analysis,
# so BinDiff VAs = st_value_within_section + section_offset_from_base.
# For single-section .o files (one .text block) this simplifies to st_value + _GHIDRA_ELF_REL_BASE.
# For multi-section .o (e.g. .text.hot, .text.unlikely) the section layout depends on Ghidra's
# linker emulation and may need per-section adjustment. Verify against a live Ghidra analysis.
# bugs.md #61: was 0x10000000 — live Ghidra 11.0.3 runs place a single-.text ET_REL object
# at 0x100000. Now only the DEFAULT: the offset is measured from BinDiff's function names
# when possible (_bindiff.map_matches()).
_GHIDRA_ELF_REL_BASE = 0x100000
# GCC compiler-generated clone/outline suffixes — same set as DB2 (both GCC-compiled).
# BinDiff frequently fails to match these across builds because inlining/outlining decisions
# change their CFG structure entirely; they produce phantom new/removed with no attribution.
_ARTIFACT = re.compile(r"\.(cold|constprop|localalias|part|isra|clone|lto_priv)\b")


class NoFunctionSymbols(Exception):
    """A changed object yielded no function symbols on a side, so it couldn't be diffed."""


def _exec_bytes(path):
    """Concatenated bytes of every executable section (SHF_EXECINSTR, or named .text* in case
    the flag is missing), or None when the file can't be parsed — callers treat None as
    "can't prove the code is unchanged"."""
    try:
        from elftools.elf.elffile import ELFFile
        from elftools.elf.constants import SH_FLAGS
        with open(lp(path), "rb") as fh:
            elf = ELFFile(fh)
            return b"".join(sec.data() for sec in elf.iter_sections()
                            if ((sec["sh_flags"] & SH_FLAGS.SHF_EXECINSTR)
                                or (sec.name or "").startswith(".text"))
                            and sec["sh_type"] != "SHT_NOBITS")
    except Exception:
        return None


def _diff_o(obj_name, src_rel, pa, fa, out, readable, attrib=None, use_bindiff=False,
            disassembled_dir=None, run_ts=None, vlabel="vuln", flabel="fixed",
            decompile=False, decompile_cache=None, decompiled_c_dir=None,
            decompile_stats=None, skipped=None, bindiff_fallbacks=None, decompile_max=None,
            decompile_failures=None, version_dirs=None, bindiff_dir=None):
    """Symbol-based capstone function diff of one ELF `.o` pair -> readable cards. Reuses the
    DB2 func-map (ELF .symtab) + shared normalization (branch/call->L etc. masks reloc churn).

    `readable` is mutated in place, same as every caller expects — but (CRIT-NT-5) each
    call now applies _EMIT_CAP against its OWN cards only, internally, before extending
    the caller's list; a prior call having already emitted up to the cap never reduces
    how many THIS call can still emit.

    decompile_stats, if given, is a {"attempted": int, "failed": int} dict mutated in
    place (shares that same accumulate-across-every-call-in-the-loop shape) — lets run()
    track decompile outcomes across every _diff_o() call in its loop. See mssql/
    stage2.py's _process_dll for why:
    distinguishes "nothing warranted decompiling" from "decompile was tried and failed
    every time" (e.g. a stale Ghidra script cache), which previously looked identical."""
    attrib = attrib or []
    if decompile_stats is None:
        decompile_stats = {"attempted": 0, "failed": 0}
    obj_decompiles = {"attempted": 0}     # --decompile-max counts per object (DB2-12)
    # bugs.md #3: pa=None (object added) or fa=None (object removed) is a one-sided function
    # inventory — every function becomes an added/removed card — instead of the object
    # getting no function-level analysis at all. The absent side is an empty function map.
    one_sided = "added" if pa is None else ("removed" if fa is None else None)
    use_bindiff = use_bindiff and not one_sided            # BinDiff needs both builds
    P = _func_map(pa) if pa is not None else {}
    F = _func_map(fa) if fa is not None else {}
    reconcile_dup_names(P, F)
    # bugs.md #28: changed functions too large to diff are reported, not silently dropped
    if skipped is not None:
        skipped.extend({"object": obj_name, "src": src_rel, **s}
                       for s in _results.skipped_oversized(P, F, one_sided))
    expected = {"added": (("fixed", F),), "removed": (("prior", P),)}.get(
        one_sided, (("prior", P), ("fixed", F)))
    if any(not m and not getattr(m, "oversized", None) for _s, m in expected):
        # CRIT-NT-9: run() calls this for EVERY common archive member, changed or not, so an
        # empty map alone isn't a failure (a data-only member legitimately has no functions).
        # But if the executable sections actually differ, real code changes are going
        # unanalyzed (typically a stripped/symbol-less object) — raise so run() records this
        # object as an error instead of it silently vanishing from a clean-looking result.
        # (an absent side has no code; a one-sided data-only object is legitimately empty)
        pc = _exec_bytes(pa) if pa is not None else b""
        fc = _exec_bytes(fa) if fa is not None else b""
        if pc is not None and pc == fc:
            return 0
        sides = [s for s, m in expected if not m]
        raise NoFunctionSymbols(
            f"no function symbols on {' and '.join(sides)} side{'s' if len(sides) > 1 else ''}"
            f" (stripped or no .symtab) — changed code could not be analyzed")
    # CRIT-NT-5: `readable` arrives as run()'s single accumulator shared across EVERY
    # object file (and every archive member) in the whole patch. Every `len(readable) >=
    # _EMIT_CAP` check below used to read that GLOBAL length, so one early, noisy object
    # file could exhaust the entire run's cap and silently suppress every later file's
    # otherwise-unrelated, well-under-cap diffs — with no error and no indication
    # anything was dropped (mirrors mssql/db2's per-binary _process_dll/_process_file,
    # which both give each binary its OWN fresh _EMIT_CAP budget). Shadow the parameter
    # with a fresh local list for the rest of this call, so every cap check below is
    # local to THIS object file, then merge it into the caller's accumulator once at the
    # very end (both return points) — giving this object file the same fresh budget
    # every other backend's per-binary worker already gets.
    _caller_readable = readable
    readable = []
    md = X.md()
    # NAIVE reverse lookup: resolves a call target only when it's already a baked-in
    # absolute immediate in the raw bytes. Oracle's .o files are ET_REL (unlinked) — a
    # call to a function in a DIFFERENT section/compilation unit is typically a
    # relocation entry, not a resolved immediate, so those calls won't resolve here and
    # are silently skipped (is_security_intrinsic/call_targets already treat "not found"
    # as "skip" — this under-detects, it never mis-detects). A fuller fix would also
    # consult the ELF's .rela.text entries; not attempted here.
    name_at_P, name_at_F = _make_name_at(P), _make_name_at(F)
    # Relocated callees per function (bug.md ORA-T2-1/T2-2) — empty for a flat-fallback map or a
    # non-FuncMap test double, in which case every use below degrades to the previous behaviour.
    P_refs, F_refs = getattr(P, "calls", {}) or {}, getattr(F, "calls", {}) or {}

    # Per-version output (bug.md ORA-T1-1 / layout parity): each build's own folder, created
    # on first use; None for a call without per-version folders (test fakes -> old flat way).
    _folders, _side_digest = {}, {}

    def version_folder(kind, side):
        info = (version_dirs or {}).get(side)
        path = pa if side == "prior" else fa
        if not info or path is None:
            return None
        if (kind, side) not in _folders:
            if side not in _side_digest:
                _side_digest[side] = _layout.file_sha256(path)
            _folders[(kind, side)] = _binary_folder(info[kind], obj_name, path, info,
                                                    _side_digest[side])
        return _folders[(kind, side)]

    def _emit_side_listings(prior_name, fixed_name):
        """Each build's plain disassembly of the function, in that build's per-version folder
        (by its own name), so one build's listings can be reused on their own. No-op without
        per-version folders, or for a side whose function/file is absent (added/removed)."""
        for side, nm, fmap in (("prior", prior_name, P), ("fixed", fixed_name, F)):
            if nm and nm in fmap:
                folder = version_folder("asm", side)
                if folder:
                    with open(lp(os.path.join(folder, _layout.function_file(nm, ".asm"))),
                              "w", encoding="utf-8") as fh:
                        fh.write(_o_listing(md, _pretty(obj_name), nm, fmap[nm]))

    def _write_asm_copy(fbase, asm_text):
        # Permanent, version+timestamp-tagged copy for later reference — mirrors
        # mssql/db2's stage2.py; runs unconditionally since assembly diffing is
        # always-on.
        if not disassembled_dir:
            return
        asm_prefix = f"{vlabel}_{flabel}_{run_ts}__{fbase}"
        with open(lp(os.path.join(disassembled_dir, asm_prefix + ".asm.diff")),
                  "w", encoding="utf-8") as fh:
            fh.write(asm_text)

    def _decompile_pair(fbase, prior_name, fixed_name):
        """Best-effort pseudo-C for one matched (non-added/removed) function pair.
        Returns ("", "") when --decompile is off, Ghidra is unavailable, or the ELF
        func-maps don't have raw bytes for the pair. ELF function maps already store
        one contiguous code blob per function, so no chunk-concatenation is needed
        (unlike MSSQL's PE hot/cold fragments)."""
        if not (decompile and decompile_cache and (version_dirs or decompiled_c_dir)):
            return "", ""
        if not decompile_allowed(decompile_max, obj_decompiles):
            # only touched when the cap applies: callers may pass {"attempted", "failed"}
            decompile_stats["skipped"] = decompile_stats.get("skipped", 0) + 1
            return "", ""
        _, pb = P[prior_name]
        _, fb = F[fixed_name]
        prior_c, fixed_c, attempted = decompile_cached(pb, fb, decompile_cache)
        # ORA-T2-1: surface the relocated callees (hidden behind .rela.text* in an unlinked .o)
        # as a header note on each side's pseudo-C, so a changed callee set is visible in the
        # prior-vs-fixed diff. Post-cache (the cache keeps the raw C) and a no-op on an empty
        # side, so the failure/one-sided accounting below is unaffected.
        prior_c = _reloc_refs_note(P_refs.get(prior_name), prior_c)
        fixed_c = _reloc_refs_note(F_refs.get(fixed_name), fixed_c)
        if attempted:
            obj_decompiles["attempted"] += 1
            decompile_stats["attempted"] += 1
            # bugs.md #7: one-sided output is a (partial) failure too
            if not (prior_c and fixed_c):
                decompile_stats["failed"] += 1
                if decompile_failures is not None:                         # DB2-14
                    decompile_failures.append(_dc_failure_record(
                        f"{obj_name} :: {prior_name}"))
        if (prior_c or fixed_c) and version_dirs:
            # Each build's pseudo-C in that build's own folder, by its own function name
            # (prior_name/fixed_name are both present for a matched pair).
            for side, nm, text in (("prior", prior_name, prior_c), ("fixed", fixed_name, fixed_c)):
                if text:
                    folder = version_folder("c", side)
                    if folder:
                        with open(lp(os.path.join(folder, _layout.function_file(nm, ".c"))),
                                  "w", encoding="utf-8") as cf:
                            cf.write(text)
        elif (prior_c or fixed_c) and decompiled_c_dir:
            # a call built without per-version folders: one shared folder, as before
            c_prefix = f"{vlabel}_{flabel}_{run_ts}__{fbase}"
            if prior_c:
                with open(lp(os.path.join(decompiled_c_dir, c_prefix + ".prior.c")),
                          "w", encoding="utf-8") as cf:
                    cf.write(prior_c)
            if fixed_c:
                with open(lp(os.path.join(decompiled_c_dir, c_prefix + ".fixed.c")),
                          "w", encoding="utf-8") as cf:
                    cf.write(fixed_c)
        return prior_c, fixed_c

    bd_failed_reason = None
    if use_bindiff:
        try:
            from patch_differ_cli._bindiff import diff_pair as _bd_diff_pair
            import sys

            # Oracle .o files are ET_REL; st_value is section-relative. For simple .o
            # with a single .text block, BinDiff VA = st_value + Ghidra's load offset.
            # bugs.md #5: that single-base mapping is only valid when every function lives
            # in ONE section. With functions spread over .text/.text.hot/.text.unlikely,
            # section-relative values collide (two functions -> one VA, one silently dropped)
            # and don't match where Ghidra actually places the later sections, so BinDiff
            # matches get attached to the wrong functions. Until per-section placement is
            # modelled, use name matching for such objects (the except below) instead of
            # producing confidently wrong matches.
            if (len(_func_sections(pa)) > 1 or len(_func_sections(fa)) > 1
                    or len({v for v, _c in P.values()}) != len(P)
                    or len({v for v, _c in F.values()}) != len(F)):
                raise _UnsafeBinDiffMapping(
                    "functions span multiple .text* sections; the single-base BinDiff "
                    "address mapping would mis-match them")

            # bug.md ORA-T1-1: a per-object workdir under a sibling of stage2/, not the shared
            # `out`. The old shared `out/bindiff/` piled every object's Ghidra project and
            # .BinExport into the result tree AND let one object's force-killed Ghidra leave a
            # stale project lock that broke BinDiff for every later object. Fallback to `out`
            # keeps callers built without "bindiff_dir" (test fakes) working.
            bd_workdir = os.path.join(bindiff_dir or out, _safe(obj_name))
            matches = _bd_diff_pair(pa, fa, bd_workdir, progress=None)
            # bugs.md #61: offset measured from BinDiff's names, _GHIDRA_ELF_REL_BASE only as
            # the default; nothing resolving raises (-> name matching, recorded) instead of
            # every function becoming a phantom added/removed card.
            from patch_differ_cli._bindiff import map_matches as _bd_map
            addr_to_name_P, addr_to_name_F = _bd_map(matches, P, F, _GHIDRA_ELF_REL_BASE,
                                                     _GHIDRA_ELF_REL_BASE)
        except Exception as exc:
            # A BinDiff/Ghidra hiccup on THIS ONE binary (timeout, misconfiguration, a
            # transient resource issue) must not lose the whole binary's result set —
            # fall through to the plain name-mode path below instead, same as when
            # use_bindiff isn't passed at all. Other binaries in the run are unaffected
            # either way (each is already its own isolated job via _parallel.py).
            import sys
            bd_failed_reason = str(exc) or type(exc).__name__
            print(f"WARNING: BinDiff failed for {obj_name} ({bd_failed_reason}); "
                 f"falling back to name-based matching for this binary.", file=sys.stderr)
            # bugs.md #57: recorded in the result too (counted, exit 3), not only printed
            if bindiff_fallbacks is not None:
                bindiff_fallbacks.append({"object": obj_name, "src": src_rel,
                                          "reason": bd_failed_reason})

    if use_bindiff and bd_failed_reason is None:
        matched_p_vas, matched_f_vas = set(), set()
        raw_bd = []
        for va1, m in matches.items():
            name_p = addr_to_name_P.get(va1)
            name_f = addr_to_name_F.get(m.addr2)
            if name_p is not None and name_f is not None:
                # Only mark BOTH sides "matched" when BOTH resolve to a known function.
                # A one-sided resolution means BinDiff correctly CFG-matched this pair,
                # but our own naive symbol resolver couldn't place one side. If the
                # resolved side were marked matched anyway, it would ALSO be excluded
                # from the new/removed derivation below — the function would then be
                # reported nowhere at all: not changed, not added, not removed. Leaving
                # it unmatched here lets it fall through to new/removed instead, same as
                # the default name-based mode would report it.
                matched_p_vas.add(va1)
                matched_f_vas.add(m.addr2)
            if name_p is None or name_f is None:
                continue
            # bugs.md #53: a BinDiff similarity of 1.0 used to be skipped outright as
            # "CFG-identical". BinDiff scores graph structure and mnemonics, NOT operands,
            # so a changed bounds constant / register width / struct offset scored 1.0 and
            # was never diffed (live-verified: cmp edi,0x100 -> 0xff, zero cards). Only
            # byte-identical functions are skipped; everything else goes through the same
            # norm()/classify() as name mode, which discards relocation-only churn.
            if m.similarity >= 1.0 and P[name_p][1] == F[name_f][1]:
                continue  # truly identical bytes
            raw_bd.append((name_p, name_f, m.similarity, m.confidence))

        removed_bd = sorted(
            name for va, name in addr_to_name_P.items()
            if va not in matched_p_vas and not name.startswith("sub_")
            and not _ARTIFACT.search(name)
        )
        new_bd = sorted(
            name for va, name in addr_to_name_F.items()
            if va not in matched_f_vas and not name.startswith("sub_")
            and not _ARTIFACT.search(name)
        )

        # bugs.md #63: BinDiff leaves a function unmatched when the fix restructures it
        # (added guards/branches) or when several functions look alike — and for MSSQL,
        # Ghidra sees the PE without its PDB, so BinDiff can't fall back on names. Such a
        # function was reported as BOTH removed and added and never diffed (and a pure
        # reorder made phantom cards). Pair what's still unmatched on both sides under
        # the same (non-sub_) name, by name, as name mode does; byte-identical pairs are
        # unchanged. Only names left over are added/removed.
        _unp = {n for va, n in addr_to_name_P.items()
                if va not in matched_p_vas and not n.startswith("sub_")}
        _unf = {n for va, n in addr_to_name_F.items()
                if va not in matched_f_vas and not n.startswith("sub_")}
        _by_name = _unp & _unf
        for name in sorted(_by_name):
            if P[name][1] != F[name][1]:
                raw_bd.append((name, name, None, None))   # no BinDiff sim: name-paired
        removed_bd = [n for n in removed_bd if n not in _by_name]
        new_bd = [n for n in new_bd if n not in _by_name]

        # Pre-compute attribution and fix-score so we can sort before applying the cap.
        # Iterating raw_bd in VA order (dict insertion order) would drop CVE-attributed
        # functions at high addresses before unattributed ones at low addresses.
        bd_hits = []
        for prior_name, fixed_name, bd_sim, bd_conf in raw_bd:
            pv, pc = P[prior_name]; fv, fc = F[fixed_name]
            pL, pS, pI = X.norm(md, pv, pc)
            fL, fS, fI = X.norm(md, fv, fc)
            if X.classify(pL, pS, pI, fL, fS, fI) in ("same", "churn"):
                continue
            sm = difflib.SequenceMatcher(a=pL, b=fL, autojunk=False)
            sim = round(sm.ratio(), 4)
            # Added security intrinsics — the strongest, most self-evident fix signal,
            # mirroring mssql/db2/stage2.py. Baked-in rel32 targets AND relocated callees
            # (ORA-T2-2), so an added hardening call behind a relocation is no longer missed.
            added_intr = _added_security_intrinsics(md, pv, pc, fv, fc, name_at_P, name_at_F,
                                                    P_refs.get(prior_name), F_refs.get(fixed_name))
            fscore, fwhy = X.fix_signature(pL, fL, added_intrinsics=added_intr,
                                           opcodes=sm.get_opcodes())
            cve, why, name_conf = _AT.attribute(prior_name, attrib)
            if cve is None and fixed_name != prior_name:
                cve_f, why_f, nc_f = _AT.attribute(fixed_name, attrib)
                if cve_f is not None:
                    cve, why, name_conf = cve_f, why_f, nc_f
            bd_hits.append((prior_name, fixed_name, bd_sim, bd_conf,
                            sim, fscore, fwhy, pL, fL, cve, why, name_conf, added_intr))
        # Sort: CVE-attributed first, then most fix-shaped, then most-changed (lowest sim).
        # Final (prior, fixed) name tie-breakers (bugs.md #4): BinDiff's SQLite rows have no
        # guaranteed order, so exact ties could otherwise swap between runs of the same input
        # and change which functions survive the _EMIT_CAP truncation.
        bd_hits.sort(key=lambda h: (h[9] is None, -h[5], h[4], h[0], h[1]))

        hits = 0
        for (prior_name, fixed_name, bd_sim, bd_conf, sim, fscore, fwhy, pL, fL, cve, why,
             name_conf, added_intr) in bd_hits:
            # Emit if CVE-attributed OR fix-shaped OR under cap; drop plain churn past cap.
            if cve is None and fscore == 0 and len(readable) >= _EMIT_CAP:
                hits += 1
                continue
            display_name = prior_name if prior_name == fixed_name else f"{prior_name} → {fixed_name}"
            obj = f"{obj_name} :: {display_name}"
            fbase = "fn__" + _safe(obj_name + "_" + prior_name)
            diff = "".join(difflib.unified_diff(
                [l + "\n" for l in pL], [l + "\n" for l in fL],
                fromfile=f"{prior_name} (prior, normalized)",
                tofile=f"{fixed_name} (fixed, normalized)", n=3))
            _asm_text = diff or "(no normalized-instruction differences)\n"
            with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
                fh.write(_asm_text)
            _write_asm_copy(fbase, _asm_text)
            _emit_side_listings(prior_name, fixed_name)
            prior_c, fixed_c = (_decompile_pair(fbase, prior_name, fixed_name)
                                if (fscore > 0 or cve is not None) else ("", ""))
            with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
                json.dump({"object": obj, "prior": "\n".join(pL), "fixed": "\n".join(fL),
                           "prior_c": prior_c, "fixed_c": fixed_c, "truncated": False}, fh)
            readable.append({"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                             "src": src_rel, "group": _pretty(obj_name), "kind": "native",
                             "cve": cve, "why": why, "name_conf": name_conf, "change": "code",
                             "similarity": sim, "fix_score": fscore, "fix_why": "; ".join(fwhy),
                             "intrinsic": bool(added_intr),
                             "bindiff_similarity": bd_sim, "bindiff_confidence": bd_conf,
                             # name-paired after BinDiff left both unmatched (#63)
                             "match_algorithm": "bindiff" if bd_sim is not None else "name"})
            hits += 1
        for name in new_bd:
            cve, why, name_conf = _AT.attribute(name, attrib)
            if cve is None and len(readable) >= _EMIT_CAP:
                hits += 1; continue
            fv, fc = F[name]
            fL, _s, _i = X.norm(md, fv, fc)
            obj = f"{obj_name} :: {name}"
            fbase = "fn__" + _safe(obj_name + "_" + name)
            _asm_text = "(added function — no prior version)\n"
            with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
                fh.write(_asm_text)
            _write_asm_copy(fbase, _asm_text)
            _emit_side_listings(None, name)
            with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
                json.dump({"object": obj, "prior": "", "fixed": "\n".join(fL),
                           "truncated": False}, fh)
            readable.append({"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                             "src": src_rel, "group": _pretty(obj_name), "kind": "native",
                             "cve": cve, "why": why, "name_conf": name_conf, "change": "added",
                             "similarity": 0.0, "fix_score": 0, "fix_why": "",
                             "match_algorithm": "bindiff"})
            hits += 1
        for name in removed_bd:
            cve, why, name_conf = _AT.attribute(name, attrib)
            if cve is None and len(readable) >= _EMIT_CAP:
                hits += 1; continue
            pv, pc = P[name]
            pL, _s, _i = X.norm(md, pv, pc)
            obj = f"{obj_name} :: {name}"
            fbase = "fn__" + _safe(obj_name + "_" + name)
            _asm_text = "(removed function — no fixed version)\n"
            with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
                fh.write(_asm_text)
            _write_asm_copy(fbase, _asm_text)
            _emit_side_listings(name, None)
            with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
                json.dump({"object": obj, "prior": "\n".join(pL), "fixed": "",
                           "truncated": False}, fh)
            readable.append({"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                             "src": src_rel, "group": _pretty(obj_name), "kind": "native",
                             "cve": cve, "why": why, "name_conf": name_conf, "change": "removed",
                             "similarity": 0.0, "fix_score": 0, "fix_why": "",
                             "match_algorithm": "bindiff"})
            hits += 1
        _caller_readable.extend(readable)
        return hits

    # --- name-mode (default) ---
    common = P.keys() & F.keys()
    hits = 0
    # Pre-compute attribution and fix-score for every common function so we can sort by
    # attribution before applying the cap. Iterating alphabetically would drop CVE-attributed
    # functions later in the alphabet before unattributed ones earlier, and the guard must
    # check CVE — which requires attribution to be known before the guard runs.
    name_hits = []
    for k in common:
        pv, pc = P[k]; fv, fc = F[k]
        if pc == fc:
            continue
        pL, pS, pI = X.norm(md, pv, pc)
        fL, fS, fI = X.norm(md, fv, fc)
        if X.classify(pL, pS, pI, fL, fS, fI) in ("same", "churn"):
            continue
        sm = difflib.SequenceMatcher(a=pL, b=fL, autojunk=False)
        sim = round(sm.ratio(), 4)
        # Added security intrinsics — the strongest, most self-evident fix signal, mirroring
        # mssql/db2/stage2.py. Baked-in rel32 targets AND relocated callees (ORA-T2-2); name
        # mode pairs by one key `k`, so both sides' refs are looked up under it.
        added_intr = _added_security_intrinsics(md, pv, pc, fv, fc, name_at_P, name_at_F,
                                                P_refs.get(k), F_refs.get(k))
        fscore, fwhy = X.fix_signature(pL, fL, added_intrinsics=added_intr,
                                       opcodes=sm.get_opcodes())
        cve, why, name_conf = _AT.attribute(k, attrib)
        name_hits.append((k, sim, fscore, fwhy, pL, fL, cve, why, name_conf, added_intr))
    # Sort: CVE-attributed first, then most fix-shaped, then most-changed (lowest sim).
    # Final tie-breaker (h[0], the name itself) makes which functions survive the
    # _EMIT_CAP truncation below deterministic across runs — without it, `common` (a
    # dict_keys & dict_keys set intersection) iterates in a hash-seed-dependent order, so
    # two exactly-tied candidates could swap places between runs of the SAME input.
    name_hits.sort(key=lambda h: (h[6] is None, -h[2], h[1], h[0]))

    for k, sim, fscore, fwhy, pL, fL, cve, why, name_conf, added_intr in name_hits:
        # Emit if CVE-attributed OR fix-shaped OR under cap; drop plain churn past cap.
        if cve is None and fscore == 0 and len(readable) >= _EMIT_CAP:
            hits += 1
            continue
        obj = f"{obj_name} :: {k}"
        fbase = "fn__" + _safe(obj_name + "_" + k)
        diff = "".join(difflib.unified_diff([l + "\n" for l in pL], [l + "\n" for l in fL],
                       fromfile=f"{k} (prior, normalized)", tofile=f"{k} (fixed, normalized)", n=3))
        _asm_text = diff or "(no normalized-instruction differences)\n"
        with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
            fh.write(_asm_text)
        _write_asm_copy(fbase, _asm_text)
        _emit_side_listings(k, k)
        prior_c, fixed_c = (_decompile_pair(fbase, k, k)
                            if (fscore > 0 or cve is not None) else ("", ""))
        with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": "\n".join(pL), "fixed": "\n".join(fL),
                       "prior_c": prior_c, "fixed_c": fixed_c, "truncated": False}, fh)
        readable.append({"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                         "src": src_rel, "group": _pretty(obj_name), "kind": "native",
                         "cve": cve, "why": why, "name_conf": name_conf, "change": "code",
                         "similarity": sim, "fix_score": fscore, "fix_why": "; ".join(fwhy),
                         "intrinsic": bool(added_intr),
                         "match_algorithm": "name"})
        hits += 1
    # sub_-prefixed keys (no ELF symbol name, see _func_map()) are excluded from
    # new/removed: an address present on only one side is an unreliable signal for an
    # unnamed function specifically, since any unrelated layout shift elsewhere in the
    # binary changes every downstream address — that would manufacture phantom
    # added/removed entries rather than catch a real one. `common` above has no such
    # filter: a shared address IS a reliable "same function slot" signal.
    # (a one-sided object has no cross-build address ambiguity: its unnamed functions
    # genuinely are added/removed too, so sub_ keys are kept there — bugs.md #3)
    new = sorted(name for name in F.keys() - P.keys()
                 if not _ARTIFACT.search(name) and (one_sided or not name.startswith("sub_")))
    removed = sorted(name for name in P.keys() - F.keys()
                     if not _ARTIFACT.search(name) and (one_sided or not name.startswith("sub_")))
    for name in new:
        cve, why, name_conf = _AT.attribute(name, attrib)
        if cve is None and len(readable) >= _EMIT_CAP:
            hits += 1; continue
        fv, fc = F[name]
        fL, _s, _i = X.norm(md, fv, fc)
        obj = f"{obj_name} :: {name}"
        fbase = "fn__" + _safe(obj_name + "_" + name)
        _asm_text = "(added function — no prior version)\n"
        with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
            fh.write(_asm_text)
        _write_asm_copy(fbase, _asm_text)
        _emit_side_listings(None, name)
        with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": "", "fixed": "\n".join(fL),
                       "truncated": False}, fh)
        readable.append({"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                         "src": src_rel, "group": _pretty(obj_name), "kind": "native",
                         "cve": cve, "why": why, "name_conf": name_conf, "change": "added",
                         "similarity": 0.0, "fix_score": 0, "fix_why": "",
                         "match_algorithm": "name"})
        hits += 1
    for name in removed:
        cve, why, name_conf = _AT.attribute(name, attrib)
        if cve is None and len(readable) >= _EMIT_CAP:
            hits += 1; continue
        pv, pc = P[name]
        pL, _s, _i = X.norm(md, pv, pc)
        obj = f"{obj_name} :: {name}"
        fbase = "fn__" + _safe(obj_name + "_" + name)
        _asm_text = "(removed function — no fixed version)\n"
        with open(lp(os.path.join(out, fbase + ".asm.diff")), "w", encoding="utf-8") as fh:
            fh.write(_asm_text)
        _write_asm_copy(fbase, _asm_text)
        _emit_side_listings(name, None)
        with open(lp(os.path.join(out, fbase + ".detail.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": "\n".join(pL), "fixed": "",
                       "truncated": False}, fh)
        readable.append({"object": obj, "file": fbase + ".asm.diff", "pair": fbase + ".detail.json",
                         "src": src_rel, "group": _pretty(obj_name), "kind": "native",
                         "cve": cve, "why": why, "name_conf": name_conf, "change": "removed",
                         "similarity": 0.0, "fix_score": 0, "fix_why": "",
                         "match_algorithm": "name"})
        hits += 1
    if one_sided:
        for r in readable:
            r["binary_change"] = one_sided            # the whole object is added/removed
    _caller_readable.extend(readable)
    return hits


def run(prior_dir, fixed_dir, workdir, stage0=None, progress=None, use_bindiff=False,
        decompile=False, vuln_label=None, fixed_label=None, bindiff_only=None,
        decompile_max=None):
    out = os.path.join(workdir, "stage2")
    os.makedirs(lp(out), exist_ok=True)
    if not X.AVAILABLE:
        raise RuntimeError("Stage 2 needs capstone (pip install capstone)")

    # Disk-load fallback: when called standalone (stage0=None, no triage result in memory),
    # load stage0/changed_files.json — if it belongs to these inputs (#43).
    if stage0 is None:
        # bugs.md #43: only a Stage 0 result produced by triage of THESE inputs is used. Any
        # changed_files.json found here used to be trusted — one written for another input
        # pair was analyzed as current (an empty one meant "nothing changed"); a missing,
        # stale or foreign one now raises instead.
        stage0 = _rs.bound_stage0(workdir, prior_dir, fixed_dir)

    changed = [e for e in (stage0 or {}).get("code_changed", [])]
    attrib = _AT.load_attrib(workdir)     # RU's tracked CVEs -> name/CWE tokens (best-effort)

    # Per-version output, mirroring mssql/db2's stage2.py: each build gets its own folders
    # (disassembled_instructions_<build>_<version>/, decompiled_c_<build>_<version>/, one
    # <object>_<sha8>/ subfolder per .o), so one build's results can be reused on their own.
    # The assembly DIFFS compare the two builds, so they keep one pair folder
    # (disassembled_instructions_<vuln>_vs_<fixed>/), with permanent per-run copies. Pseudo-C
    # is only for the native-ELF .o path (Oracle's DBRU Windows PE binaries have no PDBs).
    # bug.md ORA-T1-1: BinDiff working data goes under <workdir>/bindiff_work/<object>/, not
    # inside stage2/ — keeps the result tree clean and isolates each object's Ghidra project.
    decompile_cache = os.path.join(out, "decompile_cache")
    bindiff_dir = os.path.join(workdir, "bindiff_work")
    run_ts = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    vver, fver = _version_token(vuln_label), _version_token(fixed_label)
    vlabel = vver if vuln_label else "vuln"
    flabel = fver if fixed_label else "fixed"
    version_dirs = _version_dirs(out, vver, fver)
    disassembled_dir = _layout.pair_diff_dir(out, vver, fver)
    # bugs.md #3: removed .o/.a files (triage's uncapped code_removed list) get a one-sided
    # "removed" function inventory too, not just a line in the removed-files list.
    removed_bins = [e for e in (stage0 or {}).get("code_removed", []) or []
                    if isinstance(e, dict) and os.path.isfile(lp(os.path.join(prior_dir, e["name"])))]
    if changed or removed_bins:
        os.makedirs(lp(disassembled_dir), exist_ok=True)
        if decompile:
            os.makedirs(lp(decompile_cache), exist_ok=True)
        # the per-version folders are created by the first file written into them

    binaries, readable, code_changed, funcs = [], [], 0, 0
    skipped = []                 # changed functions too large to diff (#28)
    bd_fallbacks = []            # binaries --use-bindiff fell back to name matching (#57)
    decompile_stats = {"attempted": 0, "failed": 0, "skipped": 0}
    dc_failures = []             # per-function pseudo-C failure reasons (DB2-14)
    total = (len(changed) + len(removed_bins)) or 1
    from .._bindiff import bindiff_selected
    not_selected = []            # objects --bindiff-only left to name matching (DB2-12)

    def _inventory(obj, rel, pfile, ffile, size):
        """_diff_o() for one object (either side may be None = absent). A symbol-less
        object with real code is recorded as an error and the run continues (CRIT-NT-9).
        Returns the number of function cards emitted, or None when the object errored."""
        nonlocal funcs
        selected = bindiff_selected(rel, bindiff_only) or bindiff_selected(obj, bindiff_only)
        if use_bindiff and not selected and pfile and ffile:
            not_selected.append(obj)
        try:
            h = _diff_o(obj, rel, pfile, ffile, out, readable, attrib,
                        use_bindiff=use_bindiff and selected,
                        decompile_max=decompile_max,
                        disassembled_dir=disassembled_dir, run_ts=run_ts,
                        vlabel=vlabel, flabel=flabel,
                        decompile=decompile, decompile_cache=decompile_cache,
                        version_dirs=version_dirs, bindiff_dir=bindiff_dir,
                        decompile_stats=decompile_stats, skipped=skipped,
                        bindiff_fallbacks=bd_fallbacks,
                        decompile_failures=dc_failures)
            funcs += h
            return h
        except NoFunctionSymbols as ex:
            binaries.append({"object": obj, "src": rel, "size": size,
                             "verdict": "error", "note": str(ex)[:120]})
            return None

    def _archive_members(rel, pm, fm, size):
        """Every member of an archive pair: common members are diffed; a member present on
        only one side gets a one-sided inventory (it used to vanish entirely) plus a
        member-level added/removed verdict. Returns True if the archive produced ANY trace
        (a function card, or an added/removed/error member verdict) so the caller can give an
        all-rebuild archive a single rebuild-only verdict instead of leaving it traceless
        (ORA-NT-2)."""
        produced = False
        for oname in sorted(set(pm) | set(fm)):
            member = f"{_pretty(rel)}!{oname}"
            h = _inventory(member, rel, pm.get(oname), fm.get(oname), size)
            if (oname in pm) != (oname in fm):
                verdict = "added" if oname in fm else "removed"
                path = (fm if verdict == "added" else pm)[oname]
                binaries.append({"object": member, "src": rel,
                                 "size": os.path.getsize(lp(path)), "verdict": verdict,
                                 "note": "archive member " + verdict})
                produced = True
            elif h is None or h:          # errored (error verdict) or had real code changes
                produced = True
        return produced
    for i, e in enumerate(changed):
        rel = e["name"]
        kind = e.get("kind")
        added = e.get("change") == "added"
        pa, fa = os.path.join(prior_dir, rel), os.path.join(fixed_dir, rel)
        if progress:
            progress(int(100 * i / total), f"Binary diff ({i + 1}/{total}) {_pretty(rel)}")
        try:
            if kind == "archive":                      # .a of ELF .o -> per-member fn diff
                with tempfile.TemporaryDirectory(prefix="ora_ar_") as td:
                    # bugs.md #3: an ADDED archive is a one-sided inventory of its members
                    pm = {} if added else _ar.extract_o(pa, os.path.join(td, "p"))
                    fm = _ar.extract_o(fa, os.path.join(td, "f"))
                    _produced = _archive_members(rel, pm, fm, e.get("size"))
                if not added:
                    # ORA-NT-2: a changed archive whose members produced no trace (every
                    # member's code is unchanged) gets ONE rebuild-only verdict, so it is not
                    # silently absent from the result (no per-member flood).
                    if not _produced:
                        binaries.append(_rebuild_only_entry(rel, e.get("size"), "archive"))
                    continue
                # an added archive still gets its file-level "added" verdict below
            elif kind == "native" and rel.lower().endswith(".o"):
                _h = _inventory(_pretty(rel), rel, None if added else pa, fa, e.get("size"))
                if not added:
                    # ORA-NT-1/NT-2: a changed .o whose executable code did not change (0
                    # cards, not an error) is recorded as rebuild-only rather than leaving no
                    # trace in the result.
                    if _h == 0:
                        binaries.append(_rebuild_only_entry(rel, e.get("size"), "object"))
                    continue
                # an added object still gets its file-level "added" verdict below
            # ---- file-level (PE .dll/.exe, or objdump .o.asm) ----
            verdict, note = "content-changed", ""
            if os.path.isfile(lp(fa)) and (added or os.path.isfile(lp(pa))):
                cb = _code_sig(lp(fa))
                ca = None if added else _code_sig(lp(pa))
                if cb is None and ca is None:
                    if added:
                        verdict = "added"
                    elif rel.lower().endswith(".asm"):
                        with open(lp(pa), "r", encoding="latin-1", errors="replace") as _ph:
                            pn = _norm_asm(_ph.read())
                        with open(lp(fa), "r", encoding="latin-1", errors="replace") as _fh:
                            fn = _norm_asm(_fh.read())
                        verdict = "rebuild-only" if pn == fn else "native-changed"
                        if pn != fn:
                            code_changed += 1
                    else:
                        verdict = "native-changed"; code_changed += 1
                elif added:
                    verdict = "added"
                elif ca != cb:
                    verdict = "code-changed"; code_changed += 1
                else:
                    verdict = "rebuild-only"
            binaries.append({"object": _pretty(rel), "src": rel, "size": e.get("size"),
                             "verdict": verdict, "note": note})
        except Exception as ex:
            binaries.append({"object": _pretty(rel), "src": rel, "size": e.get("size"),
                             "verdict": "error", "note": str(ex)[:120]})

    for k, e in enumerate(removed_bins):
        rel = e["name"]
        pa = os.path.join(prior_dir, rel)
        if progress:
            progress(int(100 * (len(changed) + k) / total), f"Removed binary {_pretty(rel)}")
        try:
            if e.get("kind") == "archive":
                with tempfile.TemporaryDirectory(prefix="ora_ar_") as td:
                    _archive_members(rel, _ar.extract_o(pa, os.path.join(td, "p")), {},
                                     e.get("size"))
            elif rel.lower().endswith(".o"):
                _inventory(_pretty(rel), rel, pa, None, e.get("size"))
            binaries.append({"object": _pretty(rel), "src": rel, "size": e.get("size"),
                             "verdict": "removed", "note": ""})
        except Exception as ex:
            binaries.append({"object": _pretty(rel), "src": rel, "size": e.get("size"),
                             "verdict": "error", "note": str(ex)[:120]})

    # Finalise attribution: assert only when the name/CWE match is corroborated by an added
    # security intrinsic or a fix-shaped change (Oracle native has no cross-binary signal).
    # Most stay candidate-level — an RU bundles a whole quarter's CVEs with no per-CVE->symbol
    # map (see stage1 for the same honest limit).
    for r in readable:
        nc = r.pop("name_conf", None)
        corrob = bool(r.get("intrinsic")) or (r.get("fix_score") or 0) > 0
        conf, asserted = _AT.resolve(nc, corrob)
        # Oracle-specific conservatism: an RU bundles a whole quarter's CVEs that share broad
        # families (auth/buf/load/parse) with NO per-CVE->object map, so a family-only ('low')
        # name match is never *asserted* — it stays a ranked candidate. A specific-subsystem
        # 'high' match stands alone; a 'med' match is asserted only with corroboration.
        if nc == "low":
            asserted = False
        r["confidence"] = conf
        if not asserted and r.get("cve"):
            r["cve_candidate"] = r.pop("cve")
            r["cve"] = None
    # asserted first, then candidate, then fix-shaped, then most-changed (lowest similarity)
    readable.sort(key=lambda r: (r.get("cve") is None, r.get("cve_candidate") is None,
                                 -(r.get("fix_score") or 0), r.get("similarity", 1.0)))
    _order = {"code-changed": 0, "native-changed": 1, "added": 2, "removed": 3}
    binaries.sort(key=lambda b: (_order.get(b["verdict"], 9), -(b.get("size") or 0)))
    result = {
        "available": True,
        "kind": "native" if readable else "file-level",
        "counts": {"binaries": len(binaries), "code_changed": code_changed,
                   "changed_functions": funcs, "readable_changed": len(readable),
                   "attributed": sum(1 for r in readable if r.get("cve")),
                   "candidates": sum(1 for r in readable if r.get("cve_candidate")),
                   "libs": len({r["group"] for r in readable}) or len(binaries),
                   # Mirrors mssql/db2 stage2.py's counts.failed (they use a separate
                   # failed_binaries[] list; Oracle already records the same information
                   # per-binary in binaries[].verdict=="error" — this just makes the
                   # aggregate count queryable the same way across all three backends).
                   "failed": sum(1 for b in binaries if b.get("verdict") == "error"),
                   "functions_skipped": len(skipped),
                   "bindiff_fallbacks": len(bd_fallbacks),
                   "decompile_attempted": decompile_stats["attempted"],
                   "decompile_failed": decompile_stats["failed"],
                   "decompile_skipped": decompile_stats["skipped"]},
        "bindiff_not_selected": sorted(not_selected),
        "decompile_failures": dc_failures,
        "binaries": binaries,
        "skipped_functions": skipped,
        "bindiff_fallbacks": bd_fallbacks,
        "files": [], "readable_files": readable,
    }
    with open(lp(os.path.join(out, "functions_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 2 complete")
    return result