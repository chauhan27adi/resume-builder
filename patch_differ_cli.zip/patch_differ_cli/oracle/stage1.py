"""Stage 1 — the primary Oracle signal: unwrap changed PL/SQL and diff it.

Most Oracle DB CVE fixes ship as PL/SQL package changes, delivered WRAPPED (`.plb`).
For each Stage-0 PL/SQL file that changed between the two RUs we unwrap both sides
(`unwrap.unwrap_text`), diff the readable source, and (when it really changed) write a
`<safe>.pair.json` + unified `.diff` — the exact shape the `/split` renderer and the
detail page's `diffitem` already consume. Output: `<workdir>/stage1/modules_diff.json`.
"""
import difflib
import hashlib
import json
import os
import re
from collections import Counter

from ..db2._paths import lp, safe_name
from . import unwrap as _unwrap
from .. import _srcfix
from .. import _attribution as _AT
from .. import _result_state as _rs
from .. import _acquire_state as _state

_EMIT_CAP = 800
_MAX_BYTES = 8 * 1024 * 1024        # larger readable files are reported as errors, not diffed


def _safe(s):
    return safe_name(s, 150)


class SourceTooLarge(RuntimeError):
    """A changed readable file is over _MAX_BYTES, so it is not diffed."""


def _read_source(path, failures=None):
    """Read a PL/SQL file and unwrap any wrapped units; '' if absent. Units that couldn't be
    unwrapped are appended to `failures` (see unwrap.unwrap_text).

    bugs.md #23: an over-limit file and a read failure both used to come back as '', so a
    changed file was silently dropped (or diffed against nothing). They now raise —
    SourceTooLarge / OSError — and run() records the file as an error instead."""
    if not path or not os.path.isfile(lp(path)):
        return ""
    size = os.path.getsize(lp(path))
    if size > _MAX_BYTES:
        raise SourceTooLarge(f"{os.path.basename(path)} is {size} bytes, over the "
                             f"{_MAX_BYTES}-byte readable-diff limit — not diffed")
    with open(lp(path), "r", encoding="latin-1", errors="replace") as _fh:
        text = _fh.read()
    return _unwrap.unwrap_text(text, failures)


def _norm(text):
    return [l.rstrip() for l in (text or "").split("\n")]


def _read_java(path):
    if not path or not os.path.isfile(lp(path)):
        return ""
    try:
        with open(lp(path), "r", encoding="utf-8", errors="replace") as _fh:
            return _fh.read()
    except OSError:
        return ""


def _sha256_file(path):
    h = hashlib.sha256()
    with open(lp(path), "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _decompile_cached(jd, jar, out_dir):
    """Decompile `jar` into `out_dir`, reusing a previous run's output ONLY if it came from
    byte-identical jar content and the same decompiler. bugs.md #15: the cache used to be
    keyed by the jar's relative path alone ("dir non-empty -> reuse"), so a rerun in the same
    work dir after the jar changed silently diffed the OLD build's source. On a failed
    decompile the stale cache is cleared too — leaving it would show old code all over again."""
    source = {"jar_sha256": _sha256_file(jar), "decompiler": jd.identity()}
    if _state.is_complete(out_dir, source):
        return
    partial = _state.begin(out_dir)
    try:
        n = jd.decompile_jar(jar, partial)    # raises DecompileFailed on any failure (#10)
        if not n:                             # belt-and-braces: never cache empty output
            raise jd.DecompileFailed(f"decompiler produced no source for {os.path.basename(jar)}")
    except BaseException:
        _state.abandon(partial)
        _state.discard(out_dir)
        raise
    _state.commit(out_dir, partial, source, keep_old=False)


def _jar_has_classes(path):
    """True if the jar holds any .class entry. Raises (zipfile.BadZipFile, OSError, …) when
    the archive can't be read — bugs.md #18: that used to return False, so a corrupt or
    unreadable changed jar was skipped as "not Java" with no error."""
    import zipfile
    with zipfile.ZipFile(lp(path)) as zf:
        return any(n.endswith(".class") for n in zf.namelist())


def run(prior_dir, fixed_dir, workdir, stage0=None, progress=None):
    from . import java_decompile as _jd
    out = os.path.join(workdir, "stage1")
    decomp_root = os.path.join(out, "decomp")
    os.makedirs(lp(out), exist_ok=True)

    # Disk-load fallback: when called standalone (stage0=None, no triage result in memory),
    # load stage0/changed_files.json — if it belongs to these inputs (#43).
    if stage0 is None:
        # bugs.md #43: only a Stage 0 result produced by triage of THESE inputs is used. Any
        # changed_files.json found here used to be trusted — one written for another input
        # pair was analyzed as current (an empty one meant "nothing changed"); a missing,
        # stale or foreign one now raises instead.
        stage0 = _rs.bound_stage0(workdir, prior_dir, fixed_dir)

    # bugs.md #3: removed readable files (triage's uncapped content_removed list) are diffed
    # too, one-sided — they used to appear only in the display-only removed-files list.
    changed = [e for e in ((stage0 or {}).get("content_changed", []) or [])
               + ((stage0 or {}).get("content_removed", []) or [])
               if isinstance(e, dict) and e.get("route") == "stage1"]
    text_changed = [e for e in changed if e.get("kind") != "jar"]
    jar_changed = [e for e in changed if e.get("kind") == "jar"]
    readable, wrapped_seen, errors = [], 0, []
    state = {"n": 0}
    attrib = _AT.load_attrib(workdir)     # patch's tracked CVEs -> name/CWE tokens (best-effort)

    def emit(obj, src, kind, change, pl, fl, seed):
        """Write a pair.json + unified .diff and append a readable card (if source changed)."""
        # No cap check here: the cap is applied AFTER ranking (see below). Checking it at
        # emit time capped in FILE order — once 800 cards existed every later readable change
        # was dropped silently, fix-shaped / CVE-matched ones included.
        if pl == fl:
            return False
        sim = round(difflib.SequenceMatcher(a=pl, b=fl, autojunk=False).ratio(), 4)
        # source-level fix signature: rank the change that ADDS a guard/validation/authz check
        # above the one that merely changed the most text (Oracle's primary signal).
        fscore, freasons = _srcfix.fix_signature(pl, fl, lang="java" if kind == "java" else "plsql")
        # name/CWE attribution against the RU's tracked CVEs (finalised after the loop once
        # corroboration is known). The PL/SQL package/object name is the Oracle signal here.
        cve, why, name_conf = _AT.attribute(obj, attrib)
        fbase = "fn__" + _safe(seed)
        diff = "".join(difflib.unified_diff([l + "\n" for l in pl], [l + "\n" for l in fl],
                       fromfile=f"{obj} (prior)", tofile=f"{obj} (fixed)", n=3))
        with open(lp(os.path.join(out, fbase + ".diff")), "w", encoding="utf-8") as fh:
            fh.write(diff or "(no readable differences)\n")
        with open(lp(os.path.join(out, fbase + ".pair.json")), "w", encoding="utf-8") as fh:
            json.dump({"object": obj, "prior": "\n".join(pl), "fixed": "\n".join(fl),
                       "truncated": False}, fh)
        readable.append({"object": obj, "file": fbase + ".diff", "pair": fbase + ".pair.json",
                         "src": src, "kind": kind, "cve": cve, "why": why, "name_conf": name_conf,
                         "change": change, "similarity": sim, "fix_score": fscore,
                         "fix_why": "; ".join(freasons)})
        state["n"] += 1
        return True

    # ---- readable text files: PL/SQL (.plb unwrap) + already-decompiled .java + .sql ----
    total = len(text_changed) or 1
    for i, e in enumerate(text_changed):
        rel = e["name"]
        if progress and (i % 25 == 0):
            progress(int(70 * i / total), f"Diffing readable ({i}/{total})")
        try:
            added = e.get("change") == "added"
            removed = e.get("change") == "removed"
            fpath = os.path.join(fixed_dir, rel)
            # wrapped-source detection on whichever side exists (prior for a removed file)
            rpath = os.path.join(prior_dir, rel) if removed else fpath
            if os.path.isfile(lp(rpath)):
                with open(lp(rpath), "r", encoding="latin-1", errors="replace") as _rfh:
                    raw = _rfh.read()[:4000]
            else:
                raw = ""
            if _unwrap.is_wrapped(raw):
                wrapped_seen += 1
            pfail, ffail = [], []
            pl = _norm("" if added else _read_source(os.path.join(prior_dir, rel), pfail))
            fl = _norm("" if removed else _read_source(fpath, ffail))
            emit(rel, rel, e.get("kind") or "plsql", e.get("change") or "code", pl, fl, rel)
            # bugs.md #50: a wrapped unit that couldn't be unwrapped hides its source. If the
            # same payload failed on both sides, that unit is unchanged and nothing is lost;
            # otherwise its change could not be inspected — say so (partial result, exit 3).
            pdig = Counter(d for _h, d in pfail)
            fdig = Counter(d for _h, d in ffail)
            if pdig != fdig:
                hdrs = sorted({h for h, d in pfail + ffail if pdig[d] != fdig[d]})
                errors.append({"name": rel, "error":
                               f"{len(hdrs)} changed wrapped unit(s) could not be unwrapped "
                               f"— their source was not compared: " + "; ".join(hdrs)[:300]})
        except Exception as exc:
            # One unreadable/vanished file must not abort the whole Stage 1 run — record
            # it and keep going (the same per-item isolation already applied to mssql/db2's
            # Stage 1 and all three backends' Stage 0 this session).
            errors.append({"name": rel, "error": str(exc)})

    # ---- RAW OJVM jars: decompile both sides with CFR, diff each changed .java class ----
    for k, e in enumerate(jar_changed):
        rel = e["name"]
        if progress:
            progress(70 + int(28 * k / max(1, len(jar_changed))), f"Decompiling {os.path.basename(rel)}")
        added = e.get("change") == "added"
        removed = e.get("change") == "removed"
        pj, fj = os.path.join(prior_dir, rel), os.path.join(fixed_dir, rel)
        # Check EACH present side for classes. bugs.md #20/#42: only the fixed side (prior
        # for a removed jar) used to be checked, so a jar whose classes were all removed was
        # skipped as "not Java", and one gaining its first class failed decompiling the
        # class-free prior side and was dropped. A valid class-free side is now simply an
        # empty class map, so the other side's classes report as added/removed.
        try:
            p_has = not added and _jar_has_classes(pj)
            f_has = not removed and _jar_has_classes(fj)
        except Exception as exc:
            errors.append({"name": rel, "error": f"unreadable jar: {exc}"[:300]})
            continue
        if not (p_has or f_has):
            continue                                  # non-Java zip — nothing to decompile
        pd = os.path.join(decomp_root, "prior", _safe(rel))
        fd = os.path.join(decomp_root, "fixed", _safe(rel))
        try:
            if p_has:
                _decompile_cached(_jd, pj, pd)
            if f_has:
                _decompile_cached(_jd, fj, fd)
        except _jd.DecompileFailed as exc:
            # bugs.md #10: record it instead of silently indexing an empty/partial tree.
            # Skip the whole jar if EITHER side failed — emitting the side that worked would
            # report every class as added/removed.
            errors.append({"name": rel, "error": str(exc)[:300]})
            continue

        def _index_java(root):
            m = {}
            if os.path.isdir(lp(root)):
                for dp, _dn, files in os.walk(lp(root)):
                    for f in files:
                        if f.endswith(".java"):
                            ap = os.path.join(dp, f)
                            m[os.path.relpath(ap, lp(root)).replace("\\", "/")] = ap
            return m
        P = _index_java(pd) if p_has else {}
        F = _index_java(fd) if f_has else {}
        for cls in sorted(set(P) | set(F)):
            pl = _norm(_read_java(P.get(cls)))
            fl = _norm(_read_java(F.get(cls)))
            chg = "added" if cls not in P else ("removed" if cls not in F else "code")
            emit(f"{os.path.basename(rel)} :: {cls}", rel, "java", chg, pl, fl, rel + "_" + cls)

    # Finalise attribution: a CVE is only ASSERTED when the name/CWE match is corroborated by a
    # fix-shaped source change (Oracle has no cross-binary signal). An RU bundles a whole
    # quarter's CVEs with no per-CVE->object map, so most matches stay a low-confidence
    # 'candidate' (labelled, not claimed) — this gives ranking/labelling parity with the other
    # backends without overclaiming.
    for r in readable:
        nc = r.pop("name_conf", None)
        corrob = (r.get("fix_score") or 0) > 0
        conf, asserted = _AT.resolve(nc, corrob)
        # Oracle-specific conservatism: an RU bundles a whole quarter's CVEs that share broad
        # families (auth/buf/load/parse) with NO per-CVE->object map, so a family-only ('low')
        # name match is never *asserted* — it stays a ranked candidate. A specific-subsystem
        # 'high' match stands alone; a 'med' match is asserted only with corroboration.
        if nc == "low":
            asserted = False
        r["confidence"] = conf
        if not asserted and r.get("cve"):
            r["cve_candidate"] = r.pop("cve")
            r["cve"] = None
    # asserted first, then candidate, then fix-shaped, then most-changed (lowest similarity);
    # object name last so equal-ranked cards order deterministically
    readable.sort(key=lambda r: (r.get("cve") is None, r.get("cve_candidate") is None,
                                 -(r.get("fix_score") or 0), r.get("similarity", 1.0),
                                 r.get("object", "")))
    # Rank-then-cap: CVE-asserted, candidate and fix-shaped cards always survive (same policy
    # as Stage 2's cap bypass); the remaining plain churn fills up to _EMIT_CAP. Files of
    # dropped cards are removed so the output dir matches the result, and the number dropped
    # is reported instead of vanishing.
    keep, dropped = [], []
    for r in readable:
        priority = r.get("cve") or r.get("cve_candidate") or (r.get("fix_score") or 0) > 0
        (keep if priority or len(keep) < _EMIT_CAP else dropped).append(r)
    for r in dropped:
        for key in ("file", "pair"):
            try:
                os.remove(lp(os.path.join(out, r[key])))
            except OSError:
                pass
    readable = keep
    result = {
        "available": True,
        # NOTE: "plsql_changed" counts every emitted source card — PL/SQL *and* decompiled-Java
        # (state["n"] is bumped for both). Key name kept for output-format compatibility.
        "counts": {"plsql_changed": state["n"], "readable_changed": len(readable),
                   "readable_truncated": len(dropped),
                   "wrapped": wrapped_seen, "jars": len(jar_changed),
                   "attributed": sum(1 for r in readable if r.get("cve")),
                   "candidates": sum(1 for r in readable if r.get("cve_candidate")),
                   "errors": len(errors)},
        "files": [], "readable_files": readable, "errors": errors,
    }
    with open(lp(os.path.join(out, "modules_diff.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 1 complete")
    return result