"""Stage 0 — file triage for an Oracle RU pair.

SHA256-compare the two extracted `files/` trees. Oracle DBRU staging trees also carry
`sqlpatch/**/rollback_files/<ver>/` and `backport_files/` baselines — these are noise
for a straight RU-vs-RU diff (per ora-cve-rca) and are excluded. Changed files route by
type: wrapped PL/SQL (`.plb/.sql/.pkb/.pks/.pkh/.bsq/.trg`) -> Stage 1 (the primary
signal); PE binaries (`.dll/.exe`) -> Stage 2 (file-level); everything else -> content.

Output: `<workdir>/stage0/changed_files.json` (same shape MSSQL/DB2 use, so the detail
page's file tree renders unchanged).
"""
import hashlib
import json
import os

from ..db2._paths import lp
from .. import _acquire_state as _state

# Readable (Stage 1): DBRU PL/SQL (.plb/.sql/…). OJVM readable is handled by extension in
# _route: decompiled `.java`, or a RAW jar/zip of `.class` (decompiled on the fly by stage1).
_PLSQL_EXT = (".plb", ".sql", ".pkb", ".pks", ".pkh", ".bsq", ".trg", ".tyb", ".tys")
# sqlpatch = the OPatch registry/driver area (apply/rollback scripts, rollback_files
# baselines) — patch plumbing, not product code; excluded so it doesn't top the diff.
_EXCLUDE_SEG = ("rollback_files", "backport_files", "sqlpatch")


def _excluded(rel):
    parts = rel.replace("\\", "/").lower().split("/")
    return any(seg in parts for seg in _EXCLUDE_SEG)


def _index(root, failed=None):
    """{relpath: (abspath, size)} for every non-excluded file under root. Walk + relpath use
    the SAME lp()-prefixed base so rel comes out clean regardless of the input's prefixing.

    bugs.md #24/#36: a directory os.walk() couldn't list, and a file whose size couldn't be
    read, used to vanish silently — so that side looked like it lacked them (files shown as
    added/removed, or gone from the comparison entirely) with no error. Each such path is
    now appended to `failed` as (relpath, error); "." is the root itself."""
    out = {}
    base = lp(os.path.abspath(root))

    def _fail(path, exc):
        rel = os.path.relpath(path, base).replace("\\", "/") if path else "."
        if failed is not None and not _excluded(rel):
            failed.append((rel, f"{type(exc).__name__}: {exc.strerror or exc}"))

    for dirpath, _dirs, files in os.walk(base, onerror=lambda e: _fail(e.filename, e)):
        for f in files:
            ap = os.path.join(dirpath, f)
            rel = os.path.relpath(ap, base).replace("\\", "/")
            if _excluded(rel):
                continue
            try:
                out[rel] = (ap, os.path.getsize(ap))
            except OSError as exc:
                _fail(ap, exc)
    return out


def _under(rel, prefixes):
    """True if `rel` is, or lies beneath, one of the (relative) paths in `prefixes`."""
    return any(p == "." or rel == p or rel.startswith(p + "/") for p in prefixes)


def _sha(path):
    h = hashlib.sha256()
    with open(lp(path), "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _route(rel):
    e = os.path.splitext(rel)[1].lower()
    if e in (".jar", ".zip"):
        return "stage1", "jar"           # RAW OJVM: archive of .class -> decompile+diff
    if e == ".java":
        return "stage1", "java"          # already-decompiled OJVM Java (pre-processed input)
    if e in _PLSQL_EXT:
        return "stage1", "sql" if e == ".sql" else "plsql"
    if e == ".a":
        return "stage2", "archive"       # RAW OJVM/DBRU native archive of .o
    if e in (".o", ".asm"):
        return "stage2", "native"        # native object (raw .o) or objdump text (.o.asm)
    if e in (".dll", ".exe"):
        return "stage2", "binary"
    return "other", "content"


def _routed_removed(removed, want_route, sizes=None, kinds=None):
    """Removed files a later stage can still analyze one-sidedly, with route/kind. Kept
    separate from the display-only `removed` list (capped at 2000) so a large removal can't
    silently drop files from analysis (bugs.md #3)."""
    out = []
    for rel in removed:
        route, kind = _route(rel)
        if route == want_route and (kinds is None or kind in kinds):
            out.append({"name": rel, "pretty": rel, "route": route, "kind": kind,
                        "change": "removed", "size": (sizes or {}).get(rel)})
    return out


def _code_removed(removed, sizes=None):
    """Removed .o / .a files for Stage 2's one-sided function inventory."""
    return _routed_removed(removed, "stage2", sizes, kinds=("native", "archive"))


def _content_removed(removed, sizes=None):
    """Removed PL/SQL / Java / jar files for Stage 1's one-sided readable diff."""
    return _routed_removed(removed, "stage1", sizes)


def _from_manifest(manifest, workdir, progress=None):
    """Build the Stage-0 result directly from acquire's member-diff manifest (files-relative
    changed/added/removed) — no re-walk, no re-hash. Applies the same exclusions + routing."""
    code_changed, content_changed = [], []
    added_n = 0
    for status, entries in (("changed", manifest.get("changed", [])),
                            ("added", manifest.get("added", []))):
        for e in entries:
            rel = e["rel"]
            if _excluded(rel):
                continue
            route, kind = _route(rel)
            entry = {"name": rel, "pretty": rel, "size": e.get("size"),
                     "route": route, "kind": kind}
            if status == "added":
                entry["change"] = "added"
                added_n += 1
            (code_changed if route == "stage2" else content_changed).append(entry)
    removed = [r for r in manifest.get("removed", []) if not _excluded(r)]
    code_changed.sort(key=lambda e: -(e.get("size") or 0))
    content_changed.sort(key=lambda e: (e.get("kind") != "plsql", e["name"]))
    result = {
        "counts": {"identical": manifest.get("identical", 0), "rebuild_only": 0,
                   "code_changed": len(code_changed), "content_changed": len(content_changed),
                   "added": added_n, "removed": len(removed),
                   "total": manifest.get("identical", 0) + len(code_changed) + len(content_changed)},
        "code_changed": code_changed, "content_changed": content_changed,
        "rebuild_only": [], "removed": removed[:2000],
        "code_removed": _code_removed(removed),
        "content_removed": _content_removed(removed),
    }
    out = os.path.join(workdir, "stage0")
    os.makedirs(lp(out), exist_ok=True)
    with open(lp(os.path.join(out, "changed_files.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 0 complete (from member-diff manifest)")
    return result


def run(prior_dir, fixed_dir, workdir, progress=None):
    # Fast path: acquire's member-diff already told us exactly what changed (CRC-32 based).
    mpath = os.path.join(workdir, "acquire", "manifest.json")
    if os.path.isfile(lp(mpath)):
        try:
            with open(lp(mpath), encoding="utf-8") as _fh:
                _manifest = json.loads(_fh.read())
            # #14: only if it describes exactly these trees as they are now
            # ...and only if neither tree was modified since (#48)
            if (_state.manifest_applies(_manifest, prior_dir, fixed_dir)
                    and _state.manifest_snapshot_matches(_manifest, prior_dir, fixed_dir)):
                return _from_manifest(_manifest, workdir, progress)
        except Exception:
            pass   # fall back to full walk on any manifest problem
    if progress:
        progress(2, "Indexing prior tree")
    p_failed, f_failed = [], []
    P = _index(prior_dir, p_failed)
    if progress:
        progress(20, "Indexing fixed tree")
    F = _index(fixed_dir, f_failed)

    code_changed, content_changed, identical, errors = [], [], 0, []
    for side, failed in (("prior", p_failed), ("fixed", f_failed)):
        for rel, err in failed:
            errors.append({"name": rel, "error": f"{side} tree could not be indexed: {err}"})
    common = sorted(set(P) & set(F))
    # a path missing from a side because THAT side couldn't be indexed is not evidence it
    # was added/removed — it's reported in errors above instead (#24/#36)
    p_unknown, f_unknown = [r for r, _e in p_failed], [r for r, _e in f_failed]
    added = sorted(r for r in set(F) - set(P) if not _under(r, p_unknown))
    removed = sorted(r for r in set(P) - set(F) if not _under(r, f_unknown))
    total = len(common) or 1
    for i, rel in enumerate(common):
        try:
            pa, psz = P[rel]
            fa, fsz = F[rel]
            if psz == fsz and _sha(pa) == _sha(fa):
                identical += 1
            else:
                route, kind = _route(rel)
                entry = {"name": rel, "pretty": rel, "size": fsz, "route": route, "kind": kind}
                if route == "stage2":
                    code_changed.append(entry)
                else:
                    content_changed.append(entry)
        except Exception as exc:
            # One unreadable/corrupt file must not abort the whole triage run.
            errors.append({"name": rel, "error": str(exc)})
        if progress and (i % 500 == 0):
            progress(20 + int(75 * i / total), f"Comparing files ({i}/{total})")

    # newly-added files (a fix can add a new package/binary) — surface as content w/ change flag
    for rel in added:
        route, kind = _route(rel)
        entry = {"name": rel, "pretty": rel, "size": F[rel][1], "route": route,
                 "kind": kind, "change": "added"}
        (code_changed if route == "stage2" else content_changed).append(entry)

    code_changed.sort(key=lambda e: -e["size"])
    content_changed.sort(key=lambda e: (e.get("kind") != "plsql", e["name"]))
    result = {
        "counts": {"identical": identical, "rebuild_only": 0,
                   "code_changed": len(code_changed), "content_changed": len(content_changed),
                   "added": len(added), "removed": len(removed), "errors": len(errors),
                   "total": len(common)},
        "code_changed": code_changed,          # -> Stage 2 (binaries)
        "content_changed": content_changed,    # PL/SQL -> Stage 1; else content
        "rebuild_only": [],
        "removed": removed[:2000],
        "code_removed": _code_removed(removed, {r: P[r][1] for r in removed}),
        "content_removed": _content_removed(removed, {r: P[r][1] for r in removed}),
        "errors": errors,
    }
    out = os.path.join(workdir, "stage0")
    os.makedirs(lp(out), exist_ok=True)
    with open(lp(os.path.join(out, "changed_files.json")), "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    if progress:
        progress(100, "Stage 0 complete")
    return result