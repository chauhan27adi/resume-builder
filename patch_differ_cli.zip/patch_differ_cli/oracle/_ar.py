"""Minimal pure-Python `ar` (Unix static archive) reader — no system `ar` needed.

Oracle OJVM/DBRU ship native code in `.a` archives (libjavavm19.a, libserver19.a) of ELF
`.o` objects. This extracts the members so Stage 2 can disassemble+diff each `.o`. Handles
the GNU long-name table (`//`). Adapted from ora-cve-rca `ocrca/vendor/elfdiff.py`.
"""
import os
import struct

from ..db2._paths import lp

_MAGIC = b"!<arch>\n"


class MalformedArchive(ValueError):
    """The archive is truncated or not a (regular) ar archive, so its member list can't be
    trusted."""


def ar_members(data):
    """Yield (name, bytes) for each real member of an ar archive `data`.

    bugs.md #45: parsing used to stop quietly at a short header, a bad size field or a
    missing magic, and a short body was returned as-is — so a truncated archive read as a
    shorter one and its lost members looked like intentional removals. Every header is now
    validated (terminator, size, complete body) and anything malformed raises
    MalformedArchive. Only a missing alignment byte after the LAST member is tolerated: no
    member data is lost there."""
    if data[:8] != _MAGIC:
        raise MalformedArchive("not an ar archive (bad magic)")
    pos = 8
    longnames = b""
    while pos < len(data):
        if pos + 60 > len(data):
            if not data[pos:].strip(b"\n\0"):
                break                                  # trailing padding only
            raise MalformedArchive(f"truncated member header at offset {pos}")
        hdr = data[pos:pos + 60]
        if hdr[58:60] != b"`\n":
            raise MalformedArchive(f"corrupt member header at offset {pos}")
        pos += 60
        name = hdr[0:16].decode("latin-1", "replace").rstrip()
        try:
            size = int(hdr[48:58].decode("latin-1").strip())
        except ValueError:
            raise MalformedArchive(f"bad member size field at offset {pos - 60}") from None
        if size < 0 or pos + size > len(data):
            raise MalformedArchive(f"member {name!r} at offset {pos - 60} is truncated "
                                   f"({len(data) - pos} of {size} bytes present)")
        body = data[pos:pos + size]
        pos += size + (size & 1)                       # 2-byte alignment
        if name == "//":                               # GNU long-name table
            longnames = body
            continue
        if name in ("/", "/SYM64/") or name.startswith("__.SYMDEF"):   # symbol tables
            continue
        if name.startswith("/") and name[1:].isdigit():  # GNU long name -> offset into //
            off = int(name[1:])
            end = longnames.find(b"/\n", off)
            name = longnames[off:end].decode("latin-1", "replace") if end != -1 else name
        elif name.startswith("#1/") and name[3:].isdigit():
            # BSD long name: the name is the first N bytes of the member body (bugs.md #9
            # follow-up: these members used to be skipped without a trace)
            n = int(name[3:])
            name = body[:n].rstrip(b"\0").decode("latin-1", "replace")
            body = body[n:]
            if name.startswith("__.SYMDEF"):
                continue
        else:
            name = name.rstrip("/")
        if name:
            yield name, body


def extract_o(a_path, out_dir):
    """Extract every `.o` member of `a_path` into `out_dir`; return {member_key: abspath}.

    bugs.md #9: members were written to a flattened name ("/" -> "_"), so distinct members
    like "a/b.o" and "a_b.o" (or two members with the SAME name, which `ar q` allows, or
    names differing only in case on NTFS) landed on one file: the later member's bytes were
    analyzed under both names and the earlier member silently vanished. Each member now
    gets its own file (archive-position prefix), and a repeated name is keyed "name#2",
    "name#3", ... so the k-th copy in one build pairs with the k-th copy in the other."""
    os.makedirs(lp(out_dir), exist_ok=True)
    with open(lp(a_path), "rb") as f:
        data = f.read()
    out, seen = {}, {}
    for i, (name, body) in enumerate(ar_members(data)):
        if not name.endswith(".o"):
            continue
        seen[name] = seen.get(name, 0) + 1
        key = name if seen[name] == 1 else f"{name}#{seen[name]}"
        safe = name.replace("/", "_").replace("\\", "_").replace(":", "_")
        dst = os.path.join(out_dir, f"{i:05d}_{safe}")
        with open(lp(dst), "wb") as fh:
            fh.write(body)
        out[key] = dst
    return out