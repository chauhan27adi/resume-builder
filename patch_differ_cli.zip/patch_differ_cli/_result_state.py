"""Which comparison each persisted stage result belongs to (bugs.md #37, #43).

A stage-limited run used to leave an older later-stage result in place, and `show`
presented it beside the new triage as if one run had produced both (#37). A later stage
run on its own also used to load whatever stage0/changed_files.json sat in the output dir,
even one written for a different input pair, and analyze that list as if it were current
(#43).

Every triage run records the IDENTITY of the comparison it made — its stage0 JSON plus the
content (SHA-256 per file) of both input trees; the JSON alone isn't enough, since it
records names and sizes, not contents, and file stats aren't either, since an edit can keep
size and timestamp — in <out>/result_state.json. Each stage1/stage2
run records the identity it ran against. A stage result is current only while that matches
the latest triage, and a stage0 result is usable as an input only while its identity
matches the input trees being analyzed. Two separate stage runs on untouched inputs share
one identity, so both stay current.
"""
import hashlib
import json
import os
from pathlib import Path

from .db2._paths import lp

STATE_FILE = "result_state.json"
STAGE0_FILE = os.path.join("stage0", "changed_files.json")


def stage0_digest(out_dir):
    p = Path(out_dir) / STAGE0_FILE
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def _file_digest(path):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            for blk in iter(lambda: fh.read(4 << 20), b""):
                h.update(blk)
    except OSError as exc:
        return f"<unreadable:{type(exc).__name__}>"
    return h.hexdigest()


def comparison_identity(out_dir, vuln_dir, fixed_dir):
    """Identity of the comparison now on disk: the stage0 result + both input trees, each
    file by relative path and the SHA-256 of its CONTENT.

    An earlier version of this fix fingerprinted the trees by stat (path, size, mtime) to
    avoid reading them; an input edited to different bytes of the same size with its
    timestamp restored then kept the old identity, so stale Stage 1/2 results stayed
    "current" (#37) and an old change list was reused as if it described the new inputs
    (#43). Hashing costs one sequential read of both trees per triage run — the same order
    as triage itself, which already reads most common files' content."""
    h = hashlib.sha256()
    h.update((stage0_digest(out_dir) or "-").encode())
    for side, root in (("vuln", vuln_dir), ("fixed", fixed_dir)):
        base = lp(os.path.abspath(str(root)))
        h.update(f"\0{side}\0{os.path.normcase(os.path.abspath(str(root)))}"
                 .encode("utf-8", "surrogatepass"))
        rows = []
        out_norm = os.path.normcase(os.path.abspath(lp(os.path.abspath(str(out_dir)))))
        for dp, dn, files in os.walk(base):
            # an output dir nested inside an input tree changes on every run — not an input
            dn[:] = [d for d in dn
                     if os.path.normcase(os.path.abspath(os.path.join(dp, d))) != out_norm]
            for fn in files:
                ap = os.path.join(dp, fn)
                rows.append((os.path.relpath(ap, base).replace("\\", "/"), ap))
        for rel, ap in sorted(rows):
            h.update(f"{rel}\0{_file_digest(ap)}\n".encode("utf-8", "surrogatepass"))
    return h.hexdigest()


def read_state(out_dir):
    """The result-state record, {} if it is unreadable, or None if there is none (an output
    dir written by a version that didn't keep one — its results can't be checked)."""
    p = Path(out_dir) / STATE_FILE
    if not p.exists():
        return None
    try:
        state = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return state if isinstance(state, dict) else {}


def set_stage_state(out_dir, stage, identity=None, forget=False):
    """Record (or, with forget=True, drop) `stage`'s comparison identity. A stage's entry
    is dropped BEFORE it runs, so if it fails its older JSON can't pass as this run's."""
    state = read_state(out_dir) or {}
    if forget:
        state.pop(stage, None)
    else:
        state[stage] = {"identity": identity}
    p = Path(out_dir) / STATE_FILE
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
    os.replace(tmp, p)


def triage_identity(out_dir):
    rec = (read_state(out_dir) or {}).get("triage")
    return rec.get("identity") if isinstance(rec, dict) else None


def stage0_is_current(out_dir, vuln_dir, fixed_dir):
    """True if stage0/changed_files.json was produced by triage of exactly these inputs."""
    recorded = triage_identity(out_dir)
    return bool(recorded) and recorded == comparison_identity(out_dir, vuln_dir, fixed_dir)


def bound_stage0(workdir, prior_dir, fixed_dir):
    """The persisted Stage 0 result for a backend stage called WITHOUT one in memory (#43).

    Raises RuntimeError when there is none, or it wasn't produced by triage of these input
    trees — a stale or foreign change list used to be analyzed as if it were current (an
    empty one silently meant "nothing changed"). Run triage first."""
    p = os.path.join(workdir, STAGE0_FILE)
    if not os.path.isfile(lp(p)):
        raise RuntimeError(f"no Stage 0 result in {workdir} — run triage first")
    if not stage0_is_current(workdir, prior_dir, fixed_dir):
        raise RuntimeError(f"{p} was not produced by triage of these input directories "
                           f"(or the inputs changed since) — run triage first")
    with open(lp(p), encoding="utf-8") as fh:
        return json.load(fh)
